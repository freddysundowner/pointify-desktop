const express = require("express");
const auth = require("./auth");
const shop = require("./shop");
const supplier = require("./supplier");
const product = require("./product");
const measures = require("./measure");
const purchase = require("./purchase");
const attendants = require("./attendant");
const payments = require("./payments");
const counts = require("./count");
const purchasereturns = require("./purchasereturn");
const salereturn = require("./salereturn");
const badstock = require("./badstock");
const sales = require("./sale");
const transfer = require("./transfer");
const analysis = require("./analysis");
const customers = require("./customer");
const cashflowcategory = require("./cashflowcategory");
const admin = require("./admin"); 
const bank = require("./bank");
const cashflow = require("./cashflow");
const expenses = require("./expenses");
const expensescategory = require("./expensescategory");
const packages = require("./packageRoutes");
const subscriptions = require("./subscription");
const mpesa = require("./mpesa");
const settingRoutes = require("./settingRoutes");
const languageRoutes = require("./languageRoutes");
const notificationsRouter = require("./notificationRoutes");
const affliateRoutes = require("./affliates");
const communication = require("./communication");
const warehouse = require("./stockrequest");
const history = require("./history");
const staff = require("./staff")
const templates = require("./email_templates");
const themes = require("./themes");
const paymentmethods = require("./payment_methods");
const permissionsRoutes = require('./permissions');
const sms = require("./sms");
const verifyToken = require("../middleware/auth");
const attendantController = require("../controllers/attendant");
const reports = require("./reports");
const adminAnalaytics = require("../controllers/admin_analytics");

const aiLogs = require("./aiLogs");

module.exports = app = express();
app.use("/sms", sms)
app.use("/auth", auth);
app.use("/shop", verifyToken, shop);
app.use("/product", verifyToken, product);
app.use("/suppliers", verifyToken, supplier);
app.use("/templates", templates);
app.use("/measures", measures);
app.use("/purchases", verifyToken, purchase);
app.use("/payments", verifyToken, payments);

app.use("/reports", verifyToken, reports);
app.use("/admin/analytics", verifyToken, adminAnalaytics.getStatistics);
app.use("/attendants/login", attendantController.loginAattendant);
app.use("/attendants", verifyToken, attendants);
app.use("/purchasereturns", purchasereturns);
app.use("/salereturns", verifyToken,salereturn);
app.use("/counts", verifyToken,counts);
app.use("/badstock", verifyToken,badstock);
app.use("/sales", verifyToken, sales);
app.use("/transfer", verifyToken,transfer);
app.use("/analysis",verifyToken, analysis);
app.use("/customers", verifyToken, customers);
app.use("/cashflowcategory", verifyToken, cashflowcategory);
app.use("/cashflow",verifyToken, cashflow);
app.use("/bank", verifyToken, bank);
app.use("/expenses", verifyToken, expenses);
app.use("/communication", communication);
app.use("/admin", admin);
app.use("/expensescategory", verifyToken, expensescategory);
app.use("/packages", verifyToken,packages);
app.use("/subscriptions", verifyToken, subscriptions);
app.use("/payment", mpesa);
app.use("/settings/", settingRoutes); 
app.use("/language/", languageRoutes);
app.use("/affiliates/", affliateRoutes);
app.use("/warehouse/", verifyToken,warehouse);
app.use("/history", verifyToken, history);
app.use("/themes", themes);
app.use("/staff", verifyToken, staff)
// app.use("/sync", sync);
// app.use("/printer", printerRoutes);
app.use("/payment-methods", verifyToken, paymentmethods)
app.use("/notifications", notificationsRouter);
app.use('/permissions', permissionsRoutes);

// 2. Add this with the other app.use() lines:
app.use("/ai-logs", verifyToken, aiLogs);
app.get("/verify", (req, res) => {
  res.sendFile(__dirname + "/verify_email.html");
});

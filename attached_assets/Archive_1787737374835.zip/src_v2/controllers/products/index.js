const Product = require("@src/models/product");
const ProductCategory = require("@src/models/product");
const Supplier = require("@src/models/supplier");
const Inventory = require("@src/models/inventory");
const Shop = require("@src/models/shop");
const SaleItem = require("@src/models/saleitem");
const { Types } = require("mongoose");

const ObjectId = Types.ObjectId;
const { repairMissingInventories } = require("@src/shared/functions");
const { createNewBatch } = require("@src/shared/functions");
const { buildProductQuery } = require("./helpers/buildProductQuery");

const { getSortOptions } = require("./helpers/getSortOptions");

const { populateProductFields } = require("./helpers/populateProductFields");

const { paginatedResponse } = require("./helpers/paginatedResponse");

const getProductsList = async (req, res) => {
    try {
        const {
            sort,
            page,
            limit,
            reason = "all",
            stockMode = "all",
        } = req.query;

        if (!req.query.shop) {
            return res.status(400).json({ error: "shop is required" });
        }

        const query = buildProductQuery(req);

        // FAST MOVING
        if (req.query.type === "fastmoving") {
            const ids = await getFastMovingProductIds(req.query.shop);

            query._id = {
                $in: ids,
            };
        }

        // DORMANT
        if (req.query.type === "dormant") {
            const soldProducts = await getDormantProductIds(req.query.shop);

            query._id = {
                $nin: soldProducts,
            };
        }

        const sortOptions = getSortOptions(sort, query);

        // FETCH PRODUCTS
        const productQuery = Product.find(query).sort(sortOptions).lean();

        let products = await populateProductFields(productQuery);

        // FETCH INVENTORIES
        const inventories = await Inventory.find({
            $or: [
                {
                    shop: req.query.shop,
                },
                {
                    shop: { $exists: false },
                },
                {
                    shop: null,
                },
            ],

            product: {
                $in: products.map((p) => p._id),
            },
        })
            .select("_id product quantity shop repairVersion")
            .lean();
        // REPAIR + MAP
        const shopDetails = await Shop.findById(req.query.shop)
            .select("useWarehouse")
            .lean();
        const inventoryMap = await repairInventories({
            products,
            inventories,
            shopId: req.query.shop,
            useWarehouse: shopDetails?.useWarehouse === true,
        });
        products = products.map((product) => {
            const inventoryQty = inventoryMap[product._id.toString()];

            return {
                ...product,

                quantity: shopDetails?.useWarehouse
                    ? (inventoryQty ?? product.quantity ?? 0)
                    : (product.quantity ?? 0),
            };
        });

        // STOCK FILTERS
        if (stockMode === "instock") {
            products = products.filter((p) => p.quantity > 0);
        }

        if (stockMode === "outofstock") {
            products = products.filter(
                (p) => p.quantity <= 0 && p.productType !== "service",
            );
        }

        if (stockMode === "runninglow") {
            products = products.filter(
                (p) =>
                    p.quantity > 0 &&
                    p.quantity < (p.reorderLevel || Number.MAX_SAFE_INTEGER) &&
                    p.productType !== "service",
            );
        }

        // TOTAL BEFORE PAGINATION
        const totalProducts = products.length;

        // PAGINATION
        if (page) {
            const pageInt = parseInt(page) || 1;

            const limitInt = parseInt(limit) || 10;

            const start = (pageInt - 1) * limitInt;

            const end = start + limitInt;

            products = products.slice(start, end);
        }

        // PAGINATED RESPONSE
        if (page && reason !== "download") {
            return paginatedResponse({
                res,
                data: products,
                total: totalProducts,
                page,
                limit,
            });
        }

        // NORMAL RESPONSE
        return res
            .status(200)
            .json(reason === "download" ? { data: products } : products);
    } catch (error) {
        console.error(error);

        return res.status(500).json({
            error: "Internal server error",
        });
    }
};
const repairInventories = async ({
    products,
    inventories,
    shopId,
    useWarehouse,
}) => {
    const inventoryMap = {};
    const inventorySet = new Set();

    for (const inv of inventories) {
        // if(!inv.repairVersion){
        //   //delete this inventory
        //   await Inventory.findByIdAndDelete(inv._id);
        // }
        if (!inv.shop) {
            // await Inventory.findByIdAndDelete(inv._id);
            continue;
        }
        const productId = inv.product.toString();

        inventoryMap[productId] = inv.quantity;

        inventorySet.add(productId);
    }

    const repairs = [];
    const healOperations = [];

    for (const product of products) {
        const productId = product._id.toString();

        const inventoryQty = inventoryMap[productId];

        // MISSING INVENTORY
        if (!inventorySet.has(productId)) {
            const quantity = product.quantity > 0 ? product.quantity : 0;
            if (shopId) {
                repairs.push({
                    quantity,

                    lastCount: quantity,

                    reorderLevel: product.reorderLevel || 0,

                    product: product._id,

                    shop: shopId,
                    repairVersion: 2,

                    attendant: product.attendantId,

                    expiryDate: product.expiryDate || null,

                    barcode: product.barcode || null,
                });

                // immediately reflect in response
                inventoryMap[productId] = quantity;
            }
        } else if (
            !useWarehouse &&
            Number(inventoryQty) !== Number(product.quantity)
        ) {
            const repairedQty = Number(product.quantity) || 0;

            console.log(
                `SYNC INVENTORY | ${product.name} | Inventory: ${inventoryQty} -> Product: ${repairedQty}`,
            );

            healOperations.push({
                updateOne: {
                    filter: {
                        product: product._id,
                        shop: shopId,
                    },
                    update: {
                        $set: {
                            quantity: repairedQty,
                        },
                    },
                },
            });

            // Immediately use corrected quantity in API response
            inventoryMap[productId] = repairedQty;
        }
        // NEGATIVE INVENTORY SELF HEAL
        else if (inventoryQty < 0) {
            const repairedQty = product.quantity > 0 ? product.quantity : 0;

            healOperations.push({
                updateOne: {
                    filter: {
                        product: product._id,
                        shop: shopId,
                    },

                    update: {
                        $set: {
                            quantity: repairedQty,
                        },
                    },
                },
            });

            // immediately reflect in response
            inventoryMap[productId] = repairedQty;
        }
    }

    // NON-BLOCKING DB OPERATIONS
    setImmediate(async () => {
        // CREATE MISSING
        try {
            if (repairs.length > 0) {
                await Inventory.insertMany(repairs, { ordered: false });

                console.log(
                    `AUTO INVENTORY REPAIR | Created ${repairs.length}`,
                );
            }
        } catch (err) {
            if (err.code !== 11000) {
                console.error("CREATE INVENTORY ERROR", err);
            }
        }

        // HEAL NEGATIVES
        try {
            if (healOperations.length > 0) {
                await Inventory.bulkWrite(healOperations);

                console.log(
                    `SELF HEAL INVENTORY | Fixed ${healOperations.length}`,
                );
            }
        } catch (err) {
            console.error("SELF HEAL ERROR", err);
        }
    });

    // console.log(inventoryMap);
    return inventoryMap;
};

const copyFromOthershop = async (req, res) => {
    try {
        let {
            products,
            importall = false,
            fromShop,
            toShop,
            toShopOwner,
            resetQuantity,
            attendantId,
        } = req.body;
        console.log(req.body);
        let successCount = 0;
        let failCount = 0;
        //kimbo 69cce476dc65684e23de5680
        if (importall == true) {
            products = await Product.find({ shopId: fromShop, deleted: false });
            console.log("products ", products);
            products = products.map((i) => {
                const product = i.toObject();

                delete product._id;
                delete product.__v;

                product.quantity = resetQuantity
                    ? 0
                    : product.quantity == ""
                      ? 0
                      : product.quantity;

                product.reorderLevel =
                    product.reorderLevel == "" ? 0 : product.reorderLevel;

                product.buyingPrice =
                    product.buyingPrice == "" ? 0 : product.buyingPrice;

                product.description =
                    product.description == "" ? "" : product.description;

                product.sellingPrice =
                    product.sellingPrice == "" ? 0 : product.sellingPrice;

                product.minSellingPrice =
                    product.minSellingPrice == "" ? 0 : product.minSellingPrice;

                product.maxDiscount =
                    product.maxDiscount == "" || product.maxDiscount == "null"
                        ? 0
                        : product.maxDiscount;

                product.supplierId =
                    product.supplierId == "" ? null : product.supplierId;

                product.productCategoryId = product.productCategoryId ?? null;

                product.attendantId = attendantId ?? null;

                product.admin = toShop?.adminId ?? null;

                product.shopId = toShop?._id;

                product.deleted = false;

                return product;
            });
        }
        console.log(products);

        const promises = products.map(async (i) => {
            try {
                // ONLY FOR MANUAL IMPORTS
                if (!importall) {
                    i.attendantId = attendantId ?? null;

                    if (i.productCategoryId) {
                        const category = await ProductCategory.findOneAndUpdate(
                            {
                                name: i.productCategoryId,
                                admin: i.adminId,
                            },
                            {
                                name: i.productCategoryId,
                                admin: i.adminId,
                            },
                            {
                                upsert: true,
                                new: true,
                                setDefaultsOnInsert: true,
                            },
                        );

                        i.productCategoryId = category._id;
                    }

                    if (i.supplierId) {
                        const supplier = await Supplier.findOneAndUpdate(
                            {
                                name: i.supplierId,
                                shopId: i.adminId,
                            },
                            {
                                name: i.supplierId,
                                shopId: toShop?._id,
                            },
                            {
                                upsert: true,
                                new: true,
                                setDefaultsOnInsert: true,
                            },
                        );

                        i.supplierId = supplier._id;
                    }
                }

                i.attendantId = attendantId;

                // CHECK EXISTING
                console.log(toShop?._id, i.name);
                const existingProduct = await Product.findOne({
                    name: i.name,
                    shopId: toShop?._id,
                });

                i.quantity = resetQuantity === true ? 0 : i.quantity || 0;

                if (!existingProduct) {
                    i.reorderLevel = i.reorderLevel || 0;
                    i.shopId = toShop?._id;
                    const productResponse = await Product.create(i);

                    const newInventory = new Inventory({
                        quantity: i.quantity,
                        product: productResponse._id,
                        shop: toShop?._id,
                        attendant: attendantId,
                    });

                    await newInventory.save();

                    const shopDetails = await Shop.findOne({
                        _id: toShop?._id,
                    });

                    await createNewBatch(
                        productResponse,
                        shopDetails?.trackbatches,
                    );

                    successCount++;
                } else {
                    failCount++;
                }
            } catch (error) {
                console.error(`Failed to import product: ${i.name}`, error);

                failCount++;
            }
        });

        // Wait for all product creations to complete
        await Promise.all(promises);

        res.status(200).json({
            success: true,
            imported: successCount,
            failed: failCount,
            total: products.length,
            message: `Imported ${successCount} products, ${failCount} failed.`,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
};

const productStats = async (req, res) => {
    try {
        const { shopid } = req.query;

        const shopId = new ObjectId(shopid);

        const days = 30;

        const fromDate = new Date();

        fromDate.setDate(fromDate.getDate() - days);

        // PRODUCT COUNTS
        const stats = await Product.aggregate([
            {
                $match: {
                    shopId,
                    deleted: false,

                    productType: {
                        $ne: "service",
                    },
                },
            },

            {
                $group: {
                    _id: null,

                    total: {
                        $sum: 1,
                    },

                    instock: {
                        $sum: {
                            $cond: [
                                {
                                    $gt: ["$quantity", 0],
                                },
                                1,
                                0,
                            ],
                        },
                    },

                    outofstock: {
                        $sum: {
                            $cond: [
                                {
                                    $lte: ["$quantity", 0],
                                },
                                1,
                                0,
                            ],
                        },
                    },

                    runninglow: {
                        $sum: {
                            $cond: [
                                {
                                    $and: [
                                        {
                                            $gt: ["$quantity", 0],
                                        },

                                        {
                                            $gt: ["$reorderLevel", 0],
                                        },

                                        {
                                            $lte: [
                                                "$quantity",
                                                "$reorderLevel",
                                            ],
                                        },
                                    ],
                                },

                                1,

                                0,
                            ],
                        },
                    },
                },
            },
        ]);

        // SOLD PRODUCTS
        const soldProducts = await SaleItem.distinct("product", {
            shopId,

            createdAt: {
                $gte: fromDate,
            },

            status: {
                $ne: "cancelled",
            },
        });

        // DORMANT
        const dormant = await Product.countDocuments({
            shopId,

            deleted: false,

            productType: {
                $ne: "service",
            },

            quantity: {
                $gt: 0,
            },

            _id: {
                $nin: soldProducts,
            },
        });

        // FAST MOVING
        const fastmoving = await SaleItem.aggregate([
            {
                $match: {
                    shopId,

                    createdAt: {
                        $gte: fromDate,
                    },

                    status: {
                        $ne: "cancelled",
                    },
                },
            },

            {
                $group: {
                    _id: "$product",

                    totalSoldQty: {
                        $sum: "$quantity",
                    },

                    salesCount: {
                        $sum: 1,
                    },
                },
            },

            {
                $sort: {
                    totalSoldQty: -1,
                },
            },

            {
                $limit: 10,
            },

            {
                $lookup: {
                    from: "products",

                    localField: "_id",

                    foreignField: "_id",

                    as: "product",
                },
            },

            {
                $unwind: "$product",
            },

            {
                $project: {
                    _id: "$product._id",

                    name: "$product.name",

                    quantity: "$product.quantity",

                    reorderLevel: "$product.reorderLevel",

                    sellingPrice: "$product.sellingPrice",

                    totalSoldQty: 1,

                    salesCount: 1,
                },
            },
        ]);

        const productStats = stats[0] ?? {
            total: 0,
            instock: 0,
            outofstock: 0,
            runninglow: 0,
        };

        return res.status(200).json({
            success: true,

            stats: {
                total: productStats.total,

                instock: productStats.instock,

                outofstock: productStats.outofstock,

                runninglow: productStats.runninglow,

                dormant,
            },

            fastmoving,
        });
    } catch (err) {
        return res.status(500).json({
            success: false,

            message: err.message,
        });
    }
};

const getFastMovingProductIds = async (shopId) => {
    const days = 30;

    const fromDate = new Date();

    fromDate.setDate(fromDate.getDate() - days);

    const fastmoving = await SaleItem.aggregate([
        {
            $match: {
                shopId: new ObjectId(shopId),

                createdAt: {
                    $gte: fromDate,
                },

                status: {
                    $ne: "cancelled",
                },
            },
        },

        {
            $group: {
                _id: "$product",

                totalSoldQty: {
                    $sum: "$quantity",
                },
            },
        },

        {
            $sort: {
                totalSoldQty: -1,
            },
        },

        {
            $limit: 50,
        },
    ]);

    return fastmoving.map((i) => i._id);
};
const getDormantProductIds = async (shopId) => {
    const days = 30;

    const fromDate = new Date();

    fromDate.setDate(fromDate.getDate() - days);

    const soldProducts = await SaleItem.distinct("product", {
        shopId: new ObjectId(shopId),

        createdAt: {
            $gte: fromDate,
        },

        status: {
            $ne: "cancelled",
        },
    });

    return soldProducts;
};

const bulkEditProduct = async (req, res) => {
    try {
        const { productIds, productCategoryId } = req.body;

        if (!productIds?.length) {
            return res.status(400).json({
                success: false,
                message: "No products selected",
            });
        }

        const result = await Product.updateMany(
            {
                _id: { $in: productIds },
            },
            {
                $set: {
                    productCategoryId,
                },
            },
        );

        return res.status(200).json({
            success: true,
            modifiedCount: result.modifiedCount,
            message: `${result.modifiedCount} products updated successfully`,
        });
    } catch (error) {
        console.error(error);

        return res.status(500).json({
            success: false,
            message: "Internal server error",
        });
    }
};
const bulkCreateProducts = async (req, res) => {
    try {
        const { shopId, adminId, attendantId, products } = req.body;
        console.log(req.body);

        if (!shopId) {
            return res
                .status(400)
                .json({ success: false, message: "shopId is required" });
        }
        if (!Array.isArray(products) || products.length === 0) {
            return res.status(400).json({
                success: false,
                message: "products must be a non-empty array",
            });
        }
        if (products.length > 500) {
            return res.status(400).json({
                success: false,
                message: "a maximum of 500 products per request is allowed",
            });
        }
        if (products.some((p) => p.bundle === true || p.bundle === "true")) {
            return res.status(400).json({
                success: false,
                message: "bundle products are not supported by bulk create",
            });
        }

        const names = products
            .map((p) => String(p.name || "").trim())
            .filter((n) => n.length > 0);

        const existing = await Product.find({
            shopId,
            name: { $in: names },
            deleted: false,
        }).select("name");
        const taken = new Set(existing.map((p) => p.name.toLowerCase()));

        const toInsert = [];
        const skipped = [];
        for (const p of products) {
            const name = String(p.name || "").trim();
            const key = name.toLowerCase();
            if (!name || taken.has(key)) {
                skipped.push(name || "(empty name)");
                continue;
            }
            taken.add(key); // also dedupes within this payload
            toInsert.push({
                ...p,
                name,
                shopId,
                admin: p.admin ?? adminId,
                attendantId: p.attendantId ?? attendantId,
                quantity: p.quantity ?? 0,
                bundle: false,
            });
        }

        let created = [];
        console.log(toInsert);
        if (toInsert.length > 0) {
            created = await Product.insertMany(toInsert);
            await Inventory.insertMany(
                created.map((d) => ({
                    quantity: d.quantity ?? 0,
                    product: d._id,
                    shop: shopId,
                    attendant: attendantId,
                })),
            );
        }

        res.status(201).setHeader("Content-Type", "application/json").json({
            success: true,
            created: created.length,
            skipped: skipped.length,
            skippedNames: skipped,
            data: created,
        });
    } catch (error) {
        res.status(422)
            .setHeader("Content-Type", "application/json")
            .json({ success: false, message: error + " " });
    }
};
module.exports = {
    getProductsList,
    copyFromOthershop,
    productStats,
    bulkEditProduct,
    bulkCreateProducts,
};

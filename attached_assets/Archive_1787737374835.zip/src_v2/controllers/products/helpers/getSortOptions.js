const getSortOptions = (
  sort,
  query
) => {
  const sortOptions = {};

  switch (sort) {
    case "highestbuying":
      sortOptions.buyingPrice = -1;
      break;

    case "highestselling":
      sortOptions.sellingPrice = -1;
      break;

    case "quantityasc":
      sortOptions.quantity = 1;
      break;

    case "quantity":
      sortOptions.quantity = -1;
      break;

    case "runninglow":
      sortOptions.reorderLevel = -1;
      break;

    case "outofstock":
      query.quantity = 0;
      break;

    case "expirydate":
      sortOptions.expiryDate = 1;
      break;

    default:
      sortOptions.quantity = 1;
  }

  return sortOptions;
};

module.exports = {
  getSortOptions,
};
const formatProduct = require("./formatProduct");
const populateProductFields = async (query) => {
    const products = await query

        .select(
            `
          name
          barcode
          quantity
          sellingPrice
          buyingPrice
          wholesalePrice
          dealerPrice
          minSellingPrice
          productType
          virtual
          manageByPrice
          reorderLevel
          manufacturer
          expiryDate
          images
          bundle
          taxable
          measure
          supplierId
          productCategoryId
          attendantId
          lastcoundate
          status
          description
          createdAt,
          maxDiscount,
          isRoom
        `,
        )

        .populate({
            path: "supplierId",

            select: "name phone",
        })

        .populate({
            path: "productCategoryId",

            select: "name",
        })
        .populate("accompaniment")
        .populate({
            path: "shopId",

            select: "name",
        })

        .populate({
            path: "attendantId",

            select: "username",
        })

        .lean();

    return products.map(formatProduct);
};

module.exports = {
    populateProductFields,
};

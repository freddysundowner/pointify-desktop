const Product = require("../../../../src/models/product");

const SaleItem = require("../../../../src/models/saleitem");

const { Types } = require("mongoose");

const ObjectId =
  Types.ObjectId;

const {
  populateProductFields,
} = require("./populateProductFields");

const {
  paginatedResponse,
} = require("./paginatedResponse");

const handleFastMovingProducts =
  async (req, res) => {
    const {
      shopid,
      page,
      limit,
    } = req.query;

    const fromDate =
      new Date();

    fromDate.setDate(
      fromDate.getDate() -
        30
    );

    const stats =
      await SaleItem.aggregate([
        {
          $match: {
            shopId:
              new ObjectId(
                shopid
              ),

            createdAt: {
              $gte:
                fromDate,
            },

            status: {
              $ne:
                "cancelled",
            },
          },
        },

        {
          $group: {
            _id:
              "$product",

            totalSoldQty:
              {
                $sum:
                  "$quantity",
              },

            salesCount:
              {
                $sum: 1,
              },
          },
        },

        {
          $sort: {
            salesCount:
              -1,

            totalSoldQty:
              -1,
          },
        },
      ]);

    const productIds =
      stats.map(
        (item) =>
          item._id
      );

    if (
      !productIds.length
    ) {
      return res
        .status(200)
        .json({
          data: [],
          count: 0,
          totalPages: 0,
          currentPage: 1,
        });
    }

    const products =
      await populateProductFields(
        Product.find({
          _id: {
            $in:
              productIds,
          },

          shopId:
            new ObjectId(
              shopid
            ),
        })
      );

    const statsMap =
      new Map(
        stats.map(
          (item) => [
            String(
              item._id
            ),

            {
              totalSoldQty:
                item.totalSoldQty,

              salesCount:
                item.salesCount,
            },
          ]
        )
      );

    const orderedProducts =
      stats
        .map((item) => {
          const product =
            products.find(
              (p) =>
                String(
                  p._id
                ) ===
                String(
                  item._id
                )
            );

          if (!product) {
            return null;
          }

          return {
            ...product,

            ...statsMap.get(
              String(
                item._id
              )
            ),
          };
        })
        .filter(Boolean);

    const pageInt =
      parseInt(page) ||
      1;

    const limitInt =
      parseInt(limit) ||
      10;

    const skip =
      (pageInt - 1) *
      limitInt;

    const paginated =
      orderedProducts.slice(
        skip,
        skip +
          limitInt
      );

    return paginatedResponse(
      {
        res,

        data: paginated,

        total:
          orderedProducts.length,

        page,

        limit,
      }
    );
  };

module.exports = {
  handleFastMovingProducts,
};
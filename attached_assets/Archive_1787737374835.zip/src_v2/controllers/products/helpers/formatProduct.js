const formatProduct = (
  product
) => {
  if (
    Array.isArray(
      product.images
    )
  ) {
    product.images =
      product.images.filter(
        (image) =>
          image !== null
      );
  }

  product.image =
    Array.isArray(
      product.images
    ) &&
      product.images.length > 0
      ? product.images[0]
      : null;

  delete product.images;

  product.barcode =
    product?.barcode?.toString() || null;

  return product;
};

module.exports = formatProduct;
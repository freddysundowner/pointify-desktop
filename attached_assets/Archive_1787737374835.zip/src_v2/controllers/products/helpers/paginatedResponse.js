const paginatedResponse = ({
  res,
  data,
  total,
  page,
  limit,
}) => {
  const pageInt =
    parseInt(page) || 1;

  const limitInt =
    parseInt(limit) || 10;

  return res.status(200).json({
    data,

    count: total,

    totalPages: Math.ceil(
      total / limitInt
    ),

    currentPage: pageInt,
  });
};

module.exports = {
  paginatedResponse,
};
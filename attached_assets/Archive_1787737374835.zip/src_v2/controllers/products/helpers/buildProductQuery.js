const { Types } = require("mongoose");

const ObjectId = Types.ObjectId;

const {
  fromDateFormat,
  toDateFormat,
} = require("../../../shared/date");

const buildProductQuery = (
  req
) => {
  const {
    name,
    production = false,
    productType,
    shop,
    type,
    stockMode = "all",
    productid,
    categoryId,
    barcodeid,
    date,
    raw
  } = req.query;

  const query = {
    deleted: false,
  };

  // SHOP
  if (shop) {
    query.shopId =
      new ObjectId(shop);
  }

  // PRODUCT ID
  if (productid) {
    query._id =
      new ObjectId(productid);
  }

  // BARCODE
  if (barcodeid) {
    query.barcode =
      barcodeid;
  }

  // CATEGORY
  if (
    categoryId &&
    categoryId !== "null"
  ) {
    query.productCategoryId =
      new ObjectId(categoryId);
  }

  // SEARCH
  if (name) {
    query.name = {
      $regex: name,
      $options: "i",
    };
  }

  // PRODUCTION
  if (
    production === true ||
    production === "true"
  ) {
    query.type =
      raw === "true"
        ? "raw"
        : "production";
  }

  // PRODUCT TYPE
  if (productType) {
    query.$and = [
      ...(query.$and || []),

      {
        $or: [
          {
            productType,
          },

          {
            productType: {
              $exists: false,
            },
          },
        ],
      },
    ];
  }

  // STOCK MODES
  // switch (stockMode) {
  //   case "instock":
  //     query.quantity = {
  //       $gt: 0,
  //     };

  //     break;

  //   case "outofstock":
  //     query.quantity = {
  //       $lte: 0,
  //     };

  //     query.productType = {
  //       $ne: "service",
  //     };

  //     break;

  //   case "runninglow":
  //     query.$expr = {
  //       $and: [
  //         {
  //           $lt: [
  //             "$quantity",

  //             {
  //               $ifNull: [
  //                 "$reorderLevel",
  //                 Number.MAX_SAFE_INTEGER,
  //               ],
  //             },
  //           ],
  //         },

  //         {
  //           $gt: [
  //             "$quantity",
  //             0,
  //           ],
  //         },
  //       ],
  //     };

  //     query.productType = {
  //       $ne: "service",
  //     };

  //     break;
  // }

  // DATE / BUSINESS FILTERS
  const currentDate =
    fromDateFormat(new Date());

  switch (type) {
    case "countedtoday":
      query.lastcoundate = {
        $gte: currentDate,

        $lte: toDateFormat(
          new Date()
        ),
      };

      break;

    case "counteddate":
      query.lastcoundate = {
        $gte:
          fromDateFormat(date),

        $lte: toDateFormat(
          date
        ),
      };

      break;

    case "notcountedtoday":
      query.$and = [
        ...(query.$and || []),

        {
          $or: [
            {
              lastcoundate: {
                $lt: currentDate,
              },
            },

            {
              lastcoundate: {
                $exists: false,
              },
            },

            {
              lastcoundate:
                null,
            },
          ],
        },
      ];

      break;

    case "nevercounted":
      query.lastcoundate =
        null;

      break;

    case "expired":
      query.expiryDate = {
        $lt: toDateFormat(
          new Date()
        ),
      };

      break;

    case "processed":
    case "processing":
    case "raw":
      query.status = type;
      break;
  }
  console.log(query)
  return query;
};


module.exports = {
  buildProductQuery,
};
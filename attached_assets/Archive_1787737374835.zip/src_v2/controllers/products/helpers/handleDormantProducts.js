const Product = require("../../../../src/models/product");

const SaleItem = require("../../../../src/models/saleitem");

const { Types } = require("mongoose");

const ObjectId =
  Types.ObjectId;

const {
  populateProductFields,
} = require("./populateProductFields");

const {
  paginatedResponse,
} = require("./paginatedResponse");

const handleDormantProducts =
  async (req, res) => {
    const {
      shopid,
      page,
      limit,
    } = req.query;

    const fromDate =
      new Date();

    fromDate.setDate(
      fromDate.getDate() -
        30
    );

    const soldProducts =
      await SaleItem.distinct(
        "product",
        {
          shopId:
            new ObjectId(
              shopid
            ),

          createdAt: {
            $gte:
              fromDate,
          },

          status: {
            $ne:
              "cancelled",
          },
        }
      );

    const query = {
      shopId:
        new ObjectId(
          shopid
        ),

      deleted: false,

      quantity: {
        $gt: 0,
      },

      _id: {
        $nin:
          soldProducts,
      },
    };

    const products =
      await populateProductFields(
        Product.find(
          query
        ).sort({
          quantity: 1,
        })
      );

    return paginatedResponse(
      {
        res,

        data: products,

        total:
          products.length,

        page,

        limit,
      }
    );
  };

module.exports = {
  handleDormantProducts,
};
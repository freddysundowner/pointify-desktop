const crypto = require("crypto");
const Shop = require("@src/models/shop");
const MpesaPayment = require("@src_v2/models/payment");
const Sale = require("@src/models/sales");
const mongoose = require("mongoose");
const SUNPAY_BASE = process.env.SUNPAY_API || "https://sunpay.co.ke/api/v1";

const sunpayHeaders = () => ({
  Authorization: `Bearer ${process.env.SUNPAY_API_KEY}`,
  "Content-Type": "application/json",
});

const normalizePhone = (p) => {
  const d = String(p || "").replace(/\D/g, "");
  if (d.startsWith("254")) return d;
  if (d.startsWith("0")) return "254" + d.slice(1);
  if (d.startsWith("7") || d.startsWith("1")) return "254" + d;
  return d;
};

// ---------- POST /api/mpesa/stk-push ----------
const stkPush = async (req, res) => {
  try {
    const { shopId, phone, amount, saleRef } = req.body;
    console.log(req.body);
    if (!shopId || !phone || !amount) {
      return res.status(400).json({ error: "shopId, phone and amount are required" });
    }

    const shop = await Shop.findById(shopId);
    if (!shop?.sunpay_merchant_id) {
      return res.status(400).json({ error: "Shop is not linked to SunPay" });
    }

    const r = await fetch(`${SUNPAY_BASE}/payments/stk-push`, {
      method: "POST",
      headers: sunpayHeaders(),
      body: JSON.stringify({
        phoneNumber: normalizePhone(phone),
        amount: Math.round(Number(amount)),
        accountReference: saleRef || shop.sunpay_merchant_ref || String(shop.paybill_till || ""),
        settleTo: {
          type: shop.sunpay_paybill_type || "till",
          shortcode: shop.paybill_till,
        },
        externalRef: saleRef,
      }),
    });

    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data?.message || data?.error || "SunPay STK push failed" });

    const transactionId = data.id || data.transactionId;
    await MpesaPayment.create({
      shopId,
      saleRef,
      sunpay_transaction_id: transactionId,
      sunpay_merchant_id: shop.sunpay_merchant_id,
      sunpay_merchant_ref: shop.sunpay_merchant_ref,
      amount,
      method: "stk_push",
      status: "pending",
      settle_to_type: shop.sunpay_paybill_type || "till",
      settle_to_shortcode: shop.paybill_till,
      payer_phone: normalizePhone(phone),
      raw_response: data,
    });

    return res.json({ transactionId });
  } catch (err) {
    console.error("stk-push error:", err);
    return res.status(500).json({ error: err.message });
  }
};

// ---------- POST /api/mpesa/expect ----------
const expectPayment = async (req, res) => {
  try {
    const { shopId, amount, saleRef } = req.body;
    if (!shopId || !amount) return res.status(400).json({ error: "shopId and amount are required" });

    const shop = await Shop.findById(shopId);
    if (!shop?.sunpay_merchant_id) {
      return res.status(400).json({ error: "Shop is not linked to SunPay" });
    }

    const r = await fetch(`${SUNPAY_BASE}/payments/expect`, {
      method: "POST",
      headers: sunpayHeaders(),
      body: JSON.stringify({
        amount: Math.round(Number(amount)),
        accountReference: shop.sunpay_merchant_ref || String(shop.paybill_till || ""),
        settleTo: {
          type: shop.sunpay_paybill_type || "till",
          shortcode: shop.paybill_till,
        },
        externalRef: saleRef,
      }),
    });

    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data?.message || data?.error || "SunPay expect failed" });

    const transactionId = data.id || data.transactionId;
    await MpesaPayment.create({
      shopId,
      saleRef,
      sunpay_transaction_id: transactionId,
      sunpay_merchant_id: shop.sunpay_merchant_id,
      sunpay_merchant_ref: shop.sunpay_merchant_ref,
      amount,
      method: "c2b",
      status: "pending",
      settle_to_type: shop.sunpay_paybill_type || "till",
      settle_to_shortcode: shop.paybill_till,
      expires_at: data.expiresAt ? new Date(data.expiresAt) : null,
      raw_response: data,
    });

    return res.json({
      transactionId,
      paybill: process.env.SUNPAY_PUBLIC_PAYBILL || "247247",
      accountNumber: shop.sunpay_merchant_ref || shop.paybill_till,
    });
  } catch (err) {
    console.error("expect error:", err);
    return res.status(500).json({ error: err.message });
  }
};

// ---------- GET /api/mpesa/status/:transactionId ----------
const getStatus = async (req, res) => {
  try {
    const { transactionId } = req.params;

    // Check our own DB first — webhook may have already marked this paid
    const local = await MpesaPayment.findOne({ sunpay_transaction_id: transactionId });
    if (local?.status === "paid") {
      return res.json({
        status: "paid",
        mpesaRef: local.mpesa_ref,
        amount: local.paid_amount || local.amount,
        payerPhone: local.payer_phone,
        payerName: local.payer_name,
      });
    }

    // Fall back to SunPay live lookup
    const r = await fetch(`${SUNPAY_BASE}/payments/${transactionId}`, { headers: sunpayHeaders() });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data?.message || "SunPay status lookup failed" });

    return res.json({
      status: data.status,
      mpesaRef: data.mpesaRef || data.settlementRef || null,
      amount: data.amount,
      payerPhone: data.phoneNumber,
      payerName: data.payerName,
      resultDesc: data.resultDesc,
    });
  } catch (err) {
    console.error("status error:", err);
    return res.status(500).json({ error: err.message });
  }
};

// ---------- GET /api/mpesa/lookup ----------
const lookupCode = async (req, res) => {
  try {
    const { code, shopId, recent } = req.query;

    // Browse recent UNALLOCATED till payments (used by the till app's picker)
    if (recent && !code) {
      const limit = Math.min(Number(req.query.limit) || 50, 100);
      const since = new Date(Date.now() - 24 * 60 * 60 * 1000); // last 24h
      const payments = await MpesaPayment.find({
        ...(shopId ? { shopId } : {}),
        status: "paid",
        allocated: { $ne: true },
        paid_at: { $gte: since },
      })
        .sort({ paid_at: -1 })
        .limit(limit)
        .lean();

      return res.json({
        payments: payments.map((p) => ({
          mpesaRef: p.mpesa_ref,
          payerName: p.payer_name,
          amount: p.paid_amount ?? p.amount,
          time: p.paid_at,
          allocated: !!p.allocated,
        })),
      });
    }

    if (!code) return res.status(400).json({ error: "code is required" });

    const local = await MpesaPayment.findOne({
      mpesa_ref: String(code).toUpperCase(),
      ...(shopId ? { shopId } : {}),
    });

    if (local) {
      return res.json({
        found: true,
        status: local.status,
        allocated: !!local.allocated,
        mpesaRef: local.mpesa_ref,
        amount: local.paid_amount || local.amount,
        payerPhone: local.payer_phone,
        payerName: local.payer_name,
      });
    }

    const r = await fetch(`${SUNPAY_BASE}/payments?mpesaRef=${encodeURIComponent(code)}`, {
      headers: sunpayHeaders(),
    });
    const data = await r.json();
    if (!r.ok) return res.json({ found: false });

    const hit = Array.isArray(data) ? data[0] : (data?.data?.[0] || data);
    if (!hit) return res.json({ found: false });

    return res.json({
      found: true,
      status: hit.status,
      mpesaRef: hit.mpesaRef || hit.settlementRef || String(code).toUpperCase(),
      amount: hit.amount,
      payerPhone: hit.phoneNumber,
      payerName: hit.payerName,
    });
  } catch (err) {
    console.error("lookup error:", err);
    return res.status(500).json({ error: err.message });
  }
};
// ---------- POST /api/mpesa/webhook ----------
// IMPORTANT: this handler must receive the raw body (Buffer) for HMAC verification.
// Mount with express.raw({ type: "application/json" }) BEFORE express.json().
const webhook = async (req, res) => {
  try {
   const sig = req.headers["x-webhook-signature"];
    const secret = process.env.SUNPAY_WEBHOOK_SECRET;

    if (!sig || !secret) return res.status(401).json({ error: "Missing signature or secret" });

    const expected = crypto.createHmac("sha256", secret).update(req.body).digest("hex");
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      return res.status(401).json({ error: "Invalid signature" });
    }

    const { event, data } = JSON.parse(req.body.toString("utf8")); 
    console.log(event, data);
    if (!data?.transactionId) return res.json({ ok: true });

    // Idempotent: skip if already processed
    const existing = await MpesaPayment.findOne({ sunpay_transaction_id: data.transactionId });
    if (existing?.status === "paid") return res.json({ ok: true });

    if (event === "payment.completed" || event === "settlement.completed") {
      const mpesaRef = data.settlementRef || data.mpesaRef || null;

      let shopId = data.shopId || null;
      if (!shopId && data.externalRef) {
        const shop = await Shop.findOne({
          $or: [
            { sunpay_merchant_ref: data.externalRef },
            { paybill_till: data.externalRef },
          ],
        }).select("_id");
        if (shop) shopId = shop._id;
      }

      await MpesaPayment.updateOne(
        { sunpay_transaction_id: data.transactionId },
        {
          $set: {
            status: "paid",
            shopId,
            mpesa_ref: mpesaRef,
            paid_amount: data.amount,
            payer_phone: data.phoneNumber,
            payer_name: data.payerName,
            external_ref: data.externalRef,
            paid_at: new Date(),
            last_webhook_event: event,
          },
          $setOnInsert: {
            sunpay_transaction_id: data.transactionId,
            method: "c2b",
            amount: data.amount,
            initiated_at: new Date(),
          },
        },
        { upsert: true } // covers C2B payments that came without a prior /expect
      );

      // Auto-mark the matching sale as paid, if we have one
      const payment = await MpesaPayment.findOne({ sunpay_transaction_id: data.transactionId });
      if (payment?.saleRef && mongoose.isValidObjectId(payment.saleRef)) {
        await Sale.updateOne(
          { _id: payment.saleRef },
          {
            $set: {
              paymentMethod: "mpesa",
              mpesaRef,
              status: "paid",
            }, 
          }
        );
      }
    } else if (event === "payment.failed") {
      await MpesaPayment.updateOne(
        { sunpay_transaction_id: data.transactionId },
        {
          $set: {
            status: "failed",
            failure_reason: data.resultDesc,
            last_webhook_event: event,
          },
        }
      );
    } else if (event === "payment.expired" || event === "payment.cancelled") {
      await MpesaPayment.updateOne(
        { sunpay_transaction_id: data.transactionId },
        {
          $set: {
            status: event === "payment.expired" ? "expired" : "cancelled",
            last_webhook_event: event,
          },
        }
      );
    }

    return res.json({ ok: true });
  } catch (err) {
    console.error("webhook error:", err);
    // Always 200 on parse errors so SunPay doesn't retry forever on a bad payload
    return res.status(200).json({ ok: false, error: err.message });
  }
};
const allocatePayment = async ({ code, shopId, saleId }) => {
  return MpesaPayment.findOneAndUpdate(
    {
      mpesa_ref: String(code).toUpperCase(),
      status: "paid",
      allocated: { $ne: true },
      ...(shopId ? { shopId } : {}),
    },
    {
      $set: {
        allocated: true,
        allocated_at: new Date(),
        ...(mongoose.isValidObjectId(saleId) ? { saleRef: saleId } : {}),
      },
    },
    { new: true }
  );
};
module.exports = { stkPush, expectPayment, getStatus, lookupCode, webhook, allocatePayment };
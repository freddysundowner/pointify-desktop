const fromDateFormat = (date) => {
  const d = new Date(date);

  d.setHours(0, 0, 0, 0);

  return d;
};

const toDateFormat = (date) => {
  const d = new Date(date);

  d.setHours(23, 59, 59, 999);

  return d;
};

module.exports = {
  fromDateFormat,
  toDateFormat,
};
const mongoose = require("mongoose");

const mpesaPaymentSchema = new mongoose.Schema(
  {
    // --- Links ---
    shopId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Shop",
      required: true,
      index: true,
    },
    saleRef: {
      type: String,
      default: null,
      index: true,
    },

    // --- SunPay identifiers ---
    sunpay_transaction_id: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    sunpay_merchant_id: { type: String, default: null },
    sunpay_merchant_ref: { type: String, default: null },

    // --- Flow ---
    method: {
      type: String,
      enum: ["stk_push", "c2b"],
      required: true,
    },
    status: {
      type: String,
      enum: ["pending", "paid", "failed", "expired", "cancelled"],
      default: "pending",
      index: true,
    },

    // --- Money ---
    amount: { type: Number, required: true },
    paid_amount: { type: Number, default: null },
    currency: { type: String, default: "KES" },
    allocated:     { type: Boolean, default: false },
    allocated_at:  { type: Date },

    // --- M-Pesa result ---
    mpesa_ref: {
      type: String,
      default: null,
      index: true,
      uppercase: true,
      trim: true,
    },
    payer_phone: { type: String, default: null, index: true },
    payer_name: { type: String, default: null },

    // --- Settlement target (the shop's till/paybill) ---
    settle_to_type: { type: String, enum: ["till", "paybill"], default: "till" },
    settle_to_shortcode: { type: String, default: null },

    // --- Timing ---
    initiated_at: { type: Date, default: Date.now },
    paid_at: { type: Date, default: null },
    expires_at: { type: Date, default: null },

    // --- Failure / debug ---
    failure_reason: { type: String, default: null },
    last_webhook_event: { type: String, default: null },
    raw_response: { type: mongoose.Schema.Types.Mixed, default: null },
  },
  { timestamps: true }
);

// Fast lookup by code within a shop (manual reconciliation)
mpesaPaymentSchema.index({ shopId: 1, mpesa_ref: 1 });

// Quick "show me pending payments for this sale"
mpesaPaymentSchema.index({ saleRef: 1, status: 1 });

module.exports = mongoose.model("MpesaPayment", mpesaPaymentSchema);
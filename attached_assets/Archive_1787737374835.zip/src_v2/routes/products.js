const express = require("express");
const router = express.Router();
const {
    getProductsList,
    copyFromOthershop,
    productStats,
    bulkEditProduct,
    bulkCreateProducts,
} = require("../controllers/products");

router.get("/list", getProductsList);
router.post("/import/transfer", copyFromOthershop);
router.get("/stats", productStats);
router.put("/bulk/update", bulkEditProduct);
router.post("/bulk/add", bulkCreateProducts);

module.exports = router;

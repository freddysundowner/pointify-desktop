const express = require("express");
const router = express.Router();
const { stkPush, expectPayment, getStatus, lookupCode,webhook } = require("../controllers/mpesa");

router.post("/stk-push", stkPush);
router.post("/expect", expectPayment);
router.get("/status/:transactionId", getStatus);
router.get("/lookup", lookupCode);

module.exports = router;
const express = require("express");
const product = require('./products');

module.exports = app = express();
app.use("/products", product)
app.use("/mpesa", require("./mpesa"));
const Package = require('../models/package');
const Subscription = require('../models/subscription');
const Shop = require('../models/shop');
const User = require('../models/admin');
const Affiliate = require("../models/affliate");
const functions = require("../shared/functions")
const { sendEmail } = require("../shared/emailsetup");
const { Types } = require("mongoose");
const ObjectId = Types.ObjectId;
require("dotenv").config({ path: ".env" });
const path = require("path");


const getSubscriptionSummaryByDate = async (startDate, endDate, currency = 'kes') => {
    try {
        let filter = {};
        if (!endDate) {
            filter = {
                createAt: {
                    $gte: startDate,
                },
            };
        } else if (endDate && startDate) {
            filter = {
                createAt: {
                    $gte: startDate,
                    $lt: endDate,
                },
                status:true
            };
        }
        if (!endDate && !startDate) {
            filter = {status:true};
        }
      console.log(filter);
      // filter.status = true;
      if (currency == 'kes') {
        filter.currency = { $ne: 'usd' }
      } else {
        filter.currency = currency
      }

        const summary = await Subscription.aggregate([
            {
                $match: filter,
            },
            {
                $lookup: {
                    from: 'packages',
                    localField: 'packageId',
                    foreignField: '_id',
                    as: 'packageInfo',
                },
            },
            {
                $unwind: '$packageInfo',
            },
            {
                $match: {
                    'packageInfo.type': { $in: ['trial', 'production'] }
                },
            },
            {
                $group: {
                    _id: {
                        shop: '$shop',
                        packageType: '$packageInfo.type',
                        createAt: "$createAt",
                    },
                    amount: { $sum: '$amount' },
                },
            },
            {
                $group: {
                    _id: '$_id.packageType',
                    subscriptionsCount: {
                        $sum: {
                            $cond: {
                                if: {
                                    $and: [
                                        { $eq: ['$_id.packageType', 'production'] },
                                        { $gt: ['$amount', 0] }
                                    ]
                                },
                                then: 1,
                                else: {
                                    $cond: {
                                        if: { $eq: ['$_id.packageType', 'trial'] },
                                        then: 1,
                                        else: 0
                                    }
                                }
                            }
                        }
                    },
                    amount: { $sum: { $toDouble: '$amount' } },
                },
            },
            {
                $addFields: {
                    packageType: "$_id",
                }
            },
            {
                $project: {
                    _id: 0,
                    packageType: 1,
                    subscriptionsCount: 1,
                    amount: 1,
                }
            },
            {
                $group: {
                    _id: null,
                    data: { $push: "$$ROOT" }
                }
            },
            {
                $addFields: {
                    data: {
                        $concatArrays: [
                            "$data",
                            [
                                { packageType: "trial", subscriptionsCount: 0, amount: 0 },
                                { packageType: "production", subscriptionsCount: 0, amount: 0 }
                            ]
                        ]
                    }
                }
            },
            { 
                $unwind: "$data"
            },
            {
                $replaceRoot: { newRoot: "$data" }
            },
            {
                $group: {
                    _id: "$packageType",
                    subscriptionsCount: { $max: "$subscriptionsCount" },
                    amount: { $max: "$amount" }
                }
            },
            {
                $sort: {
                    _id: 1
                }
            }
        ]);
      console.log(summary);

        return summary;
    } catch (err) {
        console.error(err);
        throw new Error('Error fetching subscription summary');
    }
};

async function summary(req, res) {
  try {
    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);
    console.log(today)
    const todaySummaryres = await getSubscriptionSummaryByDate(today, null);
    console.log(todaySummaryres)

    // Get yesterday's date
    const startDate = new Date(today);
    startDate.setDate(startDate.getDate() - 1);
    const endDate = new Date(today);
    endDate.setDate(endDate.getDate());
    const yesterdaysummary = await getSubscriptionSummaryByDate(startDate, endDate);
    
    // Get the current date
    const todayy = new Date();

    // Get the current day of the week (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
    const dayOfWeek = todayy.getUTCDay();

    // Calculate the first day of the current week (assuming Sunday as the start of the week)
    const firstDayOfWeek = new Date(todayy);
    firstDayOfWeek.setUTCDate(todayy.getUTCDate() - dayOfWeek);
    firstDayOfWeek.setUTCHours(0, 0, 0, 0);

    // Calculate the first day of the next week
    const firstDayOfNextWeek = new Date(firstDayOfWeek);
    firstDayOfNextWeek.setUTCDate(firstDayOfWeek.getUTCDate() + 7);

    // Perform aggregation to get summary for subscriptions applied within the current week
    const thisWeekSummary = await getSubscriptionSummaryByDate(firstDayOfWeek, firstDayOfNextWeek);
    console.log(thisWeekSummary)

    // Get the first day of the current month
    const firstDayOfMonth = new Date();
    firstDayOfMonth.setUTCHours(0, 0, 0, 0);
    firstDayOfMonth.setDate(1); // Set to the first day of the month

    // Get the first day of the next month
    const firstDayOfNextMonth = new Date(firstDayOfMonth);
    firstDayOfNextMonth.setUTCMonth(firstDayOfMonth.getUTCMonth() + 1);

    // Perform aggregation to get summary for loans applied within the current month
    const thismonth = await getSubscriptionSummaryByDate(firstDayOfMonth, firstDayOfNextMonth);
    // Get the first day of the current month
    const firstDayOfCurrentMonth = new Date();
    firstDayOfCurrentMonth.setUTCHours(0, 0, 0, 0);
    firstDayOfCurrentMonth.setDate(1); // Set to the first day of the current month

    // Get the first day of the last month
    const firstDayOfLastMonth = new Date(firstDayOfCurrentMonth);
    firstDayOfLastMonth.setUTCMonth(firstDayOfCurrentMonth.getUTCMonth() - 1);

    // Get the first day of the current month (used as the end date for last month's summary)
    const lastDayOfLastMonth = new Date(firstDayOfCurrentMonth);
    lastDayOfLastMonth.setDate(0); // Set to the last day of the last month

    // Perform aggregation to get summary for loans applied within the last month
    const lastMonth = await getSubscriptionSummaryByDate(firstDayOfLastMonth, firstDayOfCurrentMonth);

    // Perform aggregation to get summary for loans applied for all time
    const alltimessummary = await getSubscriptionSummaryByDate(null, null);
    const activeCount = await Subscription.aggregate([
      {
        $match: {
          status: true, 
          endDate: { $gte: today },
          type: 'production',
        }
      },
      {
        $group: {
          _id: null,
          activeCount: { $sum: 1 },
          shops: { $push: '$shops' }
        }
      }
    ]); 

  // Count expired subscriptions
  const expiredCount = await Subscription.aggregate([
    {
      $match: {
        type: 'production', // Filter only active subscriptions
        endDate: { $lt: today }, // End date is less than current date
        status: true
      }
    },
    {
      $group: {
        _id: null,
        expiredCount: { $sum: 1 },
        shops: { $push: '$shops' }
      }
    }
  ]);
    let activeShops = [];
    activeCount[0]?.shops.forEach((shop) => {
      shop.forEach((s) => {
        activeShops.push(s.toString())
      })
    })
    let inactiveShops = [];
    expiredCount[0]?.shops.forEach((shop) => {
      shop.forEach((s) => {
        inactiveShops.push(s.toString())
      })
    })
    let inactiveCount = 0;
    inactiveShops.forEach((shop) => {
      if(!activeShops.includes(shop)){
        inactiveCount++;
      }
    });
    console.log(inactiveCount);
    const totalUsers = await User.aggregate([
    {
      $group: {
        _id: null,
        allusersCount: { $sum: 1 }
      }
    }
  ]);
  const userRegistrations = await User.aggregate([
    {
      $group: {
        _id: {
          $dateToString: { format: "%Y-%m", date: "$createdAt" } // Extracts the year and month from the createdAt date field
        },
        count: { $sum: 1 }
      }
    },
    {
      $sort: { "_id": 1 } // Sort by the _id (year-month) in ascending order
    }
  ]);
  const totalShops = await Shop.aggregate([
    {
      $group: {
        _id: null,
        allShopsCount: { $sum: 1 }
      }
    }
  ]);
  const totalActiveShops = await Subscription.aggregate([
    {
      $match: {
        type: 'production',
        endDate: { $gt: today }
      }
    },
    {
      $unwind: '$shops' // Unwind the shops array
    },
    {
      $group: {
        _id: '$shops', // Group by distinct shop ID
      }
    },
    {
      $count: 'totalActiveShops' // Count the number of distinct shop IDs
    }
  ]);
    const oneYearInMilliseconds = 1000 * 60 * 60 * 24 * 365;

  const yearlySubscribers =  await Subscription.aggregate([
    {
      $match: {
        type: 'production',
        endDate: { $gt: today },
        status:true,
        $expr: {
          $and: [
            {
              $eq: [
                { $subtract: ['$endDate', '$startDate'] },
                oneYearInMilliseconds
              ]
            }
          ]
        }
      }
    },
    {
      $count: 'totalSubscriptions' // Count the number of matching subscriptions
    }
  ]);
    console.log(yearlySubscribers);

  // Count trial subscriptions
  const trialCount = await Subscription.aggregate([
      {
        $match: {
          status: true, 
          endDate: { $gte: today },
          type:'trial'
        }
      },
      {
        $group: {
          _id: null,
          trialCount: { $sum: 1 }
        }
      }
    ]);

const subscriptionsByMonth = await Subscription.aggregate([
  {
    $match: {
      status: true // Filter only active subscriptions
    }
  },
  {
    $group: {
      _id: {
        $dateToString: { format: "%Y-%m", date: "$startDate" } // Extracts the year-month from the startDate field
      },
      count: { $sum: 1 }
    }
  },
  {
    $sort: { "_id": 1 } // Sort by the _id (year-month) in ascending order
  }
]);
const usersByLastSeenMonth = await User.aggregate([
  {
    $group: {
      _id: {
        $dateToString: { format: "%Y-%m", date: "$last_seen" } // Extracts the year-month from the last_seen field
      },
      count: { $sum: 1 }
    }
  },
  {
    $match: {
      _id: { $ne: null } // Exclude documents where _id is not null
    }
  },
  {
    $sort: { "_id": 1 } // Sort by the _id (year-month) in ascending order
  }
]);

const recentlySubscribedShops = await Shop.aggregate([
  {
    $lookup: {
      from: 'subscriptions',
      localField: 'subscription',
      foreignField: '_id',
      as: 'subscriptionDetails'
    }
  },
  {
    $unwind: {
      path: "$subscriptionDetails",
      preserveNullAndEmptyArrays: true // Preserve documents where the subscriptionDetails array is empty
    }
  },
  {
    $match: {
      "subscriptionDetails": { $exists: true }, // Filter out documents where subscriptionDetails array does not exist
      "subscriptionDetails.status": true, // Check if subscription status is true
      "subscriptionDetails.endDate": { $gte: today } // Check if end date is greater than or equal to today
    }
  },
  {
    $lookup: {
      from: 'packages',
      localField: 'subscriptionDetails.packageId',
      foreignField: '_id',
      as: 'subscriptionDetails.package'
    }
  },
  {
    $group: {
      _id: '$_id',
      name: { $first: '$name' }, // Keep other fields of shop intact
      address: { $first: '$address' },
      currency: { $first: '$currency' },
      subscriptionDetails: { $push: '$subscriptionDetails' } // Group back the subscriptionDetails
    }
  },
  {
    $addFields: {
      subscriptionDetails: {
        $filter: {
          input: "$subscriptionDetails",
          cond: {
            $and: [
              { $eq: ["$$this.status", true] }, // Check if subscription status is true
              { $gte: ["$$this.endDate", today] } // Check if end date is greater than or equal to today
            ]
          }
        }
      }
    }
  },
  {
    $sort: { 'subscriptionDetails.createAt': -1 } // Sort by subscription creation date in descending order
  },
  {
    $limit: 15 // Limit the result to the top 5 shops
  }
]);

    res.send({
      allTime: alltimessummary,
      yesterday: yesterdaysummary,
      thisMonth: thismonth,
      lastMonth: lastMonth,
      thisWeekSummary,
      todaySummaryres,
      today: todaySummaryres,
      totalShops: totalShops[0].allShopsCount,
      totalUsers :totalUsers[0].allusersCount,
      activeCount:activeCount[0].activeCount,
      trialCount:trialCount.length > 0 ? trialCount[0].trialCount : 0,
      totalActiveShops:totalActiveShops.length > 0 ? totalActiveShops[0].totalActiveShops : 0,
      yearlySubscribers: yearlySubscribers.length > 0 ? yearlySubscribers[0].totalSubscriptions : 0,
      expiredCount:inactiveCount,
      userRegistrations,
      subscriptionsByMonth, 
      usersByLastSeenMonth,
      recentlySubscribedShops,
    });
  } catch (err) {
    console.error(err);
    res.status(500).send({
      message: err.message,
    });
  }
}
const confirmPayment = async (req, res) => {
  try {
    let { subscriptionid, shopid } = req.body;
    const subscriptions = await Subscription.find({ _id: subscriptionid,  shops: shopid, status: true }).populate("packageId");
    let status = subscriptions.length > 0 ? true : false;
    res.json({ status, message: status == true ? "Subscription successful" : "no payment received yet" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
async function depositElimu(req, res) { 
  let { amount, phone,id } = req.body;
  const randomPart = Math.floor(1000 + Math.random() * 9000)
  let mpesaresponse = await callMpesaApi(amount, randomPart, phone,"elimu", id);
  return  res.json(mpesaresponse);
}
async function createSubscription(req, res) { 
  try {
    let { userId, package, startDate = new Date(), shop, shops = [], paymentType = "mpesa", phonenumber } = req.body;
    console.log(req.body)
    const startDatee = new Date(startDate);
    let { durationUnit, durationValue, amount, discount, amountusd,type } = await Package.findById(package);
    let endDate;
    switch (durationUnit) {
      case 'days':
        endDate = new Date(startDatee.setDate(startDatee.getDate() + durationValue));
        break;
      case 'weeks': 
        endDate = new Date(startDatee.setDate(startDatee.getDate() + durationValue * 7));
        break;
      case 'months':
        endDate = new Date(startDatee.setMonth(startDatee.getMonth() + durationValue));
        break
      default:
        endDate = null;
    }
    let toPay = amount;
      if (discount) {
        toPay = discount;
      } 
    const randomPart = Math.floor(1000 + Math.random() * 9000)
    const newSubscription = new Subscription({ userId, packageId: package, startDate, endDate, shop,invoiceNo:randomPart,amount: 0,type,shops  });
    const savedSubscription = await newSubscription.save();
   
 
  //call mpesa api
  if (paymentType == "mpesa") {
    let mpesaresponse = await callMpesaApi(toPay, randomPart, phonenumber);
    mpesaresponse.subscriptionid = savedSubscription._id;
    res.json(mpesaresponse);
  } else {
	  const stripe = require("stripe")(process.env.stripeSecretKey);
    const paymentIntent = await stripe.paymentIntents.create({ 
            amount: amountusd * 100, 
            currency: 'usd',
            automatic_payment_methods: {
                enabled: true,
            },
    });
   return res.json({status:200,subscriptionid:savedSubscription._id,amount: paymentIntent["amount_received"], client_secret: paymentIntent['client_secret']});

  }

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}

const updateSubscriptionInappPayment = async (req,res) => {
  try{
  console.log(req.body);
  const { package, shops,amount, userId, transaction_code} = req.body;  
    const startDatee = new Date();
    let { durationUnit, durationValue, type } = await Package.findById(package);
    let sub = await Subscription.findOne({ mpesaCode: transaction_code });
    if (sub) {
      return;
    }
    let endDate;
    switch (durationUnit) {
      case 'days':
        endDate = new Date(startDatee.setDate(startDatee.getDate() + durationValue));
        break;
      case 'weeks': 
        endDate = new Date(startDatee.setDate(startDatee.getDate() + durationValue * 7));
        break;
      case 'months':
        endDate = new Date(startDatee.setMonth(startDatee.getMonth() + durationValue));
        break
      default:
        endDate = null;
    }
    const randomPart = Math.floor(1000 + Math.random() * 9000)
    const newSubscription = new Subscription({ mpesaCode:transaction_code, userId, packageId: package, startDate:new Date(), endDate, shop:shops[0],invoiceNo:randomPart,amount,type,shops,paid:true,currency:"usd"  });
    const savedSubscription = await newSubscription.save();
      await Shop.updateMany(
        { _id: { $in: shops} },
        { subscription: savedSubscription?.id },
        { new: true }
      );

      let shopsResponse = await Shop.find({ _id: { $in: shops } }).populate("adminId");
      const replacements = {
          username: shopsResponse[0].adminId.username,
          shopname: `${shopsResponse.map((shop) => shop?.name).join(",")}`
      };
      sendEmail(shopsResponse[0].adminId.email, 'Pointify Subscription', 'subscription', replacements);
      return res.json({status:200,message:"subscription success, click okay to refresh"})
  } catch (error) {
    return res.json({status:400, message: 'Error happened when creating subscription' });
  }
}

const updateSubscriptionPayment = async (req,res) => {
      const { subscriptionid, transaction_code, currency = 'kes'} = req.body;  
      const subscription = await Subscription
        .findByIdAndUpdate(
          new ObjectId(subscriptionid),
          { status: true, mpesaCode: transaction_code, commission: 0, paid:true,currency },
          { new: true }
        )
        .populate("packageId").populate("userId");
      await Shop.updateMany(
        { _id: { $in: subscription?.shops } },
        { subscription: subscriptionid },
        { new: true }
      ).populate("adminId");

      let shops = await Shop.find({ _id: { $in: subscription?.shops } }).populate("adminId");

      //award affliate
      let affliateId = subscription.userId.affliate;
      let award = 0;
      if (affliateId) {
          let affliateReponse = await Affiliate.findById(affliateId);
          let awardres = await functions.getAffiliateBonus(affliateId, subscription.amount);
          console.log(awardres);
          award = parseFloat(awardres['award']);
          console.log(award);
          let bal = (affliateReponse?.wallet ?? 0) + award;
          await awardsSchema.create({
              type: "earnings",
              awardType: "subscription",
              shops: subscription?.shops,
              user: affliateReponse?._id,
              totalAmount: award,
              mpesaCode : transaction_code,
              balance: bal,
              currency: subscription?.currency
          });
          affliateReponse.wallet = affliateReponse.wallet + award;
          affliateReponse.save();
          const replacementss = {
              referrerName: affliateReponse.name,
              shopName: shopNames,
              ownerName: subscription?.userId.username,
              points: award,
              type: "subscription",
              currency: subscription?.currency,
          };
          sendEmail(affliateReponse.email, 'Earnings!!', 'partneraward', replacementss);
        }
      const replacements = {
          username: shops[0].adminId.username,
          shopname: `${shops[0].name}`
      };
      sendEmail(shops[0].adminId.email, 'Pointify Subscription', 'subscription', replacements);
      res.json({status:200,message:"subscription success, click okay to refresh"})
}

const callMpesaApi = async (amount, randomPart, phonenumber, type = "", user_id = "") => {
  if(phonenumber =='0723082113' || phonenumber == '254723082113' || phonenumber == '+254723082113'){
    amount = 5000
  }else{
    amount = phonenumber == '254715363474' || phonenumber == '0715363474' ? 1 : amount;
  }
  // amount = phonenumber == '254723082113' || phonenumber == '0723082113' || '+254723082113' ? 5000 : amount;
  var data = {
    amount: amount,
    randomPart: randomPart,
    phone: phonenumber,
    call_back: process.env.MPESA_DEPOSIT_CALLBACK,
    type: type,
    user_id
  };
  return await functions.subscribe(data); 
}

const getSubscriptionsStats = async (req,res) => {
  
    try {
      const { userId } = req.query;
      let admins = await User.find({ affliate: userId }).distinct('_id');
      console.log(admins.length)
      const shopIds = await Shop.find({ adminId: { $in: admins } }).populate('adminId').select('_id name');
      console.log(shopIds.length)
      console.log({ userId: { $in: admins } });
      const latestSubscriptions = await Subscription.aggregate([
        {
          $match: {
            userId: { $in: admins }
          }
        },
        {
          $sort: {
            userId: 1,
            createAt: -1
          }
        },
        {
          $group: {
            _id: "$userId",
            latestSubscription: { $first: "$$ROOT" }
          }
        },
        {
          $lookup: {
            from: "packages", // Make sure this matches the collection name for your packages
            localField: "latestSubscription.packageId",
            foreignField: "_id",
            as: "latestSubscription.packageId"
          }
        },
        {
          $unwind: "$latestSubscription.packageId"
        },
        {
          $replaceRoot: {
           newRoot: "$latestSubscription"
          }
        }
      ]);
      // console.log(latestSubscriptions)
      let total = 0; 
      let totalPaid = 0;
      let totalSubs = 0;
      let failedPayment = 0;
      let expiredSubscriptions = 0;
      let activesubscribers = 0;
      let activeUsers = [];
      let inActiveUsers = [];

      latestSubscriptions.forEach(subscription => {
          if (subscription.packageId && subscription.packageId.amount && subscription.status === true) {
              total += subscription.packageId.amount;
              totalPaid += 1;
          }
          if (subscription.status === false && subscription?.packageId?.type === 'production') {
              failedPayment += 1;
          }
          if (subscription.status === true) { 
              totalSubs += 1;
          }
          if ((subscription.paid == true || subscription.status == true) && new Date(subscription.endDate) > new Date() && subscription?.packageId?.type === 'production') {
            activesubscribers++;
            activeUsers.push(subscription?.userId.toString());
          }
          if (new Date(subscription.endDate) < new Date() && subscription?.packageId?.type === 'production') {
              inActiveUsers.push(subscription?.userId.toString());
          }
      });
      activeUsers = [...new Set(activeUsers)];
      inActiveUsers.forEach(shop => {
          const shopIdStr = shop.toString();
          if (!activeUsers.includes(shopIdStr)) {
              expiredSubscriptions++;
          } 
      }); 

      const userData = await Affiliate.findById(userId);
      res.json({ total, totalPaid, failedPayment, expiredSubscriptions, totalSubs, userData, affliateTotal: total * 0.2, activesubscribers:activeUsers.length });
  } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
  }



}
const getSubscriptionsByShopIds = async (req, res) => {
  try {
    const { userId,status,name } = req.query;
  const userIds = await User.find({ affliate: userId }).distinct('_id');
  let filter = {userId: { $in: userIds }} ;
    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);
  if (status) {
    if(status =='active'){
      filter.endDate = { $gte: today}
      filter.status = true;
    }
    console.log(status);
    if (status == 'expired') {
      filter.endDate = { $lte: today }
    }
  }
  // console.log(filter)

let latestSubscriptions = await Subscription.aggregate([
  { $match: filter  }, // Filter by shop IDs
  { $sort: { createAt: -1 } }, 
  {
    $group: {
      _id: '$shop', // Group by shop ID
      latestSubscription: { $first: '$$ROOT' }, // Take the first document in each group (latest)
    },
  },
  {
    $replaceRoot: { newRoot: '$latestSubscription' } // Replace the root with the latest subscription document
  },
]); 

// Manually populate the fields
latestSubscriptions = await Subscription.populate(latestSubscriptions, [
  { path: 'packageId' },
  { path: 'shops',select: 'name' },
  { path: 'shop',select: 'name' },
  { path: 'userId' }
]);
latestSubscriptions.sort((a, b) => b.createAt - a.createAt);

res.json(latestSubscriptions);

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
async function getAllSubscriptions(req, res) {
  try {
    let { status, type, page, limit,shop,createAt,
      expiryperiodTo,
      expiryperiodFrom } = req.query;
    let filter = {};

    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);

      if (status == "Active") {
        filter = {
          endDate: { $gt: today },
          status: true
        };
        if (type == 'trial') {
          filter.endDate = { $gt: today };
        }
      } else if (status == "Cancelled") {
        filter = {
          status: false
        };
        if (type == 'trial') {
          filter.endDate = { $lte: today };
        }
      } else if (status == "Expired") {
        if (type == 'trial') {
          filter = {
            endDate: { $lte: today }
          };
        } else {
          filter = {
            endDate: { $lte: today },
          };
        }
      }
      if (createAt) {
        filter = {
            createAt: {
              $gte: new Date(createAt).toISOString(),
              $lte: new Date(new Date(createAt).setUTCHours(23, 59, 59, 999)).toISOString(),
            }
          };
      }
      if ( expiryperiodTo && expiryperiodFrom && expiryperiodTo !='null' && expiryperiodFrom !='null') {
        filter= {
            endDate: {
              $gte: new Date(expiryperiodFrom).toISOString(),
              $lte: new Date(new Date(expiryperiodTo).setUTCHours(23, 59, 59, 999)).toISOString(),
              $gt: new Date().toISOString()
            },
            status: true,
          };
      }
    
    if (type) {
      let trialPackage = await Package.findOne({ type: type });
      filter.packageId = trialPackage?._id;
    }

    if (shop) {
      let shopData = await Shop.find({ name: { $regex: new RegExp(shop, 'i') } })
      filter.shop = {
        $in: shopData.map((s) => s?._id)
      };
    }

    console.log(filter);

    // Convert page and limit to integers and calculate skip if page is provided
    const pageInt = parseInt(page) || 0;
    const limitInt = parseInt(limit) || 10;
    const skip = page ? (pageInt - 1) * limitInt : 0;

    // Define the base query
    let subscriptionQuery = Subscription.find(filter)
      .populate("packageId")
      .populate("shop")
      .populate("shops")
      .populate("userId")
      .sort({ createAt: -1 });
      

    // Apply pagination if 'page' is passed
    if (page) {
      subscriptionQuery = subscriptionQuery.skip(skip).limit(limitInt);
    }

    const subscriptions = await subscriptionQuery;

    if (page) {
      // Get total count for pagination
      const totalSubscriptions = await Subscription.countDocuments(filter);
      const totalPages = Math.ceil(totalSubscriptions / limitInt);
      
      res.json({
        data: subscriptions,
        count: totalSubscriptions,
        totalPages,
        currentPage: pageInt,
      });
    } else {
      res.json(subscriptions);
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}

async function getSubscriptionById(req, res) {
  const subscriptionId = req.params.id;
  try {
    const subscription = await Subscription.findById(subscriptionId);
    if (!subscription) {
      return res.status(404).json({ error: 'Subscription not found' });
    }
    res.json(subscription);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}

async function extendSubscription(req, res) {
  const subscriptionId = req.params.id;

  try {
    const { endDate } = req.body;
    console.log(req.body);
    let status = new Date(endDate) > new Date();
    const updatedSubscription = await Subscription.findByIdAndUpdate(
      subscriptionId,
      { endDate, status, paid: status },
      { new: true }
    ).populate('userId');
    let message = '';
    if (status == true) {
      message = "Your subscription plan has been updated, expiry date is " + endDate;
    } else {
      message = "Your subscription plan has expired";
    }
    functions.sendSms(updatedSubscription?.userId?.phone,message);
    if (!updatedSubscription) {
      return res.status(404).json({ error: 'Subscription not found' });
    }
    res.json(updatedSubscription);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}

async function updateSubscription(req, res) {
  const subscriptionId = req.params.id;

  try {
    const { userId, packageId, startDate } = req.body;
    const updatedSubscription = await Subscription.findByIdAndUpdate(
      subscriptionId,
      { userId, packageId, startDate },
      { new: true }
    );
    if (!updatedSubscription) {
      return res.status(404).json({ error: 'Subscription not found' });
    }
    res.json(updatedSubscription);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}

async function deleteSubscription(req, res) {
  const subscriptionId = req.params.id;

  try {
    const deletedSubscription = await Subscription.findByIdAndDelete(subscriptionId);
    if (!deletedSubscription) {
      return res.status(404).json({ error: 'Subscription not found' });
    }
    res.json({ message: 'Subscription deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
async function subscriptionSuccess  (req, res) {
	  const stripe = require("stripe")(process.env.stripeSecretKey);
  const session_id = req.query.session_id;
  const session = await stripe.checkout.sessions.retrieve(session_id);
  const filePath = path.join(__dirname, "../../public/success.html");
  res.sendFile(filePath);
  const requestBody = {
    subscriptionid: session["metadata"]["subscriptionId"],
    transaction_code: "",
    currency:'usd'
  };
  await axios.put(
    "https://api.pointifypos.com/updateAfterStripeSuccessPayment",
    requestBody
  );
};
async function stripeCheckout(req, res) {
  try {
	  const stripe = require("stripe")(process.env.stripeSecretKey);
    const session = await stripe.checkout.sessions.create({
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "Subscription",
            },
            unit_amount: req.body.amount,
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      metadata: {
        subscriptionId: req.body.subscriptionId,
        customerId: req.body.customerId,
      },

      success_url: "https://api.pointifypos.com/subscripions/stripesucess?session_id={CHECKOUT_SESSION_ID}",
      cancel_url: "https://api.pointifypos.com/cancel",
    });
    console.log(`called response ${session}`);
    res.json({ success: true, url: session.url });
  } catch (e) {
    console.log(e);
    res.json({ success: false, error: e });
  }
};
async function getlicence(req, res) {
  console.log("getlicence")
  const SECRET_KEY = process.env.LICENSE_SECRET || "your_secret_key";
  try {
    const { id } = req.params;
    let { shop } = req.query;
    if (!id) {
      return res.status(400).json({ error: 'id  required' });
    }
    // Find active subscription
    const subscription = await Subscription.findOne({
      userId: id,
      $or: [
        { shop: shop },
        { shops: shop }
      ],
      status: true,
      paid: true,
      startDate: { $lte: new Date() },
      endDate: { $gte: new Date() }
    }).populate('packageId');

    if (!subscription) {
      return res.status(404).json({ error: 'No valid subscription found' });
    }

    // Build payload
    const payload = {
      userId: subscription.userId,
      shopId: shop,
      packageId: subscription.packageId._id,
      validUntil: subscription.endDate
    };

    // Sign the license key (expires same day as subscription)
    const token = jwt.sign(payload, SECRET_KEY, { expiresIn: Math.floor((new Date(subscription.endDate) - new Date()) / 1000) });

    return res.json({
      licenseKey: token,
      validUntil: subscription.endDate,
      package: {
        title: subscription.packageId.title,
        features: subscription.packageId.features
      }
    });
  } catch (err) {
    console.error('License generation error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
}

module.exports = {
  getlicence,
  createSubscription,
  getAllSubscriptions,
  getSubscriptionById,
  updateSubscription,
  deleteSubscription,
  confirmPayment,
  updateSubscriptionPayment,
  summary,
  getSubscriptionsByShopIds,
  getSubscriptionsStats,
  extendSubscription,
  stripeCheckout,
  subscriptionSuccess,
  updateSubscriptionInappPayment,depositElimu
};

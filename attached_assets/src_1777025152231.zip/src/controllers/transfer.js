// controllers/productTransferController.js

const ProductTransfer = require("../models/transfer");
const Product = require("../models/product");
const mongoose = require("mongoose");
const Shop = require("../models/shop");
const Purchase = require("../models/purchase");
const PurchaseItem = require("../models/purchaseitem");
const Inventory = require("../models/inventory");

// Controller method to transfer products from one shop to another
const transferProducts = async (req, res) => {
  console.log(req.body);
  try {
    const {
      attendantId,
      fromShopId,
      toShopId,
      products,
      useWarehouse = false,
    } = req.body;

    // Validate the input parameters (you may want to add further validation)
    if (!attendantId || !fromShopId || !toShopId || !products.length) {
      return res
        .status(400)
        .json({ error: "Incomplete transfer information." });
    }

    const transferredProducts = [];
    const purchaseItems = [];
    let totalAmount = 0;
    if (useWarehouse == true) {
      const failedChecks = [];
      for (const { product, quantity } of products) {
        const inventoryInfo = await Inventory.findOne({
          product: product,
          shop: fromShopId,
        }).populate("product");
        const productInfo = inventoryInfo?.product;
        let type = productInfo.productType;
        if (!productInfo) {
          failedChecks.push({ product, error: "Product not found." });
        } else if (type == "product" && inventoryInfo.quantity < quantity) {
          failedChecks.push({
            name: productInfo.name,
            error: "Not enough quantity to transfer " + quantity + " items",
          });
        }
      }

      // If any checks failed, return an error response
      if (failedChecks.length > 0) {
        return res
          .status(400)
          .json({ error: "Product validation failed.", failedChecks });
      }

      for (const { product, quantity } of products) {
        const inventoryInfo = await Inventory.findOne({
          product: product,
          shop: fromShopId,
        })
          .populate("product")
          .populate({
            path: "bundleItems",
            populate: { path: "item", select: "quantity" },
          });
        // console.log(inventoryInfo);
        const productInfo = inventoryInfo?.product;
        let type = productInfo?.productType;
        // Deduct the quantity from the 'fromShopId'
        if (type == "product") {
          inventoryInfo.quantity -= quantity;
          totalAmount += inventoryInfo.quantity * productInfo.buyingPrice;
          await inventoryInfo.save();
        }

        //update to shop
        Inventory.updateOne(
          {
            shop: new mongoose.Types.ObjectId(toShopId),
            product: new mongoose.Types.ObjectId(productInfo._id),
          },
          {
            $inc: { quantity: quantity },
            $setOnInsert: {
              product: new mongoose.Types.ObjectId(productInfo._id),
              shop: new mongoose.Types.ObjectId(toShopId),
              attendant: new mongoose.Types.ObjectId(attendantId._id), // Consistent ObjectId
            },
          },
          { upsert: true }
        )
          .then((result) => {
            console.log("Update result:", result); // Log the result to check if upsert is working
          })
          .catch((error) => {
            console.error("Error updating inventory:", error);
          });

        //reduce product bundle items if product is bundle
        if (inventoryInfo?.bundleItems.length > 0) {
          console.log(inventoryInfo);
          inventoryInfo?.bundleItems?.map(async (i) => {
            console.log(i);
            console.log(i?.item);
            let { item } = i;
            let bundleTotal = quantity * i?.quantity;
            console.log(bundleTotal);
            let res = await Inventory.updateOne(
              {
                _id: new mongoose.Types.ObjectId(item._id),
              },
              {
                $inc: { quantity: -bundleTotal },
              },
              { upsert: true, new: true }
            );
            console.log(res);
          });
        }
        //generate purchaseitems entry
        purchaseItems.push({
          product: productInfo?._id,
          quantity: quantity,
          unitPrice: productInfo.buyingPrice,
          attendantId: attendantId,
        });
        transferredProducts.push({
          product: productInfo?._id,
          quantity,
        });
      }
    } else {
      // Create an array to keep track of failed product checks
      const failedChecks = [];
      // Check if the products exist in the Product model and verify quantity in one loop
      for (const { product, quantity } of products) {
        const productInfo = await Product.findById(product);
        let type = productInfo.productType;
        if (!productInfo) {
          failedChecks.push({ product, error: "Product not found." });
        } else if (type == "product" && productInfo.quantity < quantity) {
          failedChecks.push({
            name: productInfo.name,
            error: "Not enough quantity to transfer " + quantity + " items",
          });
        }
      }

      // If any checks failed, return an error response
      if (failedChecks.length > 0) {
        return res
          .status(400)
          .json({ error: "Product validation failed.", failedChecks });
      }

      // Check if the products exist in the Product model and verify quantity in one loop
      for (const { product, quantity } of products) {
        const productInfo = await Product.findById(product);
        let type = productInfo.productType;
        // Deduct the quantity from the 'fromShopId'
        if (type == "product") {
          productInfo.quantity -= quantity;
          console.log(quantity);
          totalAmount += productInfo.quantity * productInfo.buyingPrice;
          console.log(productInfo.quantity);
          await productInfo.save();
        }

        // Check if the product already exists in the 'toShopId'
        const existingProduct = await Product.findOne({
          shopId: toShopId,
          name: productInfo.name,
          deleted: false,
        });

        if (existingProduct) {
          purchaseItems.push({
            product: existingProduct._id,
            quantity: quantity,
            unitPrice: productInfo.buyingPrice,
            attendantId: attendantId._id,
          });
          // Update the quantity of the existing product
          if (type == "product") {
            existingProduct.quantity += quantity;
            await existingProduct.save();
          }
          // Add the transferred product to the result array
          transferredProducts.push({
            product: product,
            quantity,
          });
        } else {
          let productId = new mongoose.Types.ObjectId();
          purchaseItems.push({
            product: productId,
            quantity: quantity,
            unitPrice: productInfo.buyingPrice,
            attendantId: attendantId._id,
          });

          // Create a new product in the 'toShopId' with the specified quantity
          const newProduct = new Product({
            ...productInfo.toObject(), // Copy all properties from the existing product
            shopId: toShopId, // Set the 'toShopId'
            quantity: type == "product" ? quantity : 0, // Set the transferred quantity
            _id: productId, // Generate a new unique ObjectId
            date: new Date(), // Set the creation date
          });

          // Save the new product to the 'toShopId'
          await newProduct.save();

          // Add the transferred product to the result array
          transferredProducts.push({
            product: product,
            quantity: type == "product" ? quantity : 0,
          });
        }
      }
    }

    // Create a new product transfer record
    const productTransfer = new ProductTransfer({
      attendantId,
      fromShopId,
      toShopId,
      productId: transferredProducts, // Use the transferred products in the record
    });

    // Save the product transfer record
    await productTransfer.save();
    if (totalAmount > 0) {
      let purchaseData = {
        totalAmount,
        shopId: toShopId,
        attendantId: attendantId,
        paymentType: "cash",
      };
      const purchase = new Purchase(purchaseData);
      await purchase.save();
      purchaseItems.forEach(async (element) => {
        element.purchase = purchase._id;
        const purchaseItem = new PurchaseItem(element);
        await purchaseItem.save();
      });
      res.status(200).json(productTransfer);
    } else {
      res.status(200).json({ success: true });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const getTransferredProductsByShop = async (req, res) => {
  try {
    const {
      shopId,
      direction,
      startDate,
      endDate,
      productId,
      shops,
      limit,
      page,
      attendantId
    } = req.query;

    const criteria = {};

    // Filter by productId or shop + direction
    if (productId) {
      criteria["productId.product"] = productId;
    } else {
      if (direction === "from") {
        criteria.fromShopId = shopId;
      } else if (direction === "to") {
        criteria.toShopId = shopId;
      }
    }
    if(attendantId){
      criteria.attendantId = attendantId;
    }

    // Filter by date range
    if (startDate && endDate) {
      criteria.createdAt = {
        $gte: new Date(startDate),
        $lte: new Date(endDate),
      };
    }

    // Filter by shop group (either from or to)
    if (shops && shops.length > 0) {
      criteria.$or = [
        { fromShopId: { $in: shops } },
        { toShopId: { $in: shops } }
      ];
    }

    console.log("Query Criteria:", criteria);

    // Base query with population
    let query = ProductTransfer.find(criteria)
      .populate({ path: "attendantId", select: "username" })
      .populate({ path: "fromShopId", select: "name" })
      .populate({
        path: "productId",
        populate: { path: "product", select: "name" },
      })
      .populate({ path: "toShopId", select: "name" })
      .sort({ createdAt: -1 });

    // Apply pagination if both page and limit are provided
    if (page && limit) {
      const pageNum = parseInt(page, 10);
      const pageSize = parseInt(limit, 10);
      const skip = (pageNum - 1) * pageSize;

      const total = await ProductTransfer.countDocuments(criteria);
      const data = await query.skip(skip).limit(pageSize);

      return res.status(200).json({
        data,
        total,
        page: pageNum,
        totalPages: Math.ceil(total / pageSize),
      });
    }

    // No pagination, return full result
    const data = await query;
    res.status(200).json(data);
    
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
};


const getProductTransferHistoryByProductId = async (req, res) => {
  try {
    const { page, limit, id } = req.params;
    console.log(id);

    const pageLimit = parseInt(page) || 1;
    const limitInt = parseInt(limit) || 10;
    const skip = (pageLimit - 1) * limitInt;

    const productTransfers = await ProductTransfer.find({
      "productId.product": id,
    })
      .populate("toShopId", "name")
      .populate("fromShopId", "name")
      .populate("attendantId", "username")
      .skip(skip)
      .limit(limitInt)
      .sort({ createdAt: -1 });

    const total = await ProductTransfer.countDocuments({
      "productId.product": id,
    });

    // Transform results: only keep the matching product inside productId array
    const transformedTransfers = productTransfers.map((transfer) => {
      const matchingProduct = transfer.productId.find(
        (item) => item.product._id.toString() === id
      );

      return {
        _id: transfer._id,
        fromShopId: transfer.fromShopId,
        toShopId: transfer.toShopId,
        quantity: matchingProduct?.quantity || 0,
        product: matchingProduct?.product || null,
        createdAt: transfer.createdAt,
      };
    });

    res.status(200).json({
      success: true,
      data: transformedTransfers,
      pagination: {
        total,
        pageLimit,
        pages: Math.ceil(total / limitInt),
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
};

module.exports = {
  getTransferredProductsByShop,
  transferProducts,
  getProductTransferHistoryByProductId,
};

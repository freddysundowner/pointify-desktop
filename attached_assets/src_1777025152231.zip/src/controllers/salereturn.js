const SaleReturn = require("../models/salereturns");
const Product = require("../models/product");
const SaleItem = require("../models/saleitem");
const SaleModel = require("../models/sales");
const Customer = require("../models/customer");
const UserPayment = require("../models/payment");
const mongoose = require("mongoose");
const { toDateFormat, fromDateFormat } = require("../shared/validationUtils");
const Inventory = require("../models/inventory");

exports.createSaleReturn = async (req, res) => {
  const { saleid, items, reason, attendantId, deleteReceipt, shopId } =
    req.body;
  try {
    const updatedSaleItems = [];
    let refundAmount = 0;

    let saleResponse = await SaleModel.findById(saleid)
      .populate("customerId")
      .populate("items");
    if (!saleResponse) {
      return res.status(404).json({ error: "Receipt not found" });
    }
    const totalQty = items.reduce((accumulator, item) => {
      return accumulator + item.quantity;
    }, 0);
    const totalRQty = saleResponse?.items?.reduce((accumulator, item) => {
      return accumulator + item.quantity;
    }, 0);
    if (totalQty < totalRQty && saleResponse.paymentTag == "split") {
      return res.status(404).json({
        error:
          "This sale was a split sale, you need to return the whole receipt and sell again",
      });
    }
    for (const returnItem of items) {
      const saleItem = await SaleItem.findOne({
        product: returnItem.product,
        sale: saleid,
      }).populate("product", "manageByPrice");

      if (!saleItem) {
        return res.status(404).json({ error: "Sale item not found" });
      }
      if (saleItem?.product?.manageByPrice == true) {
        refundAmount = saleItem.unitPrice;
      } else {
        refundAmount += returnItem.quantity * saleItem.unitPrice;
      }

      const availableQuantity = saleItem.quantity;

      if (returnItem.quantity > availableQuantity) {
        return res
          .status(400)
          .json({ error: "Not enough quantity available for the return" });
      }
      // Update the purchased item quantity
      saleItem.quantity -= returnItem.quantity;
      if ( saleItem.quantity <= 0) { 
        await SaleItem.findOneAndRemove({ sale: saleid });
      }else{
        await saleItem.save();
      }

      updatedSaleItems.push({
        product: returnItem.product,
        quantity: returnItem.quantity,
        unitPrice: saleItem.unitPrice,
      });

      // Find and update the corresponding product to reduce its quantity
      const product = await Product.findById(returnItem.product);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      // Update product quantity
      product.quantity += returnItem.quantity;
      // Update the product in the database
      await product.save();

      //return to inventory
      await Inventory.findOneAndUpdate(
        { product: returnItem.product, shop: shopId },
        { $inc: { quantity: returnItem.quantity } },
        { upsert: true, new: true }
      );
    }

    // Respond with the updated products, sale return, and updated sale items
    let results = await SaleModel.findById(saleid)
      .populate({
        path: "items",
        populate: {
          path: "product",
          select: "name",
        },
      })
      .populate({
        path: "customerId",
      })
      .populate({
        path: "attendantId",
      });
    let totalValue = 0;
    results.items.forEach((obj) => {
      totalValue += obj.quantity;
    });

    //create/update sale return only if deleteReceipt == false
    let prevSaleReturn = await SaleReturn.findOne({ saleId: saleid });
    //update return item if there is already a previous same receipt returned
    if (prevSaleReturn) {
      updatedSaleItems.forEach((returnItem) => {
        // Check if the product already exists in the items array
        const existingItemIndex = prevSaleReturn.items.findIndex((item) =>
          item.product.equals(returnItem.product)
        );

        if (existingItemIndex !== -1) {
          // If the product exists, update the quantity
          prevSaleReturn.items[existingItemIndex].quantity +=
            returnItem.quantity;
        } else {
          // If the product does not exist, add a new item
          prevSaleReturn.items.push({
            product: returnItem.product,
            quantity: returnItem.quantity,
            unitPrice: returnItem.unitPrice,
          });
        }
      });
      prevSaleReturn.refundAmount += refundAmount;

      saleResponse.totalAmount = saleResponse.totalAmount - refundAmount;
      saleResponse.totalWithDiscount =
        saleResponse.totalWithDiscount - refundAmount;
      if (saleResponse.paymentType == "credit") {
        saleResponse.outstandingBalance =
          saleResponse.outstandingBalance - refundAmount;
      } else {
        saleResponse.amountPaid = saleResponse.amountPaid - refundAmount;
      }
      await saleResponse.save();
      await prevSaleReturn.save();
    } else {
      if (items.length > 0) {
        await SaleReturn.create({
          saleId: saleid,
          items: updatedSaleItems,
          refundAmount,
          customerId: saleResponse.customerId?._id,
          attendantId,
          shopId,
          reason,
        });
        if (saleResponse.paymentType == "wallet" && saleResponse.customerId || saleResponse.paymentType == "credit") {
          
              const lastPayment = await UserPayment.findOne({
                      customerId: saleResponse.customerId
              }).sort({ createdAt: -1 });
          
              await UserPayment.create({
                  type: "refund",
                  shopId: shopId,
                  customerId: saleResponse.customerId,
                  attendantId,
                  totalAmount: refundAmount,
                  balance: (lastPayment?.balance??0) + refundAmount
              });
          
              await Customer.findByIdAndUpdate(saleResponse.customerId._id, {$inc: {wallet : refundAmount}});
          // customer.wallet = customer.wallet + refundAmount;
          // customer.save();
        }
        if (saleResponse.paymentType == "credit") {
          saleResponse.outstandingBalance =
            saleResponse.outstandingBalance - refundAmount;
        } else {
          saleResponse.amountPaid = saleResponse.amountPaid - refundAmount;
        }

        //update receipt
        saleResponse.totalAmount = saleResponse.totalAmount - refundAmount;
        saleResponse.totalWithDiscount =
          saleResponse.totalWithDiscount - refundAmount;
        await saleResponse.save();
      }
    }

    if (totalValue == 0) {
      await SaleItem.findOneAndRemove({ sale: saleid });
      await SaleModel.findByIdAndRemove(saleid);
      res.status(201).json({
        deleteReceipt,
      });
      return;
    } else {
      res.status(201).json({
        saleReturn: results,
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error creating sale return" });
  }
};

exports.getSaleReturn = async (req, res) => {
  try {
    const {
      saleId,
      customerId,
      attendantId,
      productId,
      fromDate,
      toDate,
      shopId,
      paginated = false,
      page = 1,
      limit = 10,
    } = req.query;

    const filters = {};

    if (saleId) {
      filters.saleId = saleId;
    }

    if (customerId) {
      filters.customerId = customerId;
    }

    if (attendantId) {
      filters.attendantId = attendantId;
    }

    if (shopId) {
      filters.shopId = new mongoose.Types.ObjectId(shopId);
    }

    if (productId) {
      filters["items.product"] = productId;
    }

    if (fromDate && toDate) {
      filters.createdAt = {
        $gte: fromDateFormat(fromDate),
        $lte: toDateFormat(toDate),
      };
    }

    console.log(filters);

    const query = SaleReturn.find(filters)
      .populate({
        path: "customerId",
        select: "name",
      })
      .populate({
        path: "attendantId",
        select: "username",
      })
      .populate({
        path: "items.product",
        select: "name",
      })
      .sort({ createdAt: -1 });

    // Handle pagination
    if (paginated === "true" || paginated === true) {
      const pageNumber = parseInt(page) || 1;
      const pageSize = parseInt(limit) || 10;

      const total = await SaleReturn.countDocuments(filters);
      const totalPages = Math.ceil(total / pageSize);

      const saleReturns = await query
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize)
        .exec();

      return res.json({
        data: saleReturns,
        pagination: {
          total,
          page: pageNumber,
          totalPages,
          pageSize,
        },
      });
    }

    // No pagination
    const saleReturns = await query.exec();
    res.json(saleReturns);
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error fetching sale returns" });
  }
};


exports.updateSaleReturn = async (req, res) => {
  try {
    const saleReturnId = req.params.id; // Assuming you pass the sale return ID in the URL
    const { originalSaleId, items, refundAmount, reason } = req.body; // Destructure the fields to update

    // Find and update the sale return by its ID
    const updateSaleReturn = await SaleReturn.findByIdAndUpdate(
      saleReturnId,
      {
        originalSaleId,
        items,
        refundAmount,
        reason,
      },
      { new: true } // Return the updated document
    );

    if (!updateSaleReturn) {
      return res.status(404).json({ error: "Sale return not found" });
    }

    // Respond with the updated sale return
    res.json(updateSaleReturn);
  } catch (error) {
    res.status(500).json({ error: "Error updating sale return" });
  }
};

exports.deleteSaleReturn = async (req, res) => {
  try {
    const saleReturnId = req.params.id; // Assuming you pass the sale return ID in the URL
    // Find and delete the sale return by its ID
    const deletedSaleReturn = await SaleReturn.findByIdAndRemove(saleReturnId);

    if (!deletedSaleReturn) {
      return res.status(404).json({ error: "Sale return not found" });
    }

    // Respond with a success message or the deleted sale return
    res.json({ message: "Sale return deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Error deleting sale return" });
  }
};

const Admin = require("../models/admin"); // Adjust the import path as needed
const bcrypt = require("bcryptjs");
const Subscription = require("../models/subscription");

const Shop = require("../models/shop");
const CashFlowCategory = require("../models/cashflowcategory");
const mongoose = require("mongoose"); // Import the mongoose module
const ExpenseCategory = require("../models/expensecategory");
const sales = require("../models/sales");
const Customers = require("../models/customer")
const supplier = require("../models/supplier")
const cashflow = require("../models/cashflow")
const count = require("../models/count")
const badstock = require("../models/badstock")
const bank = require("../models/bank")
const expenses = require("../models/expenses")
const payment = require("../models/payment")
const product = require("../models/product")
const purchase = require("../models/purchase")
const purchaseitem = require("../models/purchaseitem")
const saleitem = require("../models/saleitem")
const salereturns = require("../models/salereturns")
const transfer = require("../models/transfer")
const attendant = require("../models/attendant")
const transporter = require("../shared/emailsetup"); // Import your Nodemailer setup
const jwt = require('jsonwebtoken');

const permissions = (req, res) => {
  return res.json([
    {
      "key": "pos",
      "value": [
        "set_sale_date",
        'can_sell',
        'can_sell_to_dealer_&_wholesaler',
        'discount',
        "edit_price",
      ],
    },
    {
      "key": "stocks",
      "value": [
        'view_products',
        'add_products',
        "view_buying_price",
        'stock_summary',
        'view_purchases',
        'add_purchases',
        'stock_count',
        'badstock',
        'transfer',
        'return',
        'delete_purchase_invoice',
      ],
    },
    {
      "key": "products",
      "value": [
        'edit',
        'delete',
        'add',
        "adjust_stock",
        "view_adjustment_history",
        "view_history"
      ],
    },
    {
      "key": "sales",
      "value": ['view_sales', "return", "delete", "view_profit","view_summary"],
    },
    {
      "key": "reports",
      "value": [
        'sales',
        "dues",
        "productsales",
        "discoutedsales",
        "debtors",
        "purchases",
        "expenses",
        "stocktake",
        "netprofit",
        'stockreport',
        "productmovement",
        "profitanalysis"
      ],
    },
    {
      "key": "purchases",
      "value": ['edit_buying_price'],
    },
    {
      "key": "accounts",
      "value": [
        'cashflow',
      ],
    },
    {
      "key": "expenses",
      "value": [
        'manage',
      ],
    },
    {
      "key": "suppliers",
      "value": ['manage']
    },
    {
      "key": "customers",
      "value": ['manage', 'deposit']
    },
    {
      "key": 'shop',
      "value": ["manage", "switch"],
    },
    {
      "key": 'attendants',
      "value": ["manage", "view"],
    },
    {
      "key": 'usage',
      "value": ["manage"],
    },
    {
      "key": 'support',
      "value": ["manage"],
    },
  ])
}
// Get all shops
const getAdmins = async (req, res) => {
  let { affliate, page, limit,name } = req.query;
  let filter = {};
  
  if (affliate) {
    filter = {
      affliate: new mongoose.Types.ObjectId(affliate),
    };
  }
  if (name) {
    filter.username = { $regex: name, $options: "i" };
  }
  
  
  try {
    // Convert page and limit to integers and calculate skip if page is provided
    const pageInt = parseInt(page) || 0;
    const limitInt = parseInt(limit) || 10;
    const skip = page ? (pageInt - 1) * limitInt : 0;

    // Define the base aggregation pipeline
    let pipeline = [
      {
        $match: filter,
      },
      {
        $lookup: {
          from: "shops", // replace with the actual name of your Shop schema
          localField: "_id",
          foreignField: "adminId",
          as: "shops",
        },
      },
      {
        $lookup: {
          from: "shops", // replace with the actual name of your Shop schema
          localField: "primaryShop",
          foreignField: "_id",
          as: "primaryShop",
        },
      },
      {
        $addFields: {
          shopCount: { $size: "$shops" },
        },
      },
      {
        $sort: { createdAt: -1 },
      },
    ];

    // Apply pagination stages if page is provided
    if (page) {
      pipeline.push(
        { $skip: skip },
        { $limit: limitInt }
      );
    }

    // Execute the aggregation pipeline
    const admins = await Admin.aggregate(pipeline);

    if (page) {
      // Get total count for pagination
      const totalAdmins = await Admin.countDocuments(filter);
      const totalPages = Math.ceil(totalAdmins / limitInt);

      res.status(200).json({
        data: admins,
        count: totalAdmins,
        totalPages,
        currentPage: pageInt,
      });
    } else {
      res.status(200).json(admins);
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const getLocalAdmin = async (req, res) => {
  const admin = await Admin.findOne().populate({ path: "primaryShop", populate: { path: "subscription", populate: { path: "packageId" } } }).populate('attendantId');
  return res.json(admin);
}
const updateAdmin = async (req, res) => {
  try {
    const adminId = req.params.id;
    const { username, password, shop, phone,emailVerified,phoneVerified,email,lastAppRatingDate,status } = req.body;

    // Find the admin by ID
    const admin = await Admin.findById(adminId);

    if (!admin) {
      return res.status(404).json({ error: "Admin not found" });
    }

    let update = {};

    // Update the fields you want to change
    if (username) {
      update.username = username;
    }
    if (status) {
      update.status = status;
    }
    if (shop) {
      update.primaryShop = shop;
    }
    if (emailVerified) {
      update.emailVerified = emailVerified;
    }
    if (phoneVerified) {
      update.phoneVerified = phoneVerified;
    }
    if (phone) {
      update.phone = phone;
    }
    if (email) {
      update.email = email;
    }
    if (lastAppRatingDate) { 
      update.lastAppRatingDate = lastAppRatingDate;
    }
    if (password) {
      const salt = await bcrypt.genSalt(10);
      update.password = await bcrypt.hash(password, salt);
    }
    const updatedAdmin = await Admin.findByIdAndUpdate(adminId, update, {
      new: true,
    }).populate({ path: "primaryShop", populate: { path: "subscription", populate: { path: "packageId" } } }).populate('attendantId');


    return res.json(updatedAdmin);
  } catch (error) {
    if (error.code === 11000 && error.keyPattern && error.keyValue && error.keyValue.email) {
        const duplicateEmail = error.keyValue.email;
        const friendlyErrorMessage = `Oops! It seems that there's already an admin account associated with the email address ${duplicateEmail}. Please double-check the email address you entered or try using a different one. If you believe this is an error, please reach out to our support team for assistance.`;
      // console.error(friendlyErrorMessage);
      return res.status(200).json({ error: friendlyErrorMessage});
        // You can also send this friendly error message as a response to the client if it's a web application
    } else {
        console.error("An unexpected error occurred:", error);
      return res.status(200).json({ error: error});
        // Handle other types of errors
    }
    return res.status(500).json({ error: "Internal server error" });
  }
};
function generateVerificationToken(userid) {
  return signedToken = jwt.sign({ id: userid }, process.env.jwtsecret);
}
const sendverificationemail = async (req, res) => {
  try {
    let { userid } = req.body;
    let verificationToken = generateVerificationToken(userid);
    const admin = await Admin.findById(userid);
    admin.verificationToken = verificationToken;
    await admin.save();
    const verificationLink = `https://pointifypos.com/verify?token=${verificationToken}`;

    const verifyEmailReplacements = {
      username: admin.username,
      verificationLink: verificationLink
    };
    transporter.sendEmail(admin.email, 'Verify Email', 'emailverify', verifyEmailReplacements);
    res.json({ message: `Email verification link sent to your email (${admin.email}), please open your mailbox and click the link sent then come back to the app and refresh`})
  } catch (e) {
    res.json({ error: "Error sending verification" })
  }
}

const verifyemail = async (req, res) => {
  console.log(req.body)
  const decodedToken = jwt.decode(req.body.token);

  jwt.verify(req.body.token, process.env.jwtsecret, async (err, decoded) => {
    if (err) {
      // Token verification failed (e.g., expired or invalid)
      console.error('Token verification failed:', err.message);
    } else {
      // Token verification succeeded
      console.log('Decoded payload:', decoded);

      // Check if the token has expired
      const now = Math.floor(Date.now() / 1000); // Current time in seconds
      if (decoded.iat && now > decoded.iat + (60 * 60 * 24)) {
        // Token has expired (assuming a 24-hour expiration)
        console.log('Token has expired');
        return res.json({message:'Token has expired', status:false})
      } else {
        // Token is still valid
        const admin = await Admin.findById(decoded.id);
        admin.emailVerified = true;
        admin.save();
        console.log('Token is still valid',admin);
        return res.json({message:"Email Verified", status:true})
      }
    }
  });
 
}

const deleteAdmin = async (req, res) => {

  //delete all sales and sales items
  let shops = await Shop.find({ adminId: req.params.id });

    const promises = shops.map(async (i) => {
      let id = i._id;
      await saleitem.deleteMany({ shopId: id });
      await sales.deleteMany({ shopId: id });
      await salereturns.deleteMany({ shopId: id });

      await Subscription.deleteMany({
        userId: id
      });

      //delete all customers
      await Customers.deleteMany({ shopId: id });
      //delete all products
      await product.deleteMany({ shopId: id });

      //delete all suppliers
      await supplier.deleteMany({ shopId: id });

      //delete all purchases and purchases items
      await purchaseitem.deleteMany({ shopId: id });
      await purchase.deleteMany({ shopId: id });

      //delete all expenses
      await ExpenseCategory.deleteMany({ shopId: id });
      await expenses.deleteMany({ shopId: id });

      //delete all cashflow and cashflow categories
      await cashflow.deleteMany({ shopId: id });
      await CashFlowCategory.deleteMany({ shopId: id });

      //others
      await transfer.deleteMany({ toShopId: id });
      await transfer.deleteMany({ fromShopId: id });
      await payment.deleteMany({ shopId: id });
      await badstock.deleteMany({ shopId: id });
      await count.deleteMany({ shopId: id });
      await bank.deleteMany({ shopId: id });
      await attendant.deleteMany({ shopId: id });
      await Shop.findOneAndDelete({ shopId: id });
    });
    await Promise.all(promises);
    await Admin.findOneAndDelete({ _id: req.params.id });
  return res.json({ "message": "account deleted" });
    
};
const searchAdmin = async (req, res) => {
  let { text } = req.query;
  console.log(req.query);
  let response = await Admin.find({
    $or:[
      {username: { $regex: text, $options: "i" }},
      {phone: { $regex: text, $options: "i" }},
      {email: { $regex: text, $options: "i" }}
    ]
  });
  console.log(response);
  res.json(response);
}

module.exports = {
  updateAdmin,
  verifyemail,
  deleteAdmin,
  getAdmins,
  sendverificationemail,
  searchAdmin,permissions,getLocalAdmin
};

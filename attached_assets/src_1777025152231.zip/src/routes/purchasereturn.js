const express = require("express");
const router = express.Router();

const returnController = require("../controllers/purchasereturn");

/**
 * @swagger
 * /purchasereturns:
 *   post:
 *     summary: Create a new purchase return entry
 *     tags:
 *       - Purchase Returns
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               purchaseId:
 *                 type: string
 *                 description: The ID of the original purchase associated with the return.
 *               items:
 *                 type: array
 *                 description: An array of returned items, each containing a product ID and quantity.
 *                 items:
 *                   type: object
 *                   properties:
 *                     product:
 *                       type: string
 *                       description: The ID of the product being returned.
 *                     quantity:
 *                       type: number
 *                       description: The quantity of the product being returned.
 *               reason:
 *                 type: string
 *                 description: An optional reason for the return.
 *               deleteReceipt:
 *                 type: boolean
 *                 description: An optional reason for the return.
 *     responses:
 *       '201':
 *         description: Successfully created a new purchase return entry.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 purchaseReturn:
 *                   type: object
 *                   description: The newly created purchase return entry.
 *                 updatedProducts:
 *                   type: array
 *                   description: An array of updated product quantities.
 *                 updatedPurchaseItems:
 *                   type: array
 *                   description: An array of updated purchase items.
 *       '400':
 *         description: Bad request. Invalid input data.
 *       '404':
 *         description: Product or purchase item not found.
 *       '500':
 *         description: Internal server error.
 */

router.post("/", returnController.createPurchaseReturn);
/**
 * @swagger
 * /{id}:
 *   get:
 *     summary: Get purchase return details by ID
 *     tags:
 *       - Purchase Returns
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the purchase return to retrieve.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Successfully retrieved purchase return details.
 *       '404':
 *         description: Purchase return not found.
 *       '500':
 *         description: Internal server error.
 */

router.get("/:id", returnController.getPurchaseReturn);
/**
 * @swagger
 * /{id}:
 *   put:
 *     summary: Update a purchase return by ID
 *     tags:
 *       - Purchase Returns
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the purchase return to update.
 *         schema:
 *           type: string
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               originalPurchaseId:
 *                 type: string
 *                 description: The updated ID of the original purchase associated with the return.
 *               items:
 *                 type: array
 *                 description: An updated array of returned items with product IDs and quantities.
 *               refundAmount:
 *                 type: number
 *                 description: The updated total refund amount for the return.
 *               reason:
 *                 type: string
 *                 description: An updated reason for the return.
 *     responses:
 *       '200':
 *         description: Successfully updated the purchase return.
 *       '400':
 *         description: Bad request. Invalid input data.
 *       '404':
 *         description: Purchase return not found.
 *       '500':
 *         description: Internal server error.
 */

router.put("/:id", returnController.updatePurchaseReturn);
/**
 * @swagger
 * /{id}:
 *   delete:
 *     summary: Delete a purchase return by ID
 *     tags:
 *       - Purchase Returns
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the purchase return to delete.
 *         schema:
 *           type: string
 *     responses:
 *       '204':
 *         description: Successfully deleted the purchase return.
 *       '404':
 *         description: Purchase return not found.
 *       '500':
 *         description: Internal server error.
 */

router.delete("/:id", returnController.deletePurchaseReturn);
/**
 * @swagger
 * /purchasereturns:
 *   get:
 *     summary: Get purchase returns by supplier ID
 *     tags:
 *       - Purchase Returns
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *       - in: path
 *         name: shopId
 *       - in: path
 *         name: fromDate
 *       - in: path
 *         name: toDate
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Successfully retrieved purchase returns for the specified supplier.
 *       '404':
 *         description: Supplier not found or no purchase returns found for the supplier.
 *       '500':
 *         description: Internal server error.
 */

router.get("/", returnController.getPurchaseReturns);

module.exports = router;

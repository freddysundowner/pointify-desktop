const express = require("express");
const router = express.Router();
const paymentsController = require("../controllers/payments");
/**
 * @swagger
 * /payments/recordPurchasePayment:
 *   post:
 *     summary: Record a payment for a purchase made on credit.
 *     tags:
 *       - Payments
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               purchaseId:
 *                 type: string
 *               paymentAmount:
 *                 type: number
 *               attendantId:
 *                 type: string
 *               type:
 *                 type: string
 *             example:
 *               purchaseId: "654023e8278614d7dcdfc470"
 *               paymentAmount: 2
 *               attendantId: "65400d6082ab4a6b7e45335e"
 *     responses:
 *       200:
 *         description: Successfully recorded the payment.
 *       400:
 *         description: Invalid request or payment amount exceeds outstanding balance.
 *       404:
 *         description: Purchase not found.
 */

router.post("/recordPurchasePayment", paymentsController.recordPurchasePayment);
/**
 * @swagger
 * /payments/recordSalePayment:
 *   post:
 *     summary: Record a payment for a sale made on credit.
 *     tags:
 *       - Payments
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               saleId:
 *                 type: string
 *               paymentAmount:
 *                 type: number
 *               attendantId:
 *                 type: string
 *               type:
 *                 type: string
 *             example:
 *               saleId: "654023e8278614d7dcdfc470"
 *               paymentAmount: 2
 *               attendantId: "65400d6082ab4a6b7e45335e"
 *     responses:
 *       200:
 *         description: Successfully recorded the payment.
 *       400:
 *         description: Invalid request or payment amount exceeds outstanding balance.
 *       404:
 *         description: Sale not found.
 */

router.post("/recordSalePayment", paymentsController.recordSalePayment);
/**
 * @swagger
 * /payments:
 *   get:
 *     tags:
 *       - Payments
 *     summary: Get payments by Purchase ID
 *     description: Retrieve payments associated with a specific purchase by its ID.
 *     parameters:
 *       - in: query
 *         name: saleId
 *       - in: query
 *         name: purchaseId
 *       - in: query
 *         name: fromDate
 *       - in: query
 *         name: toDate
 *       - in: query
 *         name: shop 
 *     responses: 
 *       200:
 *         description: Successful operation. Returns an array of payments.
 *         content:
 *           application/json: 
 *             example:
 *               - _id: 123456
 *                 amount: 500
 *                 paymentDate: 2023-10-30T12:00:00Z
 *                 referenceNumber: PAY-789
 *               - _id: 789012
 *                 amount: 300
 *                 paymentDate: 2023-10-30T14:00:00Z
 *                 referenceNumber: PAY-890
 *       404:
 *         description: Purchase not found.
 *         content:
 *           application/json:
 *             example:
 *               error: Purchase not found
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             example:
 *               error: Internal server error
 */
router.get("/", paymentsController.getPaymentsByPurchaseIdOrSaleId);

/**
 * @swagger
 * /payments/{id}:
 *   delete:
 *     tags:
 *       - Payments
 *     summary: Delete a receipt by ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the receipt to delete
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: receipt deleted
 *       404:
 *         description: receipt not found
 *       500:
 *         description: Internal server error
 */
// Delete a receipt by ID
router.delete("/:id", paymentsController.deleteReceipt);


/**
 * @swagger
 * /payments/awards:
 *   get:
 *     tags:
 *       - Payments
 *     summary: Get awards payments by user ID
 *     description: Retrieve payments associated with a specific user by its ID.
 *     parameters:
 *       - in: query
 *         name: user
 *     responses: 
 *       200:
 *         description: Successful operation. Returns an array of payments.
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             example:
 *               error: Internal server error
 */
router.get("/awards", paymentsController.getAwardsPayments);

/**
 * @swagger
 * /payments/awards/withdraw/{id}:
 *   post:
 *     tags:
 *       - Payments
 *     summary: withdraw awards payments by user ID
 *     description: Retrieve payments associated with a specific user by its ID.
 *     parameters:
 *       - in: path
 *         name: id
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               amount:
 *                 type: number
 *               phonenumber:
 *                 type: string
 *     responses: 
 *       200:
 *         description: Successful operation. Returns an array of payments.
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             example:
 *               error: Internal server error
 */
router.post("/awards/withdraw/:id", paymentsController.withdrawAmount)
router.post("/withdraw/response/", paymentsController.withdrawResponse)
/**
 * @swagger
 * /payments/transactions:
 *   get:
 *     tags:
 *       - Payments
 *     summary: withdraw awards payments by user ID
 *     description: Retrieve payments associated with a specific user by its ID.
 *     parameters:
 *       - in: query
 *         name: id
 *     responses: 
 *       200:
 *         description: Successful operation. Returns an array of payments.
 *       500:
 *         description: Internal server error.
 *         content: 
 *           application/json:
 *             example:
 *               error: Internal server error
 */
router.get("/transactions", paymentsController.transactions)
router.post("/transactions/b2c", paymentsController.b2c)
router.post("/que/timeout", (req, res) => {
    console.log(req.body,req.query)
})
router.post("/b2b/response", (req, res) => {
    console.log(req.body,req.query)
})

router.post("/elimu/withdraw", paymentsController.withdrawElimu)


module.exports = router;

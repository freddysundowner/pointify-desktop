// subscriptionRoutes.js

const express = require('express');
const router = express.Router();
const subscriptionController = require('../controllers/subscription');

/**
 * @swagger
 * /subscriptions:
 *   post:
 *     summary: Create a new subscription
 *     description: Endpoint to create a new subscription.
 *     tags: [Subscriptions]
 *     parameters:
 *       - in: path
 *         name: shop
 *         description: shop id.
 *         required: true
 *       - in: path
 *         name: package
 *         description: package id.
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Subscription created successfully
 *       '500':
 *         description: Internal Server Error
 */
router.post('/', subscriptionController.createSubscription);

router.post('/createCheckout', subscriptionController.stripeCheckout);
router.get('/stripesucess', subscriptionController.subscriptionSuccess);
router.get("/shop/sales", subscriptionController.getSubscriptionsByShopIds)
router.get('/', subscriptionController.getAllSubscriptions);
router.get("/shop/stats", subscriptionController.getSubscriptionsStats)
router.get('/:id', subscriptionController.getSubscriptionById);
router.put('/:id', subscriptionController.updateSubscription);
router.delete('/:id', subscriptionController.deleteSubscription);
router.put("/stripe/updateAfterStripeSuccessPayment", subscriptionController.updateSubscriptionPayment)
router.put('/extend/:id', subscriptionController.extendSubscription);
router.get('/summary/stats', subscriptionController.summary);
router.post("/inapp/ios", subscriptionController.updateSubscriptionInappPayment)
router.post('/elimu/deposit', subscriptionController.depositElimu)
router.get("/licence/:id", subscriptionController.getlicence)
module.exports = router;
 
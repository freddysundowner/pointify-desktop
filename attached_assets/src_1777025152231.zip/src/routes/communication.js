
const express = require("express");
const router = express.Router();
const { sendAdminEmail,getEmailtemplates,getEmailSent,deleteTemplate } = require("../controllers/communications");
/**
 * @swagger
 * /communication:
 *   post:
 *     summary: Send Admin Email
 *     tags:
 *       - AdminEmails
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               to:
 *                 type: string
 *                 description: Email address separated by commans
 *                 example: "reggypos@gmail.com,pointifypos@gmail.com"
 *               type:
 *                 type: string
 *                 description: Type of email
 *                 example: "single"
 *               subject:
 *                 type: string
 *                 description: email subject
 *                 example: "Test Email"
 *               body:
 *                 type: string
 *                 description: content of the email
 *                 example: "This is a test email, please ignore"
 *             required:
 *               - type
 *               - subject
 *               - body
 *     responses:
 *       201:
 *         description: Email sent successfully
 *         content:
 *           application/json:
 *             example:
 *               to: "reggypos@gmail.com"
 *               type: "single"
 *               name: "Test Email"
 *               body: "This is a test email, please ignore"
 *       400:
 *         description: Bad request, validation failed
 */
router.post("/", sendAdminEmail);
/**
 * @swagger
 * /communication:
 *   get:
 *     summary: get Admin Email templates
 *     tags:
 *       - AdminEmails
 *     requestBody:
 *       content:
 *         application/json:
 *     responses:
 *       201:
 *         description: Email sent successfully
 *       400:
 *         description: Bad request, validation failed
 */
router.get("/", getEmailtemplates);
/**
 * @swagger
 * /communication/sent:
 *   get:
 *     summary: get Emails sent
 *     tags:
 *       - AdminEmails
 *     requestBody:
 *       content:
 *         application/json:
 *     responses:
 *       201:
 *         description: Email sent successfully
 *       400:
 *         description: Bad request, validation failed
 */
router.get("/sent", getEmailSent);
router.delete("/:id", deleteTemplate);
module.exports = router;

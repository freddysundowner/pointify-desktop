const express = require("express");
const router = express.Router();
const transferController = require("../controllers/transfer");
/**
 * @swagger
 * /transfer/shop/transfer:
 *   post:
 *     summary: Transfer products between shops
 *     tags: [Transfer]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               attendantId:
 *                 type: string
 *               fromShopId:
 *                 type: string
 *               toShopId:
 *                 type: string
 *               products:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     product:
 *                       type: string
 *                     quantity:
 *                       type: integer
 *                 required: true
 *     responses:
 *       '200':
 *         description: Successful product transfer
 *       '400':
 *         description: Bad request or validation error
 *       '500':
 *         description: Internal server error
 */

router.post("/shop/transfer", transferController.transferProducts);
/**
 * @swagger
 * /transfer/filter:
 *   get:
 *     summary: Retrieve products transferred from or to a specific shop with a date filter.
 *     description: Retrieve transferred products based on shop, direction, and date range.
 *     tags:
 *       - Transfer
 *     parameters:
 *       - in: query
 *         name: shopId
 *         description: Shop ID to filter transferred products.
 *         schema:
 *           type: string
 *       - in: query
 *         name: productId
 *         description: product Id to filter transferred products.
 *         schema:
 *           type: string
 *       - in: query
 *         name: direction
 *         description: Filter direction ('from' or 'to').
 *         schema:
 *           type: string
 *       - in: query
 *         name: startDate
 *         description: Start date for the date range filter (YYYY-MM-DD).
 *         schema:
 *           type: string
 *       - in: query
 *         name: endDate
 *         description: End date for the date range filter (YYYY-MM-DD).
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successful operation. Returns transferred products.
 *       400:
 *         description: Bad request. Invalid parameters or direction.
 *       500:
 *         description: Internal server error.
 */

router.get("/filter", transferController.getTransferredProductsByShop);
router.get(
  "/product/:id",
  transferController.getProductTransferHistoryByProductId
);
module.exports = router;

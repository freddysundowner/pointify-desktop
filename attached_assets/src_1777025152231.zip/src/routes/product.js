const express = require("express");
const router = express.Router();
const productController = require("../controllers/product");
router.post("/category/", productController.createProductCategory);
router.get("/category/", productController.getAllProductCategories);
router.put("/category/:id", productController.updateProductCategory);
router.delete("/category/:id", productController.deleteProductCategory);

router.get("/category/all/:id", productController.getProductCategoryById);
router.post("/", productController.createProduct);
router.get("/", productController.getAllProducts);
/**
 * @swagger
 * /product/{id}: 
 *   put:
 *     summary: Update a product by ID
 *     description: Update a product with the specified ID.
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the product.
 *         schema:
 *           type: string
 *           format: ObjectId
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               buyingPrice:
 *                 type: number
 *               sellingPrice:
 *                 type: number
 *               minSellingPrice:
 *                 type: number
 *               quantity:
 *                 type: number
 *               maxDiscount:
 *                 type: number
 *               reorderLevel:
 *                 type: number
 *               productCategoryId:
 *                 type: string
 *               measureUnit:
 *                 type: string
 *               supplierId:
 *                 type: string
 *               description:
 *                 type: string
 *               uploadImage:
 *                 type: string
 *     responses:
 *       200:
 *         description: Product updated successfully.
 *       404:
 *         description: Product not found.
 *       500:
 *         description: Internal server error.
 */

router.put("/:id", productController.updateProduct);
/**
 * @swagger
 * /product/{id}:
 *   get:
 *     summary: Get a product by ID with populated fields
 *     description: Retrieve a product by its unique ID with populated fields for measureUnit, supplier, and userId.
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the product.
 *         schema:
 *           type: string
 *           format: ObjectId
 *     responses:
 *       200:
 *         description: Product retrieved successfully with populated fields.
 *       404:
 *         description: Product not found.
 *       500:
 *         description: Internal server error.
 */

router.get("/:id", productController.getProductById);
/**
 * @swagger
 * /product/product/search:
 *   get:
 *     summary: Get products.
 *     description: Retrieve products with optional filtering and sorting by name, userId, shopId, supplierId, reorder, outOfStock, highestBuyingPrice, and highestSellingPrice.
 *     tags:
 *       - Products
 *     parameters:
 *       - in: query
 *         name: name
 *         schema:
 *           type: string
 *         description: Filter products by name (case-insensitive).
 *       - in: query
 *         name: userId
 *         schema:
 *           type: string
 *         description: Filter products by user ID.
 *       - in: query
 *         name: shopId
 *         schema:
 *           type: string
 *         description: Filter products by shop ID.
 *       - in: query
 *         name: supplierId
 *         schema:
 *           type: string
 *         description: Filter products by supplier ID.
 *       - in: query
 *         name: outOfStock
 *         schema:
 *           type: boolean
 *         description: Filter out-of-stock products (true to enable).
 *       - in: query
 *         name: reorder
 *         schema:
 *           type: boolean
 *         description: Filter products where reorderLevel is less than quantity (true to enable).
 *       - in: query
 *         name: highestBuyingPrice
 *         schema:
 *           type: boolean
 *         description: Filter products with the highest buying price (true to enable).
 *       - in: query
 *         name: highestSellingPrice
 *         schema:
 *           type: boolean
 *         description: Filter products with the highest selling price (true to enable).
 *       - in: query
 *         name: sort
 *         schema:
 *           type: string
 *         description: Sort products by "buyingPrice" or "sellingPrice" (ascending order). Prefix with "-" to sort in descending order (e.g., "-buyingPrice").
 *     responses:
 *       200:
 *         description: A list of products.
 */

router.get("/product/search", productController.searchProducts);

/**
 * @swagger
 * /product/{id}:
 *   delete:
 *     summary: Delete a product by ID
 *     description: Delete a product by its unique ID.
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the product.
 *         schema:
 *           type: string
 *           format: ObjectId
 *     responses:
 *       204:
 *         description: Product deleted successfully.
 *       404:
 *         description: Product not found.
 *       500:
 *         description: Internal server error.
 */
router.delete("/:id", productController.deleteProduct);
router.put("/remove/bundle/item", productController.removebundleitem);
/**
 * @swagger
 * /product/product/summary:
 *   get:
 *     summary: Get a summary of products added in a specific year.
 *     description: Retrieve a summary of products added in a specific year, grouped by month.
 *     tags:
 *       - Products
 *     parameters:
 *       - in: query
 *         name: year
 *         schema:
 *           type: integer
 *       - in: query
 *         name: productId
 *         schema:
 *           type: string
 *         description: The year for which you want to retrieve the product summary.
 *     responses:
 *       200:
 *         description: A summary of products added in the specified year.
 */

router.get("/product/summary", productController.getProductSummary);
/**
 * @swagger
 * /product/shop/{shopId}:
 *   get:
 *     summary: Get products by shopId
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: shopId
 *         required: true
 *         description: The ID of the shop to retrieve products from.
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Successfully retrieved products by shopId.
 *       '500':
 *         description: Internal server error.
 */

router.get("/shop/:shopId", productController.getProductsByShopId);

/**
 * @swagger
 * /product/import/products:
 *   post:
 *     summary: Import products from an Excel sheet.
 *     description: Upload an Excel sheet containing product data to import into the system.
 *     tags:
 *       - Products
 *     consumes:
 *       - multipart/form-data
 *     parameters:
 *       - in: formData
 *         name: productExcel
 *         type: file
 *         description: Excel file containing product data.
 *         required: true
 *     responses:
 *       200:
 *         description: Successful import of products.
 *       400:
 *         description: Bad request. No file uploaded or invalid file format.
 *       500:
 *         description: Internal server error.
 */

router.post("/import/products", productController.importProducts);
/**
 * @swagger
 * /product/transfer/products:
 *   post:
 *     summary: Import products from an Excel sheet.
 *     description: Upload an Excel sheet containing product data to import into the system.
 *     tags:
 *       - Products
 *     consumes:
 *       - multipart/form-data
 *     parameters:
 *       - in: formData
 *         name: productExcel
 *         type: file
 *         description: Excel file containing product data.
 *         required: true
 *     responses:
 *       200:
 *         description: Successful import of products.
 *       400:
 *         description: Bad request. No file uploaded or invalid file format.
 *       500:
 *         description: Internal server error.
 */

router.post("/transfer/products", productController.transferProducts);
/**
 * @swagger
 * /product/stockreport/{shopId}:
 *   get:
 *     summary: Get stock report by shopId
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: shopId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Successfully retrieved stock report by shopId.
 *       '500':
 *         description: Internal server error.
 */

router.get("/stockreport/:shopId", productController.getStockReport);

/**
 * @swagger
 * /product/images/{id}:
 *   get:
 *     summary: update product images
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Successfully update product data.
 *       '500':
 *         description: Internal server error.
 */

router.put("/images/:id", productController.updateProductImages);
router.post("/report", productController.generateResports);
router.put("/adjust/:id", productController.adjustStock);
router.get("/adjust/:id", productController.getProductAdjustments);
router.get("/bundle/items/:id", productController.getProductBundleItems)
router.get("/history/product", productController.getStockAndSalesSummary)
module.exports = router;
 
const express = require("express");
const router = express.Router();

const adminController = require("../controllers/admin");
/**
 * @swagger
 * /admin/{id}:
 *   put:
 *     summary: Update admin information.
 *     description: Update the username and/or password of an admin.
 *     tags:
 *       - Admins
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the admin to update.
 *         schema:
 *           type: string
 *       - in: body
 *         name: adminData
 *         required: true
 *         description: Admin data to update.
 *         schema:
 *           type: object
 *           properties:
 *             primaryShop:
 *               type: string
 *               description: New primaryShop for the admin.
 *             username:
 *               type: string
 *               description: New username for the admin.
 *             password:
 *               type: string
 *               description: New password for the admin.
 *     responses:
 *       200:
 *         description: Admin information updated successfully.
 *       400:
 *         description: Bad request. Invalid input data.
 *       404:
 *         description: Admin not found.
 *       500:
 *         description: Internal server error.
 */
router.put("/:id", adminController.updateAdmin);
/**
 * @swagger
 * /admin/verifyemail:
 *   post:
 *     summary: Update admin information.
 *     description: Update the username and/or password of an admin.
 *     tags:
 *       - Admins
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the admin to update.
 *         schema:
 *           type: string
 *       - in: body
 *         name: adminData
 *         required: true
 *         description: Admin data to update.
 *         schema:
 *           type: object
 *           properties:
 *             primaryShop:
 *               type: string
 *               description: New primaryShop for the admin.
 *             username:
 *               type: string
 *               description: New username for the admin.
 *             password:
 *               type: string
 *               description: New password for the admin.
 *     responses:
 *       200:
 *         description: Admin information updated successfully.
 *       400:
 *         description: Bad request. Invalid input data.
 *       404:
 *         description: Admin not found.
 *       500:
 *         description: Internal server error.
 */
router.post("/verifyemail", adminController.verifyemail);
/**
 * @swagger
 * /admin/sendverificationemail:
 *   post:
 *     summary: Update admin information.
 *     description: Update the username and/or password of an admin.
 *     tags:
 *       - Admins
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the admin to update.
 *         schema:
 *           type: string
 *       - in: body
 *         name: adminData
 *         required: true
 *         description: Admin data to update.
 *         schema:
 *           type: object
 *           properties:
 *             primaryShop:
 *               type: string
 *               description: New primaryShop for the admin.
 *             username:
 *               type: string
 *               description: New username for the admin.
 *             password:
 *               type: string
 *               description: New password for the admin.
 *     responses:
 *       200:
 *         description: Admin information updated successfully.
 *       400:
 *         description: Bad request. Invalid input data.
 *       404:
 *         description: Admin not found.
 *       500:
 *         description: Internal server error.
 */
router.post("/sendverificationemail", adminController.sendverificationemail);
/**
 * @swagger
 * /admin/{id}:
 *   put:
 *     summary: Update admin information.
 *     description: Update the username and/or password of an admin.
 *     tags:
 *       - Admins
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the admin to update.
 *         schema:
 *           type: string
 *       - in: body
 *         name: adminData
 *         required: true
 *         description: Admin data to update.
 *         schema:
 *           type: object
 *           properties:
 *             primaryShop:
 *               type: string
 *               description: New primaryShop for the admin.
 *             username:
 *               type: string
 *               description: New username for the admin.
 *             password:
 *               type: string
 *               description: New password for the admin.
 *     responses:
 *       200:
 *         description: Admin information updated successfully.
 *       400:
 *         description: Bad request. Invalid input data.
 *       404:
 *         description: Admin not found.
 *       500:
 *         description: Internal server error.
 */
router.delete("/:id", adminController.deleteAdmin);

/**
 * @swagger
 * /admin:
 *   get:
 *     summary: Get a list of all admis
 *     description: Retrieve a list of all admis in the system.
 *     tags:
 *       - Admins
 *     responses:
 *       200:
 *         description: A list of admis.
 *       500:
 *         description: Internal server error.
 */
router.get("/", adminController.getAdmins);
router.get("/search", adminController.searchAdmin);
router.get("/permissions", adminController.permissions)
router.get("/single/user",adminController.getLocalAdmin)
module.exports = router; 
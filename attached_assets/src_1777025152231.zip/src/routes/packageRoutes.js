// packageRoutes.js

const express = require('express');
const router = express.Router();
const packageController = require('../controllers/package');

/**
 * @swagger
 * tags:
 *   name: Packages
 *   description: CRUD operations for packages
 */
/**
 * @swagger
 * /packages:
 *   post:
 *     summary: Create a new package
 *     description: Endpoint to create a new package.
 *     tags: [Packages]
 *     requestBody:
 *       description: The package object.
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               title:
 *                 type: string
 *               description:
 *                 type: string
 *               type:
 *                 type: string
 *                 enum: ['trial', 'production']
 *               durationValue:
 *                 type: number
 *               durationUnit:
 *                 type: string
 *                 enum: ['days', 'weeks', 'months', 'years']
 *               amount:
 *                 type: number
 *               discount:
 *                 type: number
 *               order:
 *                 type: number
 *               features:
 *                 type: array
 *                 items:
 *                   type: string
 *               maxShops:
 *                 type: number
 *     responses:
 *       200:
 *         description: Package created successfully
 *       500:
 *         description: Internal Server Error
 */
router.post('/', packageController.createPackage);

/**
 * @swagger
 * /packages:
 *   get:
 *     summary: Get all packages
 *     description: Endpoint to get a list of all packages.
 *     tags: [Packages]
 *     responses:
 *       200:
 *         description: List of packages
 *       500:
 *         description: Internal Server Error
 */
router.get('/', packageController.getAllPackages);

/**
 * @swagger
 * /packages/{id}:
 *   get:
 *     summary: Get a specific package by ID
 *     description: Endpoint to get a specific package by ID.
 *     tags: [Packages]
 *     parameters:
 *       - in: path
 *         name: id
 *         description: The package ID.
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Package details
 *       404:
 *         description: Package not found
 *       500:
 *         description: Internal Server Error
 */
router.get('/:id', packageController.getPackageById);

/**
 * @swagger
 * /packages/{id}:
 *   put:
 *     summary: Update a package by ID
 *     description: Endpoint to update a specific package by ID.
 *     tags: [Packages]
 *     parameters:
 *       - in: path
 *         name: id
 *         description: The package ID.
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       description: The package object.
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               title:
 *                 type: string
 *               description:
 *                 type: string
 *               type:
 *                 type: string
 *                 enum: ['trial', 'production']
 *               durationValue:
 *                 type: number
 *               durationUnit:
 *                 type: string
 *                 enum: ['days', 'weeks', 'months', 'years']
 *               amount:
 *                 type: number
 *               features:
 *                 type: array
 *                 items:
 *                   type: string
 *               maxShops:
 *                 type: number
 *     responses:
 *       200:
 *         description: Package updated successfully
 *       404:
 *         description: Package not found
 *       500:
 *         description: Internal Server Error
 */
router.put('/:id', packageController.updatePackage);

/**
 * @swagger
 * /packages/{id}:
 *   delete:
 *     summary: Delete a package by ID
 *     description: Endpoint to delete a specific package by ID.
 *     tags: [Packages]
 *     parameters:
 *       - in: path
 *         name: id
 *         description: The package ID.
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Package deleted successfully
 *       404:
 *         description: Package not found
 *       500:
 *         description: Internal Server Error
 */
router.delete('/:id', packageController.deletePackage);

module.exports = router;

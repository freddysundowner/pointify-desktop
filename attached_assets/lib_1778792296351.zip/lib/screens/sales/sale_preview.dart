import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controllers/customercontroller.dart';
import '../../controllers/salescontroller.dart';
import '../../functions/functions.dart';
import '../../models/customer.dart';
import '../../utils/colors.dart';
import '../../widgets/alert.dart';
import '../customers/customers_page.dart';

/// Preview screen shown after items are added to the cart.
///
/// All single-channel payments (Cash, Mpesa, Bank, Wallet, Credit) collect
/// their inputs inline on this page. Split Payment uses a bottom sheet since
/// it needs three separate channel fields.
class SalePreview extends StatefulWidget {
  final String? page;

  const SalePreview({super.key, this.page});

  @override
  State<SalePreview> createState() => _SalePreviewState();
}

class _SalePreviewState extends State<SalePreview> {
  final SalesController salesController = Get.find<SalesController>();
  final CustomerController customersController = Get.find<CustomerController>();

  @override
  void initState() {
    super.initState();

    salesController.paymentType.value = 'Cash';

    // Clear any stale extra charges from a previous (abandoned) sale.
    salesController.extraCharges.clear();

    // WidgetsBinding.instance.addPostFrameCallback((_) {
    //   Future.delayed(
    //     const Duration(milliseconds: 250),
    //     _showPaymentMethodsSheet,
    //   );
    // });
  }

  // ─────────────────────────────────────────────────────────────────────────
  // BUILD
  // ─────────────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff7f7fb),
      bottomNavigationBar: _buildBottomBar(),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            child: Column(
              children: [
                _buildCloseButton(),
                const SizedBox(height: 12),
                _buildTotalCard(),
                const SizedBox(height: 10),
                _buildPaymentMethodsLabel(),
                const SizedBox(height: 12),
                _buildPaymentSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // BOTTOM BAR — single button completes whatever method is selected
  // ─────────────────────────────────────────────────────────────────────────

  Widget _buildBottomBar() {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.04),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: Obx(() {
          final method = salesController.paymentType.value ?? 'Cash';
          final state = _validate(method);

          return SizedBox(
            height: 52,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.mainColor,
                disabledBackgroundColor: AppColors.mainColor.withOpacity(.4),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              onPressed:
                  state.canComplete ? () => _onCompletePressed(method) : null,
              child: Text(
                state.buttonLabel,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // HEADER WIDGETS
  // ─────────────────────────────────────────────────────────────────────────

  Widget _buildCloseButton() {
    return Align(
      alignment: Alignment.centerRight,
      child: InkWell(
        onTap: Get.back,
        borderRadius: BorderRadius.circular(30),
        child: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: const Icon(Icons.close, size: 18),
        ),
      ),
    );
  }

  Widget _buildTotalCard() {
    return Obx(() {
      final receipt = salesController.receipt.value;
      final total = receipt?.totalWithDiscount?.toStringAsFixed(2) ?? '0';
      final itemCount = receipt?.items?.length ?? 0;

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              AppColors.mainColor,
              AppColors.mainColor.withOpacity(.85),
            ],
          ),
          borderRadius: BorderRadius.circular(26),
        ),
        child: Column(
          children: [
            const Text(
              'TOTAL AMOUNT',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              htmlPrice(total),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '$itemCount item(s)',
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ],
        ),
      );
    });
  }

  Widget _buildPaymentMethodsLabel() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        'Payment Methods',
        style: TextStyle(
          color: Colors.grey.shade700,
          fontWeight: FontWeight.w700,
          fontSize: 13,
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // PAYMENT SECTION
  // ─────────────────────────────────────────────────────────────────────────

  Widget _buildPaymentSection() {
    return Obx(() {
      final method = (salesController.paymentType.value ?? '').isEmpty
          ? 'Cash'
          : salesController.paymentType.value!;

      return Column(
        children: [
          _SelectedPaymentMethodCard(
            method: method,
            iconResolver: _paymentIcon,
            onTap: _showPaymentMethodsSheet,
          ),
          if (method != 'Split Payment') _buildInlinePaymentCard(method),
          _buildChangeMethodLink(),
        ],
      );
    });
  }

  Widget _buildChangeMethodLink() {
    return InkWell(
      onTap: _showPaymentMethodsSheet,
      child: Padding(
        padding: const EdgeInsets.only(top: 2, bottom: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Change payment method',
              style: TextStyle(
                color: AppColors.mainColor,
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
            const SizedBox(width: 4),
            Icon(
              Icons.keyboard_arrow_down,
              size: 18,
              color: AppColors.mainColor,
            ),
          ],
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // INLINE PAYMENT CARD — used by Cash / Mpesa / Bank / Wallet / Credit
  // ─────────────────────────────────────────────────────────────────────────

  Widget _buildInlinePaymentCard(String method) {
    final needsCustomer = method == 'Credit' || method == 'Wallet';
    final isWallet = method == 'Wallet';
    final isMpesa = method == 'Mpesa';

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (needsCustomer) ...[
            _buildCustomerSelector(),
            const SizedBox(height: 12),
          ],
          if (isWallet) ...[
            _buildWalletBalanceRow(),
            const SizedBox(height: 12),
          ],
          _buildInlineExtraCharges(),
          const SizedBox(height: 12),
          _buildAmountPaidField(method: method),
          if (isMpesa) ...[
            const SizedBox(height: 10),
            _buildMpesaTransIdField(),
          ],
          const SizedBox(height: 14),
          _buildPaymentSummary(method: method),
        ],
      ),
    );
  }

  // ─── customer selector ─────────────────────────────────────────────────

  Widget _buildCustomerSelector() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: InkWell(
        onTap: _openCustomerPicker,
        child: Obx(() {
          final customer = salesController.currentCustomer.value;
          final name = customer?.name ?? 'Select Customer';
          final hasCustomer = customer != null;

          return Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: AppColors.mainColor.withOpacity(.08),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  Icons.person_outline,
                  color: AppColors.mainColor,
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: hasCustomer ? Colors.black : Colors.grey,
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      hasCustomer ? 'Tap to change' : 'Required',
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              if (hasCustomer)
                _ClearCustomerButton(onTap: _clearCustomer)
              else
                Icon(
                  Icons.arrow_forward_ios,
                  size: 13,
                  color: Colors.grey.shade500,
                ),
            ],
          );
        }),
      ),
    );
  }

  // ─── wallet balance row ────────────────────────────────────────────────

  Widget _buildWalletBalanceRow() {
    return Obx(() {
      final total = salesController.receipt.value?.totalWithDiscount ?? 0;
      final wallet = salesController.currentCustomer.value?.wallet ?? 0;
      final remaining = wallet - total;
      final hasCustomer = salesController.currentCustomer.value != null;

      if (!hasCustomer) {
        return const _InfoBanner(
          color: Colors.orange,
          icon: Icons.info_outline,
          text: 'Select a customer to see their wallet balance.',
        );
      }

      final insufficient = wallet < total;

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color:
              insufficient ? Colors.red.withOpacity(.06) : Colors.grey.shade50,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: insufficient
                ? Colors.red.withOpacity(.15)
                : Colors.grey.shade200,
          ),
        ),
        child: Column(
          children: [
            _PaymentRow(
              label: 'Wallet Balance',
              value: _signedPrice(wallet),
              valueColor: wallet < 0 ? Colors.red : Colors.green,
            ),
            const SizedBox(height: 6),
            _PaymentRow(
              label: 'After Sale',
              value: _signedPrice(remaining),
              bold: true,
              valueColor: remaining < 0 ? Colors.red : Colors.green,
            ),
            if (insufficient) ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  const Icon(
                    Icons.warning_amber_rounded,
                    color: Colors.red,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Wallet balance is not enough for this sale.',
                      style: TextStyle(
                        color: Colors.red.shade700,
                        fontWeight: FontWeight.w600,
                        fontSize: 11,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      );
    });
  }

  // ─── extra charges ─────────────────────────────────────────────────────

  Widget _buildInlineExtraCharges() {
    return Obx(() {
      final charges = salesController.extraCharges;

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildExtraChargesHeader(),
          if (charges.isNotEmpty) ...[
            const SizedBox(height: 10),
            ...List.generate(charges.length, (index) {
              final charge = charges[index];
              return Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        charge['name'] ?? '',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Text(
                      htmlPrice(charge['amount'] ?? 0),
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(width: 8),
                    InkWell(
                      onTap: () {
                        salesController.removeExtraCharge(index);
                        salesController.getTotalCredit();
                      },
                      child: const Icon(
                        Icons.close,
                        size: 16,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ],
      );
    });
  }

  Widget _buildExtraChargesHeader() {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'Extra Charges',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          ),
        ),
        InkWell(
          onTap: _showAddChargeDialog,
          borderRadius: BorderRadius.circular(30),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.mainColor,
              borderRadius: BorderRadius.circular(30),
            ),
            child: const Row(
              children: [
                Icon(Icons.add, size: 14, color: Colors.white),
                SizedBox(width: 4),
                Text(
                  'Add',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── amount paid field ─────────────────────────────────────────────────

  Widget _buildAmountPaidField({required String method}) {
    if (salesController.amountPaid.text == '0.0') {
      salesController.amountPaid.clear();
    }

    return TextFormField(
      controller: salesController.amountPaid,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      onChanged: (_) {
        salesController.getTotalCredit();
        salesController.receipt.refresh();
      },
      decoration: InputDecoration(
        labelText: _amountLabelFor(method),
        hintText: 'Enter amount',
        prefixIcon: const Icon(Icons.payments_outlined),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  String _amountLabelFor(String method) {
    switch (method) {
      case 'Cash':
        return 'Cash Received';
      case 'Mpesa':
        return 'Mpesa Amount';
      case 'Bank':
        return 'Bank Amount';
      case 'Wallet':
        return 'Amount to Deduct';
      case 'Credit':
        return 'Amount Paid Now';
      default:
        return 'Amount';
    }
  }

  // ─── mpesa transaction id (optional) ───────────────────────────────────

  Widget _buildMpesaTransIdField() {
    return TextFormField(
      controller: salesController.mpesaTransId,
      decoration: InputDecoration(
        labelText: 'Mpesa Transaction ID (optional)',
        hintText: 'e.g. QFG3X9KLM2',
        prefixIcon: const Icon(Icons.confirmation_number_outlined),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  // ─── summary card (Total / Paid / Balance or Change) ───────────────────

  Widget _buildPaymentSummary({required String method}) {
    return Obx(() {
      final total = salesController.receipt.value?.totalWithDiscount ?? 0;
      final paid = double.tryParse(salesController.amountPaid.text) ?? 0;
      final diff = total - paid; // >0 balance owed, <0 change due

      final isCredit = method == 'Credit';
      final balanceLabel = diff < 0 ? 'Change' : 'Balance';
      final balanceColor =
          diff > 0 ? (isCredit ? Colors.orange : Colors.red) : Colors.green;

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          children: [
            _PaymentRow(label: 'Total', value: htmlPrice(total)),
            const SizedBox(height: 10),
            _PaymentRow(label: 'Paid', value: htmlPrice(paid)),
            Divider(height: 24, color: Colors.grey.shade300),
            _PaymentRow(
              label: balanceLabel,
              value: htmlPrice(diff.abs()),
              bold: true,
              valueColor: balanceColor,
            ),
          ],
        ),
      );
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  // CUSTOMER ACTIONS
  // ─────────────────────────────────────────────────────────────────────────

  void _openCustomerPicker() {
    customersController.getCustomersInShop('all');
    Get.to(
      () => Customers(
        type: 'sale',
        function: (Customer? customer) {
          if (customer != null) {
            salesController.currentCustomer.value = customer;
            customersController.currentCustomer.value = customer;
          }
        },
      ),
    );
  }

  void _clearCustomer() {
    salesController.currentCustomer.value = null;
    customersController.currentCustomer.value = null;
    salesController.selectedCustomerController.clear();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // PAYMENT METHODS SHEET (picker)
  // ─────────────────────────────────────────────────────────────────────────

  void _showPaymentMethodsSheet() {
    if (Get.isBottomSheetOpen ?? false) return;

    showModalBottomSheet(
      context: Get.context!,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildSheetHandle(),
              const SizedBox(height: 10),
              const Text(
                'Select Payment Method',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              ...salesController.paymentMethods.map(
                (method) => _PaymentMethodOption(
                  method: method as String,
                  icon: _paymentIcon(method),
                  onTap: () => _onPaymentMethodSelected(method),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSheetHandle() {
    return Container(
      width: 35,
      height: 4,
      decoration: BoxDecoration(
        color: Colors.grey.shade300,
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }

  void _onPaymentMethodSelected(String method) {
    if (!_hasItems()) {
      generalAlert(title: 'No items to pay');
      return;
    }

    salesController.paymentType.value = method;

    // Clear amount-paid when switching methods so prior input doesn't bleed in.
    salesController.amountPaid.clear();
    salesController.getTotalCredit();

    Get.back();

    // Split Payment still uses its dedicated bottom sheet.
    if (method == 'Split Payment') {
      Future.delayed(
        const Duration(milliseconds: 150),
        () => _confirmSplitPayment('cashed', paymentType: method),
      );
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // VALIDATION + COMPLETE-SALE DISPATCH
  // ─────────────────────────────────────────────────────────────────────────

  _PaymentValidation _validate(String method) {
    if (!_hasItems()) {
      return _PaymentValidation(canComplete: false, buttonLabel: 'No items');
    }

    final total = salesController.receipt.value?.totalWithDiscount ?? 0;
    final paid = double.tryParse(salesController.amountPaid.text) ?? 0;
    final customer = salesController.currentCustomer.value;

    switch (method) {
      case 'Cash':
        if (paid <= 0) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Enter Cash Received',
          );
        }
        if (paid < total) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Insufficient Cash',
          );
        }
        return _PaymentValidation(
          canComplete: true,
          buttonLabel: 'Complete Sale',
        );

      case 'Mpesa':
      case 'Bank':
        if (paid <= 0) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Enter Amount',
          );
        }
        if (paid < total) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Insufficient Amount',
          );
        }
        return _PaymentValidation(
          canComplete: true,
          buttonLabel: 'Complete Sale',
        );

      case 'Wallet':
        if (customer == null) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Select Customer',
          );
        }
        if ((customer.wallet ?? 0) < total) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Insufficient Wallet',
          );
        }
        return _PaymentValidation(
          canComplete: true,
          buttonLabel: 'Complete Wallet Sale',
        );

      case 'Credit':
        if (customer == null) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Select Customer',
          );
        }
        return _PaymentValidation(
          canComplete: true,
          buttonLabel: 'Complete Credit Sale',
        );

      case 'Split Payment':
        return _PaymentValidation(
          canComplete: true,
          buttonLabel: 'Enter Split Amounts',
        );

      default:
        return _PaymentValidation(
          canComplete: false,
          buttonLabel: 'Complete Sale',
        );
    }
  }

  void _onCompletePressed(String method) {
    // Make sure latest typed amount is reflected on the receipt model.
    salesController.getTotalCredit();

    switch (method) {
      case 'Credit':
        _handleCreditSale(status: 'cashed', paymentType: method);
        break;
      case 'Split Payment':
        _confirmSplitPayment('cashed', paymentType: method);
        break;
      default:
        salesController.saveSale(
          screen: widget.page ?? 'admin',
          status: 'cashed',
        );
    }
  }

  void _handleCreditSale(
      {required String status, required String paymentType}) {
    final customer = salesController.currentCustomer.value;
    final receiptTotal = salesController.receipt.value?.totalWithDiscount ?? 0;

    if (customer == null) {
      generalAlert(
        title: 'Customer Required',
        message: 'Please select customer for credit sale',
      );
      return;
    }

    final creditLimit = customer.creditLimit ?? 0;
    final hasLimit = creditLimit > 0;
    if (hasLimit && creditLimit < receiptTotal) {
      _clearCustomer();
      generalAlert(
        title: 'Error!',
        message: 'Customer has reached credit limit to sell on credit',
        function: Get.back,
      );
      return;
    }

    generalAlert(
      title: 'Confirm',
      message:
          'Are you sure you want to sell on $paymentType to ${customer.name}?',
      function: () => salesController.saveSale(
        screen: widget.page ?? 'admin',
        status: status,
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // ADD EXTRA CHARGE DIALOG
  // ─────────────────────────────────────────────────────────────────────────

  void _showAddChargeDialog() {
    final nameController = TextEditingController();
    final amountController = TextEditingController();
    final nameFocus = FocusNode();
    final amountFocus = FocusNode();

    showDialog(
      context: Get.context!,
      barrierDismissible: true,
      builder: (_) => AlertDialog(
        title: const Text('Add Extra Charge'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: nameController,
                focusNode: nameFocus,
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) =>
                    FocusScope.of(Get.context!).requestFocus(amountFocus),
                decoration: const InputDecoration(labelText: 'Charge Name'),
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: amountController,
                focusNode: amountFocus,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                textInputAction: TextInputAction.done,
                decoration: const InputDecoration(labelText: 'Amount'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: Get.back, child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final name = nameController.text.trim();
              final parsed = double.tryParse(amountController.text.trim());
              if (name.isEmpty || parsed == null) return;

              salesController.addExtraCharge(name: name, amount: parsed);
              salesController.getTotalCredit();
              Get.back();
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // SPLIT PAYMENT SHEET (kept as bottom sheet)
  // ─────────────────────────────────────────────────────────────────────────

  void _confirmSplitPayment(String status, {required String paymentType}) {
    salesController.cashPaid.clear();
    salesController.mpesaCashPaid.clear();
    salesController.bankCashPaid.clear();
    salesController.amountPaid.clear();
    salesController.calculateSplitTotals();

    showModalBottomSheet(
      context: Get.context!,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(Get.context!).viewInsets.bottom + 20,
        ),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: StatefulBuilder(
          builder: (context, setState) => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildSheetHandle(),
              const SizedBox(height: 20),
              const Text(
                'Split Payment',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 20),
              _buildSplitField(
                controller: salesController.cashPaid,
                label: 'Cash Amount',
                setState: setState,
              ),
              const SizedBox(height: 12),
              _buildSplitField(
                controller: salesController.mpesaCashPaid,
                label: 'Mpesa Amount',
                setState: setState,
              ),
              const SizedBox(height: 12),
              _buildSplitField(
                controller: salesController.bankCashPaid,
                label: 'Bank Amount',
                setState: setState,
              ),
              const SizedBox(height: 10),
              _buildSplitSummary(),
              const SizedBox(height: 20),
              _buildSplitCompleteButton(status),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSplitField({
    required TextEditingController controller,
    required String label,
    required StateSetter setState,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      onChanged: (_) {
        salesController.calculateSplitTotals();
        setState(() {});
      },
      decoration: InputDecoration(
        labelText: label,
        hintText: '0',
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  Widget _buildSplitSummary() {
    return Obx(() {
      final total = salesController.receipt.value?.totalWithDiscount ?? 0;
      final entered = double.tryParse(salesController.amountPaid.text) ?? 0;
      final balance = total - entered;

      final cash = double.tryParse(salesController.cashPaid.text) ?? 0;
      final mpesa = double.tryParse(salesController.mpesaCashPaid.text) ?? 0;
      final bank = double.tryParse(salesController.bankCashPaid.text) ?? 0;

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            _SplitRow(label: 'Cash', amount: cash),
            const SizedBox(height: 8),
            _SplitRow(label: 'Mpesa', amount: mpesa),
            const SizedBox(height: 8),
            _SplitRow(label: 'Bank', amount: bank),
            Divider(height: 24, color: Colors.grey.shade300),
            const SizedBox(height: 15),
            _SplitRow(
              label: balance < 0 ? 'Change' : 'Balance',
              amount: balance.abs(),
              bold: true,
              valueColor: balance > 0
                  ? Colors.red
                  : balance < 0
                      ? Colors.orange
                      : Colors.green,
            ),
          ],
        ),
      );
    });
  }

  Widget _buildSplitCompleteButton(String status) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: Builder(builder: (_) {
        final total = salesController.receipt.value?.totalWithDiscount ?? 0;
        final entered = double.tryParse(salesController.amountPaid.text) ?? 0;
        final canComplete = entered > 0 && entered >= total;

        final label = entered <= 0
            ? 'Enter Amount'
            : entered < total
                ? 'Incomplete Payment'
                : 'Complete Sale';

        return ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.mainColor,
            disabledBackgroundColor: AppColors.mainColor.withOpacity(.4),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          onPressed: !canComplete
              ? null
              : () {
                  Get.back();
                  salesController.saveSale(
                    screen: widget.page ?? 'admin',
                    status: status,
                  );
                },
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
        );
      }),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────────────────────────────────

  bool _hasItems() {
    final items = salesController.receipt.value?.items;
    return items != null && items.isNotEmpty;
  }

  String _signedPrice(double value) =>
      value < 0 ? '-${htmlPrice(value.abs())}' : htmlPrice(value);

  IconData _paymentIcon(String method) {
    switch (method) {
      case 'Cash':
        return Icons.payments_outlined;
      case 'Mpesa':
        return Icons.phone_android;
      case 'Bank':
        return Icons.account_balance;
      case 'Credit':
        return Icons.credit_score;
      case 'Split Payment':
        return Icons.splitscreen;
      default:
        return Icons.wallet;
    }
  }
}

// ───────────────────────────────────────────────────────────────────────────
// VALIDATION RESULT
// ───────────────────────────────────────────────────────────────────────────

class _PaymentValidation {
  final bool canComplete;
  final String buttonLabel;
  _PaymentValidation({required this.canComplete, required this.buttonLabel});
}

// ───────────────────────────────────────────────────────────────────────────
// SMALL REUSABLE WIDGETS
// ───────────────────────────────────────────────────────────────────────────

class _SelectedPaymentMethodCard extends StatelessWidget {
  final String method;
  final IconData Function(String) iconResolver;
  final VoidCallback onTap;

  const _SelectedPaymentMethodCard({
    required this.method,
    required this.iconResolver,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.mainColor, width: 1.4),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.04),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: AppColors.mainColor.withOpacity(.08),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(iconResolver(method), color: AppColors.mainColor),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                method,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              size: 16,
              color: Colors.grey.shade500,
            ),
          ],
        ),
      ),
    );
  }
}

class _PaymentMethodOption extends StatelessWidget {
  final String method;
  final IconData icon;
  final VoidCallback onTap;

  const _PaymentMethodOption({
    required this.method,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Row(
          children: [
            Container(
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                color: AppColors.mainColor.withOpacity(.08),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: AppColors.mainColor),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                method,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              size: 15,
              color: Colors.grey.shade500,
            ),
          ],
        ),
      ),
    );
  }
}

class _ClearCustomerButton extends StatelessWidget {
  final VoidCallback onTap;
  const _ClearCustomerButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        width: 24,
        height: 24,
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(.08),
          shape: BoxShape.circle,
        ),
        child: const Icon(Icons.close, size: 14, color: Colors.red),
      ),
    );
  }
}

class _PaymentRow extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;
  final Color? valueColor;

  const _PaymentRow({
    required this.label,
    required this.value,
    this.bold = false,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13,
            color: Colors.grey.shade700,
            fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
            color: valueColor ?? Colors.black,
          ),
        ),
      ],
    );
  }
}

class _SplitRow extends StatelessWidget {
  final String label;
  final double amount;
  final bool bold;
  final Color? valueColor;

  const _SplitRow({
    required this.label,
    required this.amount,
    this.bold = false,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
            color: Colors.grey.shade700,
          ),
        ),
        Text(
          htmlPrice(amount),
          style: TextStyle(
            fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
            color: valueColor ?? Colors.black,
          ),
        ),
      ],
    );
  }
}

class _InfoBanner extends StatelessWidget {
  final Color color;
  final IconData icon;
  final String text;

  const _InfoBanner({
    required this.color,
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(.15)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: color,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

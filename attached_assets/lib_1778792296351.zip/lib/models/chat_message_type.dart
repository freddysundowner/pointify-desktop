enum ChatMessageType {
  sent,
  received,
}

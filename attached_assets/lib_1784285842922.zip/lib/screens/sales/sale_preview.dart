import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controllers/customercontroller.dart';
import '../../controllers/salescontroller.dart';
import '../../functions/functions.dart';
import '../../models/customer.dart';
import '../../utils/colors.dart';
import '../../widgets/alert.dart';
import '../customers/customers_page.dart';

class SalePreview extends StatefulWidget {
  final String? page;

  const SalePreview({super.key, this.page});

  @override
  State<SalePreview> createState() => _SalePreviewState();
}

class _SalePreviewState extends State<SalePreview> {
  final SalesController salesController = Get.find<SalesController>();
  final CustomerController customersController = Get.find<CustomerController>();

  late final Worker _mpesaSuccessWorker;

  @override
  void initState() {
    super.initState();

    salesController.paymentType.value = 'Cash';
    salesController.extraCharges.clear();

    // Auto-complete the sale the moment an STK payment is confirmed AND fully paid.
    _mpesaSuccessWorker = ever(salesController.mpesaStatus, (status) {
      if (status != 'success') return;
      if (salesController.paymentType.value != 'Mpesa') return;

      final total = salesController.receipt.value?.totalWithDiscount ?? 0;
      final paid = double.tryParse(salesController.amountPaid.text) ?? 0;
      if (paid + 0.0001 < total)
        return; // not fully covered → leave it to the cashier

      salesController.saveSale(
        screen: widget.page ?? 'admin',
        status: 'cashed',
      );
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(
        const Duration(milliseconds: 250),
        () => _showPaymentMethodsSheet(),
      );
    });
  }

  @override
  void dispose() {
    _mpesaSuccessWorker.dispose(); // ← clean up the worker
    salesController.resetMpesaFlow();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff7f7fb),
      bottomNavigationBar: _buildBottomBar(),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            child: Column(
              children: [
                _buildCloseButton(),
                const SizedBox(height: 12),
                _buildTotalCard(),
                const SizedBox(height: 10),
                _buildPaymentMethodsLabel(),
                const SizedBox(height: 12),
                _buildPaymentSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // BOTTOM BAR — single button completes whatever method is selected
  // ─────────────────────────────────────────────────────────────────────────

  Widget _buildBottomBar() {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.04),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: Obx(() {
          final method = salesController.paymentType.value ?? 'Cash';
          final state = _validate(method);

          return SizedBox(
            height: 52,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.mainColor,
                disabledBackgroundColor: AppColors.mainColor.withOpacity(.4),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              onPressed:
                  state.canComplete ? () => _onCompletePressed(method) : null,
              child: Text(
                state.buttonLabel,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // HEADER WIDGETS
  // ─────────────────────────────────────────────────────────────────────────

  Widget _buildCloseButton() {
    return Align(
      alignment: Alignment.centerRight,
      child: InkWell(
        onTap: Get.back,
        borderRadius: BorderRadius.circular(30),
        child: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: const Icon(Icons.close, size: 18),
        ),
      ),
    );
  }

  Widget _buildTotalCard() {
    return Obx(() {
      final receipt = salesController.receipt.value;
      final total = receipt?.totalWithDiscount?.toStringAsFixed(2) ?? '0';
      final itemCount = receipt?.items?.length ?? 0;

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              AppColors.mainColor,
              AppColors.mainColor.withOpacity(.85),
            ],
          ),
          borderRadius: BorderRadius.circular(26),
        ),
        child: Column(
          children: [
            const Text(
              'TOTAL AMOUNT',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              htmlPrice(total),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '$itemCount item(s)',
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ],
        ),
      );
    });
  }

  Widget _buildPaymentMethodsLabel() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        'Payment Methods',
        style: TextStyle(
          color: Colors.grey.shade700,
          fontWeight: FontWeight.w700,
          fontSize: 13,
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // PAYMENT SECTION
  // ─────────────────────────────────────────────────────────────────────────

  Widget _buildPaymentSection() {
    return Obx(() {
      final method = (salesController.paymentType.value ?? '').isEmpty
          ? 'Cash'
          : salesController.paymentType.value!;

      return Column(
        children: [
          _SelectedPaymentMethodCard(
            method: method,
            iconResolver: _paymentIcon,
            onTap: _showPaymentMethodsSheet,
          ),
          if (method != 'Split Payment')
            _buildInlinePaymentCard(
              method,
              openSheetOnTap: true,
            ),
          _buildChangeMethodLink(),
        ],
      );
    });
  }

  Widget _buildChangeMethodLink() {
    return InkWell(
      onTap: _showPaymentMethodsSheet,
      child: Padding(
        padding: const EdgeInsets.only(top: 2, bottom: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Change payment method',
              style: TextStyle(
                color: AppColors.mainColor,
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
            const SizedBox(width: 4),
            Icon(
              Icons.keyboard_arrow_down,
              size: 18,
              color: AppColors.mainColor,
            ),
          ],
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // INLINE PAYMENT CARD — used by Cash / Mpesa / Bank / Wallet / Credit
  // ─────────────────────────────────────────────────────────────────────────

  Widget _buildInlinePaymentCard(
    String method, {
    bool openSheetOnTap = false,
    FocusNode? amountFocus,
  }) {
    final needsCustomer = method == 'Credit' || method == 'Wallet';
    final isWallet = method == 'Wallet';
    final isMpesa = method == 'Mpesa';

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (needsCustomer) ...[
            _buildCustomerSelector(),
            const SizedBox(height: 12),
          ],
          if (isWallet) ...[
            _buildWalletBalanceRow(),
            const SizedBox(height: 12),
          ],
          _buildInlineExtraCharges(),
          const SizedBox(height: 12),
          if (isMpesa)
            _buildMpesaSection()
          else
            _buildAmountPaidField(
              method: method,
              openSheetOnTap: openSheetOnTap,
              focusNode: amountFocus,
            ),
          const SizedBox(height: 14),
          _buildPaymentSummary(method: method),
        ],
      ),
    );
  }

  // ─── customer selector ─────────────────────────────────────────────────

  Widget _buildCustomerSelector() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: InkWell(
        onTap: _openCustomerPicker,
        child: Obx(() {
          final customer = salesController.currentCustomer.value;
          final name = customer?.name ?? 'Select Customer';
          final hasCustomer = customer != null;

          return Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: AppColors.mainColor.withOpacity(.08),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  Icons.person_outline,
                  color: AppColors.mainColor,
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: hasCustomer ? Colors.black : Colors.grey,
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      hasCustomer ? 'Tap to change' : 'Required',
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              if (hasCustomer)
                _ClearCustomerButton(onTap: _clearCustomer)
              else
                Icon(
                  Icons.arrow_forward_ios,
                  size: 13,
                  color: Colors.grey.shade500,
                ),
            ],
          );
        }),
      ),
    );
  }

  // ─── wallet balance row ────────────────────────────────────────────────

  Widget _buildWalletBalanceRow() {
    return Obx(() {
      final total = salesController.receipt.value?.totalWithDiscount ?? 0;
      final wallet = salesController.currentCustomer.value?.wallet ?? 0;
      final remaining = wallet - total;
      final hasCustomer = salesController.currentCustomer.value != null;

      if (!hasCustomer) {
        return const _InfoBanner(
          color: Colors.orange,
          icon: Icons.info_outline,
          text: 'Select a customer to see their wallet balance.',
        );
      }

      final insufficient = wallet < total;

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color:
              insufficient ? Colors.red.withOpacity(.06) : Colors.grey.shade50,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: insufficient
                ? Colors.red.withOpacity(.15)
                : Colors.grey.shade200,
          ),
        ),
        child: Column(
          children: [
            _PaymentRow(
              label: 'Wallet Balance',
              value: _signedPrice(wallet),
              valueColor: wallet < 0 ? Colors.red : Colors.green,
            ),
            const SizedBox(height: 6),
            _PaymentRow(
              label: 'After Sale',
              value: _signedPrice(remaining),
              bold: true,
              valueColor: remaining < 0 ? Colors.red : Colors.green,
            ),
            if (insufficient) ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  const Icon(
                    Icons.warning_amber_rounded,
                    color: Colors.red,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Wallet balance is not enough for this sale.',
                      style: TextStyle(
                        color: Colors.red.shade700,
                        fontWeight: FontWeight.w600,
                        fontSize: 11,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      );
    });
  }

  // ─── extra charges ─────────────────────────────────────────────────────

  Widget _buildInlineExtraCharges() {
    return Obx(() {
      final charges = salesController.extraCharges;

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildExtraChargesHeader(),
          if (charges.isNotEmpty) ...[
            const SizedBox(height: 10),
            ...List.generate(charges.length, (index) {
              final charge = charges[index];
              return Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        charge['name'] ?? '',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Text(
                      htmlPrice(charge['amount'] ?? 0),
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(width: 8),
                    InkWell(
                      onTap: () {
                        salesController.removeExtraCharge(index);
                        salesController.getTotalCredit();
                        salesController.receipt.refresh();
                      },
                      child: const Icon(
                        Icons.close,
                        size: 16,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ],
      );
    });
  }

  Widget _buildExtraChargesHeader() {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'Extra Charges',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          ),
        ),
        InkWell(
          onTap: _showAddChargeDialog,
          borderRadius: BorderRadius.circular(30),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.mainColor,
              borderRadius: BorderRadius.circular(30),
            ),
            child: const Row(
              children: [
                Icon(Icons.add, size: 14, color: Colors.white),
                SizedBox(width: 4),
                Text(
                  'Add',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── amount paid field ─────────────────────────────────────────────────

  Widget _buildAmountPaidField({
    required String method,
    bool openSheetOnTap = false,
    FocusNode? focusNode,
  }) {
    if (salesController.amountPaid.text == '0.0') {
      salesController.amountPaid.clear();
    }

    final field = TextFormField(
      focusNode: focusNode,
      autofocus: focusNode != null,
      controller: salesController.amountPaid,
      readOnly: openSheetOnTap,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      onChanged: (_) {
        salesController.getTotalCredit();
        salesController.receipt.refresh();
      },
      decoration: InputDecoration(
        labelText: _amountLabelFor(method),
        hintText: openSheetOnTap ? 'Tap to enter amount' : 'Enter amount',
        suffixIcon:
            openSheetOnTap ? const Icon(Icons.keyboard_arrow_up_rounded) : null,
        prefixIcon: Icon(
          openSheetOnTap ? Icons.open_in_new_rounded : Icons.payments_outlined,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    );

    if (!openSheetOnTap) return field;

    return InkWell(
      onTap: () => _showSinglePaymentSheet(method),
      borderRadius: BorderRadius.circular(14),
      child: IgnorePointer(
        child: field,
      ),
    );
  }

  String _amountLabelFor(String method) {
    switch (method) {
      case 'Cash':
        return 'Cash Received';
      case 'Mpesa':
        return 'Mpesa Amount';
      case 'Bank':
        return 'Bank Amount';
      case 'Wallet':
        return 'Amount to Deduct';
      case 'Credit':
        return 'Amount Paid Now';
      default:
        return 'Amount';
    }
  }

  Widget _buildSplitMpesaStk(StateSetter setState) {
    return Obx(() {
      if (!salesController.shopHasMpesa) return const SizedBox.shrink();
      final status = salesController.mpesaStatus.value;
      final busy = status == 'sending' || status == 'waiting';
      final done = status == 'success';
      return Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFormField(
              controller: salesController.mpesaPhone,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                labelText: 'Customer phone (for STK)',
                hintText: '07XX XXX XXX',
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
            const SizedBox(height: 8),
            if (done)
              Row(children: [
                const Icon(Icons.check_circle, color: Colors.green, size: 18),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                      'Mpesa paid · ${salesController.mpesaTransId.text}',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                ),
              ])
            else
              SizedBox(
                width: double.infinity,
                height: 44,
                child: ElevatedButton.icon(
                  onPressed: busy
                      ? null
                      : () async {
                          await salesController.sendStkPushSplit();
                          setState(() {});
                        },
                  icon: busy
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.send_rounded, size: 18),
                  label: Text(
                      busy ? 'Waiting for PIN…' : 'Send STK for Mpesa amount'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.mainColor,
                    foregroundColor: Colors.white,
                    disabledBackgroundColor:
                        AppColors.mainColor.withOpacity(.5),
                    disabledForegroundColor: Colors.white70,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
            if (status == 'failed' &&
                salesController.mpesaError.value.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(salesController.mpesaError.value,
                    style: const TextStyle(color: Colors.red, fontSize: 12)),
              ),
          ],
        ),
      );
    });
  }

  Widget _buildMpesaManualCode() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextFormField(
          controller: salesController.amountPaid,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          onChanged: (_) {
            salesController.getTotalCredit();
            salesController.receipt.refresh();
          },
          decoration: InputDecoration(
            labelText: 'Mpesa Amount',
            hintText: 'Enter amount received',
            prefixIcon: const Icon(Icons.payments_outlined),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: salesController.mpesaTransId,
          textCapitalization: TextCapitalization.characters,
          decoration: InputDecoration(
            labelText: 'Mpesa Transaction Code',
            hintText: 'e.g. QFG3X9KLM2',
            prefixIcon: const Icon(Icons.confirmation_number_outlined),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        ),
      ],
    );
  }

  // ── M-PESA (clean, single section with a mode switcher) ──────────────────
  Widget _buildMpesaSection() {
    return Obx(() {
      if (!salesController.shopHasMpesa) {
        return _buildMpesaManualCode();
      }
      final mode = salesController.mpesaEntryMode.value;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // switcher
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: const Color(0xfff1f1f6),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(children: [
              _modeTab('stk', 'STK Push', Icons.send_rounded, mode),
              _modeTab(
                  'paid', 'Already Paid', Icons.receipt_long_outlined, mode),
              _modeTab('code', 'Enter Code', Icons.dialpad_rounded, mode),
            ]),
          ),
          const SizedBox(height: 14),
          if (mode == 'stk')
            _mpesaStkBody()
          else if (mode == 'paid')
            _mpesaPaidBody()
          else
            _mpesaCodeBody(),
        ],
      );
    });
  }

  Widget _modeTab(String key, String label, IconData icon, String current) {
    final selected = current == key;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => salesController.mpesaEntryMode.value = key,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(vertical: 9),
          decoration: BoxDecoration(
            color: selected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
            boxShadow: selected
                ? [
                    BoxShadow(
                        color: Colors.black.withOpacity(.06),
                        blurRadius: 6,
                        offset: const Offset(0, 2))
                  ]
                : null,
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon,
                size: 18,
                color: selected ? AppColors.mainColor : Colors.grey.shade500),
            const SizedBox(height: 3),
            Text(label,
                style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color:
                        selected ? AppColors.mainColor : Colors.grey.shade600)),
          ]),
        ),
      ),
    );
  }

  InputDecoration _mpesaInput(String label, String hint, IconData icon) =>
      InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, size: 20),
        isDense: true,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      );

// ── mode bodies ──────────────────────────────────────────────────────────
  Widget _mpesaStkBody() {
    return Obx(() {
      final status = salesController.mpesaStatus.value;
      if (status == 'success') return _mpesaSuccessTile();
      final busy = status == 'sending' || status == 'waiting';
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        TextFormField(
          controller: salesController.mpesaPhone,
          enabled: !busy,
          keyboardType: TextInputType.phone,
          decoration: _mpesaInput(
              'Customer phone', '07XX XXX XXX', Icons.phone_android),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 48,
          child: ElevatedButton.icon(
            onPressed: busy ? null : salesController.sendStkPush,
            icon: busy
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.send_rounded, size: 18),
            label: Text(status == 'waiting'
                ? 'Waiting for PIN…'
                : status == 'sending'
                    ? 'Sending…'
                    : 'Send STK Push'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.mainColor,
              foregroundColor: Colors.white, // ← icon + text white
              disabledBackgroundColor: AppColors.mainColor.withOpacity(.5),
              disabledForegroundColor: Colors.white70, // ← legible while busy
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),
        if (busy)
          Center(
              child: TextButton(
                  onPressed: salesController.resetMpesaFlow,
                  child: const Text('Cancel'))),
        if (salesController.mpesaError.value.isNotEmpty)
          Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(salesController.mpesaError.value,
                  style: const TextStyle(color: Colors.red, fontSize: 12))),
      ]);
    });
  }

  Widget _mpesaPaidBody() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      OutlinedButton.icon(
        onPressed: salesController.openMpesaPaymentPicker,
        icon: const Icon(Icons.add, size: 18),
        label: const Text('Add M-Pesa payment'),
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.mainColor,
          side: BorderSide(color: AppColors.mainColor),
          padding: const EdgeInsets.symmetric(vertical: 12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      Obx(() {
        final picks = salesController.selectedMpesaPayments;
        if (picks.isEmpty) {
          return const Padding(
              padding: EdgeInsets.only(top: 10),
              child: Text('No payments added yet.',
                  style: TextStyle(color: Colors.grey, fontSize: 12)));
        }
        return Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Column(
              children: picks
                  .map((p) => Container(
                        margin: const EdgeInsets.only(bottom: 6),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: const Color(0xfff5faf6),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.green.shade100),
                        ),
                        child: Row(children: [
                          const Icon(Icons.check_circle,
                              color: Colors.green, size: 18),
                          const SizedBox(width: 8),
                          Expanded(
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                Text(
                                    p.payerName.isEmpty
                                        ? p.mpesaRef
                                        : p.payerName,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13)),
                                Text(p.mpesaRef,
                                    style: TextStyle(
                                        color: Colors.grey.shade500,
                                        fontSize: 11)),
                              ])),
                          Text('KES ${p.amount.toStringAsFixed(2)}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 13)),
                          const SizedBox(width: 6),
                          InkWell(
                              onTap: () =>
                                  salesController.removeMpesaPayment(p),
                              child: Icon(Icons.close,
                                  size: 16, color: Colors.red.shade300)),
                        ]),
                      ))
                  .toList()),
        );
      }),
    ]);
  }

  Widget _mpesaCodeBody() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      TextFormField(
        controller: salesController.amountPaid,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        onChanged: (_) {
          salesController.getTotalCredit();
          salesController.receipt.refresh();
        },
        decoration:
            _mpesaInput('Amount', 'Enter amount', Icons.payments_outlined),
      ),
      const SizedBox(height: 10),
      TextFormField(
        controller: salesController.mpesaTransId,
        textCapitalization: TextCapitalization.characters,
        decoration: _mpesaInput('M-Pesa code', 'e.g. UEV8O6C7MO',
            Icons.confirmation_number_outlined),
      ),
    ]);
  }

  Widget _mpesaSuccessTile() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xfff0faf2),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.green.shade200),
      ),
      child: Row(children: [
        const Icon(Icons.check_circle, color: Colors.green, size: 22),
        const SizedBox(width: 10),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Payment received',
              style: TextStyle(fontWeight: FontWeight.w700)),
          Text(salesController.mpesaRef.value ?? '',
              style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
        ])),
        TextButton(
            onPressed: salesController.resetMpesaFlow,
            child: const Text('Redo')),
      ]),
    );
  }

  // ─── summary card (Total / Paid / Balance or Change) ───────────────────

  Widget _buildPaymentSummary({required String method}) {
    return Obx(() {
      final total = salesController.receipt.value?.totalWithDiscount ?? 0;
      final paid = double.tryParse(salesController.amountPaid.text) ?? 0;
      final diff = total - paid; // >0 balance owed, <0 change due

      final isCredit = method == 'Credit';
      final balanceLabel = diff < 0 ? 'Change' : 'Balance';
      final balanceColor =
          diff > 0 ? (isCredit ? Colors.orange : Colors.red) : Colors.green;

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          children: [
            _PaymentRow(label: 'Total', value: htmlPrice(total)),
            const SizedBox(height: 10),
            _PaymentRow(label: 'Paid', value: htmlPrice(paid)),
            Divider(height: 24, color: Colors.grey.shade300),
            _PaymentRow(
              label: balanceLabel,
              value: htmlPrice(diff.abs()),
              bold: true,
              valueColor: balanceColor,
            ),
          ],
        ),
      );
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  // CUSTOMER ACTIONS
  // ─────────────────────────────────────────────────────────────────────────

  void _openCustomerPicker() {
    customersController.getCustomersInShop('all');
    Get.to(
      () => Customers(
        type: 'sale',
        function: (Customer? customer) {
          if (customer != null) {
            salesController.currentCustomer.value = customer;
            customersController.currentCustomer.value = customer;
          }
        },
      ),
    );
  }

  void _clearCustomer() {
    salesController.currentCustomer.value = null;
    customersController.currentCustomer.value = null;
    salesController.selectedCustomerController.clear();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // PAYMENT METHODS SHEET (picker)
  // ─────────────────────────────────────────────────────────────────────────

  void _showPaymentMethodsSheet() {
    if (Get.isBottomSheetOpen ?? false) return;

    showModalBottomSheet(
      context: Get.context!,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildSheetHandle(),
              const SizedBox(height: 10),
              const Text(
                'Select Payment Method',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              ...salesController.paymentMethods.map(
                (method) => _PaymentMethodOption(
                  method: method as String,
                  icon: _paymentIcon(method),
                  onTap: () => _onPaymentMethodSelected(method),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSheetHandle() {
    return Container(
      width: 35,
      height: 4,
      decoration: BoxDecoration(
        color: Colors.grey.shade300,
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }

  void _onPaymentMethodSelected(String method) {
    if (!_hasItems()) {
      generalAlert(title: 'No items to pay');
      return;
    }

    salesController.paymentType.value = method;

    // Clear amount-paid when switching methods so prior input doesn't bleed in.
    salesController.amountPaid.clear();
    salesController.getTotalCredit();

    Get.back();

    // Split Payment still uses its dedicated bottom sheet.
    Future.delayed(
      const Duration(milliseconds: 150),
      () {
        if (method == 'Split Payment') {
          _confirmSplitPayment(
            'cashed',
            paymentType: method,
          );
        } else {
          _showSinglePaymentSheet(method);
        }
      },
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // VALIDATION + COMPLETE-SALE DISPATCH
  // ─────────────────────────────────────────────────────────────────────────

  _PaymentValidation _validate(String method) {
    if (!_hasItems()) {
      return _PaymentValidation(canComplete: false, buttonLabel: 'No items');
    }

    final total = salesController.receipt.value?.totalWithDiscount ?? 0;
    final paid = double.tryParse(salesController.amountPaid.text) ?? 0;
    final customer = salesController.currentCustomer.value;

    switch (method) {
      case 'Cash':
        if (paid <= 0) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Enter Cash Received',
          );
        }
        if (paid < total) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Insufficient Cash',
          );
        }
        return _PaymentValidation(
          canComplete: true,
          buttonLabel: 'Complete Sale',
        );

      case 'Mpesa':
        if (paid <= 0) {
          return _PaymentValidation(
              canComplete: false, buttonLabel: 'Add M-Pesa Payment');
        }
        if (paid < total) {
          return _PaymentValidation(
              canComplete: false,
              buttonLabel: 'Add ${htmlPrice(total - paid)} more');
        }
        return _PaymentValidation(
            canComplete: true, buttonLabel: 'Complete Sale');
      case 'Bank':
        if (paid <= 0) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Enter Amount',
          );
        }
        if (paid < total) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Insufficient Amount',
          );
        }
        return _PaymentValidation(
          canComplete: true,
          buttonLabel: 'Complete Sale',
        );

      case 'Wallet':
        if (customer == null) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Select Customer',
          );
        }
        if ((customer.wallet ?? 0) < total) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Insufficient Wallet',
          );
        }
        return _PaymentValidation(
          canComplete: true,
          buttonLabel: 'Complete Wallet Sale',
        );

      case 'Credit':
        if (customer == null) {
          return _PaymentValidation(
            canComplete: false,
            buttonLabel: 'Select Customer',
          );
        }
        return _PaymentValidation(
          canComplete: true,
          buttonLabel: 'Complete Credit Sale',
        );

      case 'Split Payment':
        return _PaymentValidation(
          canComplete: true,
          buttonLabel: 'Enter Split Amounts',
        );

      default:
        return _PaymentValidation(
          canComplete: false,
          buttonLabel: 'Complete Sale',
        );
    }
  }

  // void _onCompletePressed(String method) {
  //   // Make sure latest typed amount is reflected on the receipt model.
  //   salesController.getTotalCredit();

  //   switch (method) {
  //     case 'Credit':
  //       _handleCreditSale(status: 'cashed', paymentType: method);
  //       break;
  //     case 'Split Payment':
  //       _confirmSplitPayment('cashed', paymentType: method);
  //       break;
  //     default:
  //       salesController.saveSale(
  //         screen: widget.page ?? 'admin',
  //         status: 'cashed',
  //       );
  //   }
  // }
  void _onCompletePressed(String method) {
    salesController.getTotalCredit();

    if (method == 'Split Payment') {
      _confirmSplitPayment(
        'cashed',
        paymentType: method,
      );
      return;
    }

    _showSinglePaymentSheet(method);
  }

  void _showSinglePaymentSheet(String method) {
    final amountFocus = FocusNode();
    showModalBottomSheet(
      context: Get.context!,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 70,
          bottom: MediaQuery.of(Get.context!).viewInsets.bottom + 20,
        ),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(24),
          ),
        ),
        child: StatefulBuilder(
          builder: (context, setState) => ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * .82,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      const SizedBox(width: 40),
                      Expanded(
                        child: Column(
                          children: [
                            _buildSheetHandle(),
                            const SizedBox(height: 12),
                            Text(
                              method,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        onTap: Get.back,
                        borderRadius: BorderRadius.circular(30),
                        child: Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.close, size: 18),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _buildInlinePaymentCard(
                    method,
                    openSheetOnTap: false,
                    amountFocus: amountFocus,
                  ),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: Obx(() {
                      final state = _validate(method);

                      return ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.mainColor,
                          disabledBackgroundColor:
                              AppColors.mainColor.withOpacity(.4),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        onPressed: !state.canComplete
                            ? null
                            : () {
                                Get.back();

                                if (method == 'Credit') {
                                  _handleCreditSale(
                                    status: 'cashed',
                                    paymentType: method,
                                  );
                                } else {
                                  salesController.saveSale(
                                    screen: widget.page ?? 'admin',
                                    status: 'cashed',
                                  );
                                }
                              },
                        child: Text(
                          state.buttonLabel,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      );
                    }),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _handleCreditSale(
      {required String status, required String paymentType}) {
    final customer = salesController.currentCustomer.value;
    final receiptTotal = salesController.receipt.value?.totalWithDiscount ?? 0;

    if (customer == null) {
      generalAlert(
        title: 'Customer Required',
        message: 'Please select customer for credit sale',
      );
      return;
    }

    final creditLimit = customer.creditLimit ?? 0;
    final hasLimit = creditLimit > 0;
    if (hasLimit && creditLimit < receiptTotal) {
      _clearCustomer();
      generalAlert(
        title: 'Error!',
        message: 'Customer has reached credit limit to sell on credit',
        function: Get.back,
      );
      return;
    }

    generalAlert(
      title: 'Confirm',
      message:
          'Are you sure you want to sell on $paymentType to ${customer.name}?',
      function: () => salesController.saveSale(
        screen: widget.page ?? 'admin',
        status: status,
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // ADD EXTRA CHARGE DIALOG
  // ─────────────────────────────────────────────────────────────────────────

  void _showAddChargeDialog() {
    final nameController = TextEditingController();
    final amountController = TextEditingController();
    final nameFocus = FocusNode();
    final amountFocus = FocusNode();

    showDialog(
      context: Get.context!,
      barrierDismissible: true,
      builder: (_) => AlertDialog(
        title: const Text('Add Extra Charge'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: nameController,
                focusNode: nameFocus,
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) =>
                    FocusScope.of(Get.context!).requestFocus(amountFocus),
                decoration: const InputDecoration(labelText: 'Charge Name'),
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: amountController,
                focusNode: amountFocus,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                textInputAction: TextInputAction.done,
                decoration: const InputDecoration(labelText: 'Amount'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: Get.back, child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final name = nameController.text.trim();
              final parsed = double.tryParse(amountController.text.trim());
              if (name.isEmpty || parsed == null) return;

              salesController.addExtraCharge(name: name, amount: parsed);
              salesController.getTotalCredit();
              salesController.receipt.refresh();
              Get.back();
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // SPLIT PAYMENT SHEET (kept as bottom sheet)
  // ─────────────────────────────────────────────────────────────────────────

  void _confirmSplitPayment(String status, {required String paymentType}) {
    salesController.cashPaid.clear();
    salesController.mpesaCashPaid.clear();
    salesController.bankCashPaid.clear();
    salesController.amountPaid.clear();
    salesController.calculateSplitTotals();

    showModalBottomSheet(
      context: Get.context!,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(Get.context!).viewInsets.bottom + 20,
        ),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: StatefulBuilder(
          builder: (context, setState) => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildSheetHandle(),
              const SizedBox(height: 20),
              const Text(
                'Split Payment',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 20),
              _buildSplitField(
                controller: salesController.cashPaid,
                label: 'Cash Amount',
                setState: setState,
              ),
              const SizedBox(height: 12),
              _buildSplitField(
                controller: salesController.mpesaCashPaid,
                label: 'Mpesa Amount',
                setState: setState,
              ),
              _buildSplitMpesaStk(setState),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () async {
                    await salesController.openMpesaPaymentPicker(
                      onSelect: salesController.selectMpesaForSplit,
                    );
                    salesController
                        .calculateSplitTotals(); // recompute totals + amountPaid
                    setState(() {}); // refresh the sheet's fields
                  },
                  icon: const Icon(Icons.search, size: 18),
                  label: const Text('Select M-Pesa payment'),
                  style: TextButton.styleFrom(
                      foregroundColor: AppColors.mainColor),
                ),
              ),
              const SizedBox(height: 12),
              _buildSplitField(
                controller: salesController.bankCashPaid,
                label: 'Bank Amount',
                setState: setState,
              ),
              const SizedBox(height: 10),
              _buildSplitSummary(),
              const SizedBox(height: 20),
              _buildSplitCompleteButton(status),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSplitField({
    required TextEditingController controller,
    required String label,
    required StateSetter setState,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      onChanged: (_) {
        salesController.calculateSplitTotals();
        setState(() {});
      },
      decoration: InputDecoration(
        labelText: label,
        hintText: '0',
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  Widget _buildSplitSummary() {
    return Obx(() {
      final total = salesController.receipt.value?.totalWithDiscount ?? 0;
      final entered = double.tryParse(salesController.amountPaid.text) ?? 0;
      final balance = total - entered;

      final cash = double.tryParse(salesController.cashPaid.text) ?? 0;
      final mpesa = double.tryParse(salesController.mpesaCashPaid.text) ?? 0;
      final bank = double.tryParse(salesController.bankCashPaid.text) ?? 0;

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            _SplitRow(label: 'Cash', amount: cash),
            const SizedBox(height: 8),
            _SplitRow(label: 'Mpesa', amount: mpesa),
            const SizedBox(height: 8),
            _SplitRow(label: 'Bank', amount: bank),
            Divider(height: 24, color: Colors.grey.shade300),
            const SizedBox(height: 15),
            _SplitRow(
              label: balance < 0 ? 'Change' : 'Balance',
              amount: balance.abs(),
              bold: true,
              valueColor: balance > 0
                  ? Colors.red
                  : balance < 0
                      ? Colors.orange
                      : Colors.green,
            ),
          ],
        ),
      );
    });
  }

  Widget _buildSplitCompleteButton(String status) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: Builder(builder: (_) {
        final total = salesController.receipt.value?.totalWithDiscount ?? 0;
        final entered = double.tryParse(salesController.amountPaid.text) ?? 0;
        final canComplete = entered > 0 && entered >= total;

        final label = entered <= 0
            ? 'Enter Amount'
            : entered < total
                ? 'Incomplete Payment'
                : 'Complete Sale';

        return ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.mainColor,
            disabledBackgroundColor: AppColors.mainColor.withOpacity(.4),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          onPressed: !canComplete
              ? null
              : () {
                  Get.back();
                  salesController.saveSale(
                    screen: widget.page ?? 'admin',
                    status: status,
                  );
                },
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
        );
      }),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────────────────────────────────

  bool _hasItems() {
    final items = salesController.receipt.value?.items;
    return items != null && items.isNotEmpty;
  }

  String _signedPrice(double value) =>
      value < 0 ? '-${htmlPrice(value.abs())}' : htmlPrice(value);

  IconData _paymentIcon(String method) {
    switch (method) {
      case 'Cash':
        return Icons.payments_outlined;
      case 'Mpesa':
        return Icons.phone_android;
      case 'Bank':
        return Icons.account_balance;
      case 'Credit':
        return Icons.credit_score;
      case 'Split Payment':
        return Icons.splitscreen;
      default:
        return Icons.wallet;
    }
  }
}

// ───────────────────────────────────────────────────────────────────────────
// VALIDATION RESULT
// ───────────────────────────────────────────────────────────────────────────

class _PaymentValidation {
  final bool canComplete;
  final String buttonLabel;
  _PaymentValidation({required this.canComplete, required this.buttonLabel});
}

// ───────────────────────────────────────────────────────────────────────────
// SMALL REUSABLE WIDGETS
// ───────────────────────────────────────────────────────────────────────────

class _SelectedPaymentMethodCard extends StatelessWidget {
  final String method;
  final IconData Function(String) iconResolver;
  final VoidCallback onTap;

  const _SelectedPaymentMethodCard({
    required this.method,
    required this.iconResolver,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.mainColor, width: 1.4),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.04),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: AppColors.mainColor.withOpacity(.08),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(iconResolver(method), color: AppColors.mainColor),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                method,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              size: 16,
              color: Colors.grey.shade500,
            ),
          ],
        ),
      ),
    );
  }
}

class _PaymentMethodOption extends StatelessWidget {
  final String method;
  final IconData icon;
  final VoidCallback onTap;

  const _PaymentMethodOption({
    required this.method,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Row(
          children: [
            Container(
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                color: AppColors.mainColor.withOpacity(.08),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: AppColors.mainColor),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                method,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              size: 15,
              color: Colors.grey.shade500,
            ),
          ],
        ),
      ),
    );
  }
}

class _ClearCustomerButton extends StatelessWidget {
  final VoidCallback onTap;
  const _ClearCustomerButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        width: 24,
        height: 24,
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(.08),
          shape: BoxShape.circle,
        ),
        child: const Icon(Icons.close, size: 14, color: Colors.red),
      ),
    );
  }
}

class _PaymentRow extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;
  final Color? valueColor;

  const _PaymentRow({
    required this.label,
    required this.value,
    this.bold = false,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13,
            color: Colors.grey.shade700,
            fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
            color: valueColor ?? Colors.black,
          ),
        ),
      ],
    );
  }
}

class _SplitRow extends StatelessWidget {
  final String label;
  final double amount;
  final bool bold;
  final Color? valueColor;

  const _SplitRow({
    required this.label,
    required this.amount,
    this.bold = false,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
            color: Colors.grey.shade700,
          ),
        ),
        Text(
          htmlPrice(amount),
          style: TextStyle(
            fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
            color: valueColor ?? Colors.black,
          ),
        ),
      ],
    );
  }
}

class _InfoBanner extends StatelessWidget {
  final Color color;
  final IconData icon;
  final String text;

  const _InfoBanner({
    required this.color,
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(.15)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: color,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

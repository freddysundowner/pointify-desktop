const Attendant = require("../models/attendant");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Admin = require("../models/admin"); // Adjust the import path as needed

// Create Attendant with shopId
const createAttendant = async (req, res) => {
  try {
    const { username, uniqueDigits, password, shopId, adminId, permissions } =
      req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const attendant = new Attendant({
      username,
      uniqueDigits,
      password: hashedPassword,
      shopId,
      adminId,
      permissions,
    });
    const newAttendant = await attendant.save();

    res.status(201).json(newAttendant);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error creating attendant" });
  }
};

// Get all Attendants
const getAllAttendants = async (req, res) => {
  try {
    let { id } = req.params;
    const attendants = await Attendant.find({adminId: id}).populate("shopId");
    res.status(200).json(attendants);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching attendants" });
  }

  // Implement the remaining CRUD operations
};

// Update Attendant with shopId
const updateAttendant = async (req, res) => {
  try {
    const { id } = req.params;
    const { username, uniqueDigits, password, shopId, permissions,lastAppRatingDate } = req.body;
    console.log(req.body)

    let data = { username, uniqueDigits, shopId, permissions };
    if (password) {
      let hashedPassword = password;
      hashedPassword = await bcrypt.hash(password, 10);
      data.password = hashedPassword;
    }
    if (lastAppRatingDate) {
      data['lastAppRatingDate'] = lastAppRatingDate;
    }

    var updatedAttendant = await Attendant.findByIdAndUpdate(id, data, {
      new: true,
    });

    if (!updatedAttendant) {
      return res.status(404).json({ error: "Attendant not found" });
    }

    res.status(200).json(updatedAttendant);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating attendant" });
  }
};

// Delete Attendant
const deleteAttendant = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedAttendant = await Attendant.findByIdAndDelete(id);

    if (!deletedAttendant) {
      return res.status(404).json({ error: "Attendant not found" });
    }

    return res.status(200).json({ message: "Attendant deleted" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error deleting attendant" });
  }
};

// Get Attendants by Shop ID
const getAttendantsByShopOrAdminId = async (req, res) => {
  try {
    const { shopId, adminId } = req.query;
    let filter = {};
    if (shopId) {
      filter.shopId = shopId;
    }
    if (adminId) {
      filter.adminId = adminId;
      const adminRes = await Admin.findById(adminId);
      filter.shopId =  adminRes?.primaryShop;
    }
    console.log(filter)
    const attendants = await Attendant.find(filter).populate("shopId");
    res.status(200).json(attendants);
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .json({ error: "Error fetching attendants by shop or admin ID" });
  }
};

// Get Attendant by ID
const getAttendantById = async (req, res) => {
  try {
    const { id } = req.params;
    let attendant = await Attendant.findById(id).populate({ path: "shopId", populate: { path: "subscription", populate: { path: "packageId" } } });

    if (!attendant) {
      return res.status(404).json({ error: "Attendant not found" });
    }
    // attendant.lastAppRatingDate = '2024-08-16T00:00:00.000Z';
    res.status(200).json(attendant);
  } catch (error) { 
    console.error(error);
    res.status(500).json({ error: "Error fetching attendant by ID" });
  }
};

const loginAattendant = async (req, res) => {
  console.log(req.body)
  try {
    const { uid, password } = req.body;

    // Find the admin with the provided email
    const attendant = await Attendant.findOne({ uniqueDigits: parseInt(uid) });
    if (!attendant) {
      // If attendant not found, return a 401 Unauthorized response
      return res.status(401).json({ error: "Invalid user ID or password" });
    }
    const passwordMatch = await bcrypt.compare(password, attendant.password);
    if (!passwordMatch) {
      // If passwords don't match, return a 401 Unauthorized response
      return res.status(401).json({ error: "Invalid user ID or password" });
    }
    const token = jwt.sign(
      { uid: attendant.uniqueDigits, _id: attendant._id },
      "123456",
      {
        expiresIn: "24h",
      }
    );
    res.status(200).json({
      token,
      expiresIn: 24 * 60 * 60 * 1000,
      userdata: {
        _id: attendant._id,
        email: attendant.email,
        uniqueDigits: attendant.uniqueDigits,
      },
    });
  } catch (error) {
    // console.error(error);
    res.status(500).json({ error: "Login failed" });
  }
};

module.exports = {
  createAttendant,
  getAllAttendants,
  getAttendantById,
  updateAttendant,
  deleteAttendant,
  getAttendantsByShopOrAdminId,
  loginAattendant,
};

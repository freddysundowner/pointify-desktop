const paymentMethodSchema = require("../models/pament_methods");
const markUnsyncedPlugin = require("../shared/markUnsynced.plugin");

exports.addPaymentMethod = async (req, res) => {
    try {
        console.log("saving");
        let datasArray = req.body;
        datasArray.forEach((data) => {
            let exists = paymentMethodSchema.findOne({ name: data.name });
            if (exists) {
                // update
                paymentMethodSchema.updateOne({ name: data.name }, data);
            }else{
                let pmt = new paymentMethodSchema(data);
                pmt.save();
            }
        })
        res.status(201).json({ message: 'Payment method added successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.updatePaymentMethod = async (req, res) => {
    try {
        const updatedPaymentMethod = await paymentMethodSchema.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedPaymentMethod) {
            return res.status(404).json({ message: 'Payment method not found' });
        }
        res.json(updatedPaymentMethod);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.deletePaymentMethod = async (req, res) => {
    try {
        const deletedPaymentMethod = await paymentMethodSchema.findByIdAndDelete(req.params.id);
        if (!deletedPaymentMethod) {
            return res.status(404).json({ message: 'Payment method not found' });
        }
        res.json(deletedPaymentMethod);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getPaymentMethodById = async (req, res) => {
    try {
        const paymentMethod = await paymentMethodSchema.findById(req.params.id);
        if (!paymentMethod) {
            return res.status(404).json({ message: 'Payment method not found' });
        }
        res.json(paymentMethod);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getAllPaymentMethods = async (req, res) => {
    try {
        const paymentMethods = await paymentMethodSchema.find();
        res.json(paymentMethods);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
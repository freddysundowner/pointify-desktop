// packageController.js

const Admin = require('../models/admin');
const Package = require('../models/package');
const Subscription = require('../models/subscription');

async function createPackage(req, res) {
  try {
    const { title, description, durationValue, durationUnit, amount, features, maxShops, type, discount, order, status = true,amountusd } = req.body;
    const newPackage = new Package({ title, description, durationValue, durationUnit, amount, features, maxShops, type,discount,order,status,amountusd });
    const savedPackage = await newPackage.save();
    res.json(savedPackage);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  } 
}
function hasProductionType(obj) {
  for (let key in obj) {
    if (obj.hasOwnProperty(key)) {
      if (obj[key]?.packageId?.type === 'production') {
        return true;
      }
    }
  }
  return false;
}
async function getAllPackages(req, res) {
  try {
  let { id, page, limit, admin } = req.query;

  // Convert page and limit to integers and calculate skip if page is provided
  const pageInt = parseInt(page) || 0;
  const limitInt = parseInt(limit) || 10;
  const skip = page ? (pageInt - 1) * limitInt : 0;

  if (id) {
    const adminSubscription = await Subscription.find({ userId: id }).populate("packageId");

    let packagesQuery;

    if (hasProductionType(adminSubscription)) {
      if (!admin) {
        console.log(admin);
        packagesQuery = Package.find({
          status: true,
        }).sort({ order: 1 });
      }else{

      packagesQuery = Package.find({
        status: true,
      }).sort({ order: 1 });
      }
    } else {
      packagesQuery = Package.find({
        status: true,
        type: { $nin: ['trial'] }
      }).sort({ order: 1 });
    }

    // Apply pagination if 'page' is passed
    if (page) {
      packagesQuery = packagesQuery.skip(skip).limit(limitInt);
    }

    const packages = await packagesQuery;

    if (page) {
      // Get total count for pagination
      const totalPackages = await Package.countDocuments(packagesQuery.getFilter());
      const totalPages = Math.ceil(totalPackages / limitInt);

      return res.json({
        packages,
        totalPackages,
        totalPages,
        currentPage: pageInt,
      });
    } else {
      return res.json(packages);
    }
  }
    let packagesQuery;
   if (admin) {
      packagesQuery = Package.find().sort({ order: 1 });
   } else {
      packagesQuery = Package.find({
        status: true,
        type: { $nin: ['trial'] }
      }).sort({ order: 1 });
    }

  // Apply pagination if 'page' is passed
  if (page) {
    packagesQuery = packagesQuery.skip(skip).limit(limitInt);
  }

  const packages = await packagesQuery;

  if (page) {
    // Get total count for pagination
    const totalPackages = await Package.countDocuments(packagesQuery.getFilter());
    const totalPages = Math.ceil(totalPackages / limitInt);

    res.json({
      data: packages,
      count: totalPackages,
      totalPages,
      currentPage: pageInt,
    });
  } else {
    res.json(packages);
  }
} catch (error) {
  console.error(error);
  res.status(500).json({ error: 'Internal Server Error' });
}

}

async function getPackageById(req, res) {
  const packageId = req.params.id;

  try {
    const package = await Package.findById(packageId);
    if (!package) {
      return res.status(404).json({ error: 'Package not found' });
    }
    res.json(package);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}

async function updatePackage(req, res) {
  const packageId = req.params.id;

  try {
    const { title, description, durationValue, durationUnit, amount, features, maxShops, type,discount,order,status = true ,amountusd} = req.body;
    console.log(req.body);
    const updatedPackage = await Package.findByIdAndUpdate(
      packageId,
      { title, description, durationValue, durationUnit, amount, features, maxShops, type,discount,order,status ,amountusd},
      { new: true }
    );
    if (!updatedPackage) {
      return res.status(404).json({ error: 'Package not found' });
    }
    res.json(updatedPackage);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}

async function deletePackage(req, res) {
  const packageId = req.params.id;

  try {
    const deletedPackage = await Package.findByIdAndDelete(packageId);
    if (!deletedPackage) {
      return res.status(404).json({ error: 'Package not found' });
    }
    res.json({ message: 'Package deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}

module.exports = {
  createPackage,
  getAllPackages,
  getPackageById,
  updatePackage,
  deletePackage,
};

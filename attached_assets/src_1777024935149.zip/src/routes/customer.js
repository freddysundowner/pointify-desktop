const express = require("express");
const router = express.Router();
const {
  createCustomer,
  getAllCustomers,
  getCustomerById,
  updateCustomer,
  deleteCustomer,
  getPayments,
  customerVerify,
  getCustomerNo,
  getAllDebstorsExcel,
  getAllDebstors,
  importCustomers,
  deleteCustomerPayment,getCustomerAnalysis,getOverdueCustomers
} = require("../controllers/customer"); // Replace with the actual path

/**
 * @swagger
 * tags:
 *   name: Customers
 *   description: Operations for managing customers
 */

/**
 * @swagger
 * /customers:
 *   post:
 *     summary: Create a new customer
 *     tags: [Customers]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: John Doe
 *               wallet:
 *                 type: number
 *                 example: 100
 *               shopId:
 *                 type: string
 *                 example: 123456
 *               attendantId:
 *                 type: string
 *                 example: 789012
 *     responses:
 *       201:
 *         description: Created
 */

// Create a new customer
router.post("/", createCustomer);

router.post("/verify", customerVerify);

/**
 * @swagger
 * /customers:
 *   get:
 *     summary: Retrieve all customers or customers by shopId
 *     tags: [Customers]
 *     parameters:
 *       - in: query
 *         name: shopId
 *         schema:
 *           type: string
 *         description: Optional. Filter customers by shopId.
 *       - in: query
 *         name: type
 *         schema:
 *           type: string
 *         description: type of customers. e.g debtors, all.
 *     responses:
 *       200:
 *         description: Successful response
 */

// Retrieve all customers
router.get("/", getAllCustomers);


/**
 * @swagger
 * /customers/customerno:
 *   get:
 *     summary: Retrieve a single customer by ID
 *     tags: [Customers]
 *     parameters:
 *       - in: path
 *         name: customerno
 *         schema:
 *           type: string
 *         required: true
 *         description: Customer No to retrieve.
 *     responses:
 *       200:
 *         description: Successful response
 */

// Retrieve a single customer by ID
router.get("/customerno", getCustomerNo);
/**
 * @swagger
 * /customers/{customerId}:
 *   get:
 *     summary: Retrieve a single customer by ID
 *     tags: [Customers]
 *     parameters:
 *       - in: path
 *         name: customerId
 *         schema:
 *           type: string
 *         required: true
 *         description: Customer ID to retrieve.
 *     responses:
 *       200:
 *         description: Successful response
 */

// Retrieve a single customer by ID
router.get("/:customerId", getCustomerById);

/**
 * @swagger
 * /customers/{customerId}:
 *   put:
 *     summary: Update a customer by ID
 *     tags: [Customers]
 *     parameters:
 *       - in: path
 *         name: customerId
 *         schema:
 *           type: string
 *         required: true
 *         description: Customer ID to update.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Updated Name
 *               wallet:
 *                 type: number
 *                 example: 200
 *               shopId:
 *                 type: string
 *                 example: 123456
 *               phonenumber:
 *                 type: string
 *                 example: 123456
 *               email:
 *                 type: string
 *                 example: test@gmail.com
 *               address:
 *                 type: string
 *                 example: nakuru
 *               attendantId:
 *                 type: string
 *                 example: 789012
 *     responses:
 *       200:
 *         description: Successful response
 */

// Update a customer by ID
router.put("/:customerId", updateCustomer);

/**
 * @swagger
 * /customers/{customerId}:
 *   delete:
 *     summary: Delete a customer by ID
 *     tags: [Customers]
 *     parameters:
 *       - in: path
 *         name: customerId
 *         schema:
 *           type: string
 *         required: true
 *         description: Customer ID to delete.
 *     responses:
 *       200:
 *         description: Successful response
 */

// Delete a customer by ID
router.delete("/:customerId", deleteCustomer);

/**
 * @swagger
 * /customers/payments/{customerId}:
 *   get:
 *     tags:
 *       - Customers
 *     summary: Get payments by customer ID
 *     description: Retrieve payments associated with a specific customer by its ID.
 *     parameters:
 *       - in: path
 *         name: customerId
 *       - in: query
 *         name: type
 *     responses:
 *       200:
 *         description: Successful response
 */
router.get("/payments/:customerId", getPayments);
router.get("/customers/debtors/excel", getAllDebstorsExcel);
router.get("/customers/debtors", getAllDebstors);
router.post("/import/customers", importCustomers);
router.delete("/payments/delete/:id",deleteCustomerPayment)

router.get("/analysis/:shopId",getCustomerAnalysis)
router.get("/overdue/:shopId",getOverdueCustomers)
module.exports = router;

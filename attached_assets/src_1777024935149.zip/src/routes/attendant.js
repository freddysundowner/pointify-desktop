const express = require("express");
const router = express.Router();
const attendantController = require("../controllers/attendant");

// Create Attendant with shopId
/**
 * @swagger
 * /attendants:
 *   post:
 *     summary: Create a new Attendant with shopId.
 *     description: Create a new Attendant with a specified shopId.
 *     tags:
 *       - Attendants
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               username:
 *                 type: string
 *               uniqueDigits:
 *                 type: number
 *               password:
 *                 type: string
 *               shopId:
 *                 type: string
 *               adminId:
 *                 type: string
 *               permissions:
 *                 type: string
 *             required:
 *               - username
 *               - uniqueDigits
 *               - password
 *               - shopId
 *               - adminId
 *     responses:
 *       201:
 *         description: Attendant created successfully.
 *       500:
 *         description: Internal server error.
 */
router.post("/", attendantController.createAttendant);

// Update Attendant with shopId
/**
 * @swagger
 * /attendants/{id}:
 *   put:
 *     summary: Update an Attendant with shopId.
 *     description: Update an Attendant with a specified shopId.
 *     tags:
 *       - Attendants
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the Attendant to update.
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               username:
 *                 type: string
 *               uniqueDigits:
 *                 type: number
 *               password:
 *                 type: string
 *               shopId:
 *                 type: string
 *             required:
 *               - username
 *               - uniqueDigits
 *               - password
 *               - shopId
 *     responses:
 *       200:
 *         description: Attendant updated successfully.
 *       404:
 *         description: Attendant not found.
 *       500:
 *         description: Internal server error.
 */
router.put("/:id", attendantController.updateAttendant);

// Get Attendants by Shop ID
/**
 * @swagger
 * /attendants/shop/filter:
 *   get:
 *     summary: Get Attendants by shopId or adminId.
 *     description: Retrieve a list of Attendants for a specified shopId or adminId.
 *     tags:
 *       - Attendants
 *     parameters:
 *       - in: query
 *         name: adminId
 *         schema:
 *           type: string
 *       - in: query
 *         name: shopId
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Attendants retrieved successfully.
 *       404:
 *         description: Attendants not found for the specified shopId.
 *       500:
 *         description: Internal server error.
 */
router.get("/shop/filter", attendantController.getAttendantsByShopOrAdminId);

// Get Attendant by ID
/**
 * @swagger
 * /attendants/{id}:
 *   get:
 *     summary: Get an Attendant by ID.
 *     description: Retrieve an Attendant by its ID.
 *     tags:
 *       - Attendants
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the Attendant to retrieve.
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Attendant retrieved successfully.
 *       404:
 *         description: Attendant not found.
 *       500:
 *         description: Internal server error.
 */
router.get("/:id", attendantController.getAttendantById);


// Get Attendant by ID
/**
 * @swagger
 * /attendants/{id}:
 *   get:
 *     summary: delete an Attendant by ID.
 *     description: Retrieve an Attendant by its ID.
 *     tags:
 *       - Attendants
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID of the Attendant to retrieve.
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Attendant retrieved successfully.
 *       404:
 *         description: Attendant not found.
 *       500:
 *         description: Internal server error.
 */
router.delete("/:id", attendantController.deleteAttendant);
router.post("/login", attendantController.loginAattendant);
router.get("/all/:id",attendantController.getAllAttendants)


module.exports = router;
 
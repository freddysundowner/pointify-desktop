const express = require('express');
const router = express.Router();
const {
  createAffiliate,
  getAllAffiliates,
  getAffiliateById,
  updateAffiliate,
  deleteAffiliate,
  loginAffliate,
  registerAffliate
} = require('../controllers/affliate');


router.post("/auth/register", registerAffliate);

router.post("/auth/login", loginAffliate);


router.post('/', createAffiliate);

router.get('/', getAllAffiliates);

/**
 * @swagger
 * /affiliates/{id}:
 *   get:
 *     summary: Get an affiliate by ID
 *     tags: [Affliates]
 *     description: Get affiliate details by providing its ID.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Affiliate ID
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Success
 *       404:
 *         description: Affiliate not found
 *       500:
 *         description: Internal server error
 */

router.get('/:id', getAffiliateById);

/**
 * @swagger
 * /affiliates/{id}:
 *   put:
 *     summary: Update an affiliate
 *     tags: [Affliates]
 *     description: Update an affiliate's information by providing its ID.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Affiliate ID
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               phoneNumber:
 *                 type: string
 *               email:
 *                 type: string
 *               address:
 *                 type: string
 *               password:
 *                 type: string
 *               type:
 *                 type: string
 *                 enum: [basic, gold, silver]
 *     responses:
 *       200:
 *         description: Affiliate updated successfully
 *       400:
 *         description: Bad request. Check request body for errors.
 *       404:
 *         description: Affiliate not found
 *       500:
 *         description: Internal server error
 */

router.put('/:id', updateAffiliate);

/**
 * @swagger
 * /affiliates/{id}:
 *   delete:
 *     summary: Delete an affiliate
 *     tags: [Affliates]
 *     description: Delete an affiliate by providing its ID.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Affiliate ID
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Affiliate deleted successfully
 *       404:
 *         description: Affiliate not found
 *       500:
 *         description: Internal server error
 */

router.delete('/:id', deleteAffiliate);

module.exports = router;

const express = require("express");
const router = express.Router();
const supplierController = require("../controllers/supplier");
/**
 * @swagger
 * /suppliers:
 *   post:
 *     summary: Create a new supplier
 *     description: Create a new supplier with a name and associated shop.
 *     tags:
 *       - Suppliers
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               shopId:
 *                 type: string
 *             required:
 *               - name
 *               - shopId
 *     responses:
 *       201:
 *         description: Supplier created successfully.
 *       500:
 *         description: Internal server error. 
 */

// Create a new supplier
router.post("/", supplierController.createSupplier);
/**
 * @swagger
 * /suppliers:
 *   get:
 *     summary: Get all suppliers with filter by shop id
 *     description: Retrieve a list of all suppliers in the system with filter by shop id.
 *     tags:
 *       - Suppliers
 *     parameters:
 *       - in: path
 *         name: shopid
 *         required: true
 *         description: Get suppliers  filter by shop id.
 *         schema:
 *           type: string
 *           format: ObjectId
 *       - in: query
 *         name: type
 *         schema:
 *           type: string
 *         description: type of suppliers. e.g debtors, all.
 *     responses:
 *       200:
 *         description: A list of suppliers.
 *       500:
 *         description: Internal server error.
 */
// Get all suppliers
router.get("/supplier/:supplier", supplierController.getSupplierSupplies);

/**
 * @swagger
 * /suppliers:
 *   get:
 *     summary: Get all suppliers with filter by shop id
 *     description: Retrieve a list of all suppliers in the system with filter by shop id.
 *     tags:
 *       - Suppliers
 *     parameters:
 *       - in: path
 *         name: shopid
 *         required: true
 *         description: Get suppliers  filter by shop id.
 *         schema:
 *           type: string
 *           format: ObjectId
 *     responses:
 *       200:
 *         description: A list of suppliers.
 *       500:
 *         description: Internal server error.
 */
// Get all suppliers
router.get("/", supplierController.getAllSuppliers);
/**
 * @swagger
 * /suppliers/{id}:
 *   put:
 *     summary: Update a supplier by ID
 *     description: Update a supplier's name and associated shop by its unique ID.
 *     tags:
 *       - Suppliers
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the supplier.
 *         schema:
 *           type: string
 *           format: ObjectId
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               shopId:
 *                 type: string
 *             required:
 *               - name
 *               - shopId
 *     responses:
 *       200:
 *         description: Supplier updated successfully.
 *       404:
 *         description: Supplier not found.
 *       500:
 *         description: Internal server error.
 */
// Update a supplier by ID
router.put("/:id", supplierController.updateSupplier);
/**
 * @swagger
 * /suppliers/{id}:
 *   delete:
 *     summary: Delete a supplier by ID
 *     description: Delete a supplier by its unique ID.
 *     tags:
 *       - Suppliers
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: The ID of the supplier.
 *         schema:
 *           type: string
 *           format: ObjectId
 *     responses:
 *       204:
 *         description: Supplier deleted successfully.
 *       404:
 *         description: Supplier not found.
 *       500:
 *         description: Internal server error.
 */
// Delete a supplier by ID
router.delete("/:id", supplierController.deleteSupplier);

router.post("/import/suppliers", supplierController.importSuppliers);
module.exports = router;

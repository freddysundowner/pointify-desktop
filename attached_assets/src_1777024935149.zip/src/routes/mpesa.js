const express = require("express");
const functions = require("../shared/functions")
const mpesa = express.Router();
const mpesaController = require("../controllers/mpesa");
const { createSubscription,confirmPayment } = require("../controllers/subscription");
const { Types } = require("mongoose");
const ObjectId = Types.ObjectId;
const Package = require("../models/package");
const Shop = require("../models/shop");
const Subscription = require("../models/subscription");
const { sendEmail } = require("../shared/emailsetup");
const Admin = require("../models/admin");
const awardsSchema = require("../models/awards");
const Affliate = require("../models/affliate");
const Transaction = require("../models/transactions");
const axios = require('axios');

/**
 * @swagger
 * /payment/subscribe/confirm:
 *   post:
 *     summary: check payment status.
 *     tags:
 *       - Mpesa
 *     requestBody:
 *       description: check payment status.
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               shopid:
 *                 type: string
 *               packageid:
 *                 type: string
 *     responses:
 *       200:
 *         description: Successfully recorded the payment.
 *       400:
 *         description: Invalid request or payment amount exceeds outstanding balance.
 *       404:
 *         description: Purchase not found.
 */

mpesa.post("/subscribe/confirm", confirmPayment);
/**
 * @swagger
 * /payment/registerurl:
 *   post:
 *     summary: Record a payment for a purchase made on credit.
 *     tags:
 *       - Mpesa
 *     responses:
 *       200:
 *         description: Successfully recorded the payment.
 *       400:
 *         description: Invalid request or payment amount exceeds outstanding balance.
 *       404:
 *         description: Purchase not found.
 */

mpesa.post("/registerurl", mpesaController.registerMpesaUrl);

/**
 * @swagger
 * /payment/subscribe:
 *   post:
 *     summary: Record a payment for a purchase made on credit.
 *     tags:
 *       - Mpesa
 *     requestBody:
 *       description: The package object.
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               amount:
 *                 type: number
 *               phonenumber:
 *                 type: string
 *               packageId:
 *                 type: string
 *               shopId:
 *                 type: string
 *     responses:
 *       200:
 *         description: Successfully recorded the payment.
 *       400:
 *         description: Invalid request or payment amount exceeds outstanding balance.
 *       404:
 *         description: Purchase not found.
 */
mpesa
    .route(`/subscribe`)
    .post(
        async (req, res) => {

            let { amount } = await Package.findById(req.body.packageId);
            var data = {
                amount: amount,
                package: req.body.packageId,
                shop: req.body.shopId,
                userId: req.body.userId,
                phone: req.body.phonenumber,
                call_back: process.env.MPESA_DEPOSIT_CALLBACK,
            };
            console.log(data)
            let response = await functions.subscribe(data);
            console.log("vvvv ",response);
            res.json(response);

        }
    )



// mpesa.post('/confirmation', createSubscription);
mpesa
    .route(`/query`)
    .post(
        async (req, res) => {
            await functions.checkTransactionStatus(req.body).then((r) => {
                res.json({ status: 200, message: "waiting" })
            }).catch((e) => {
                res.json(e)
            })
        }
    );
mpesa
    .route(`/reverse`)
    .post(
        async (req, res) => {
            let response = await functions.reverse(req.body).then((r) => {
                res.json(response)
            }).catch((e) => {
                res.json(e)
            })
        }
    );
mpesa
    .route(`/validation`)
    .post(async (req, res) => {
        console.log("validation")
        res.send({ "ResultCode": "0", "ResultDesc": "Success", "ThirdPartyTransID": "0" });

    })

/**
 * @swagger
 * /payment/confirmation:
 *   post:
 *     summary: Create a new subscription
 *     description: Endpoint to create a new subscription.
 *     tags: [Subscriptions]
 *     parameters:
 *       - in: path
 *         name: shop
 *         description: shop id.
 *         required: true
 *       - in: path
 *         name: package
 *         description: package id.
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Subscription created successfully
 *       '500':
 *         description: Internal Server Error
 */
mpesa
    .route(`/confirmation`)
    .post(
        async (req, res) => {
            
            var transaction_code = req.body.TransID;
            if (transaction_code == undefined || transaction_code == null) {
                res.json({ status: 500, message: "invalid transaction" });
                return;
            }
            let reference = req.body.BillRefNumber
            if (reference.includes("elimu")) { 
                const apiUrl = 'https://258d8bf8-3545-4261-aa4b-8174819750ad-00-2gsyrrve7byny.picard.replit.dev/api/mpesa/payment-callback';
                const response = await axios.post(apiUrl, req.body);
                return;
            }
            console.log(req.body);
            console.log(req.query, req.params);
            const subscriptioresponsen = await Subscription.findOne({ invoiceNo: req.body.BillRefNumber }).populate("packageId").populate("userId").populate("shops");
            console.log(subscriptioresponsen);
            let subscription;
            if (subscriptioresponsen) {
                subscription = subscriptioresponsen;
                subscription.status = true;
                subscription.paid = true;
                subscription.mpesaCode = transaction_code;
                subscription.amount = req.body.TransAmount;
                subscription.save();
            } else {
                return;
            }
            let afterupdate = await Shop.updateMany(
                { _id: { $in: subscriptioresponsen?.shops } },
                { subscription: subscriptioresponsen?._id },
                { new: true }
            );
            console.log(afterupdate);

            const shopNames = Object.keys(subscriptioresponsen?.shops).map(key => subscriptioresponsen.shops[key].name);
            console.log(shopNames);
            const replacements = {
                username: subscriptioresponsen.userId.username,
                shopname: shopNames
            };
            sendEmail(subscriptioresponsen.userId.email, 'Pointify Subscription', 'subscription', replacements);
            functions.sendSms(subscriptioresponsen?.userId?.phone,"Your Subscription has successfully been activated, expiry date is "+subscriptioresponsen?.endDate+"\n Thank you for doing business with us!");
            let award = 0;
            if (subscriptioresponsen.userId.affliate) {
                let affliateReponse = await Affliate.findById(subscriptioresponsen.userId.affliate);
                let awardres = await functions.getAffiliateBonus(subscriptioresponsen.userId.affliate, subscription.amount);//(subscription.amount / 100) * affliateReponse.commission;
                console.log(awardres);
                award = parseFloat(awardres['award']);
                console.log(award);
                let bal = (affliateReponse?.wallet ?? 0) + award;
                await awardsSchema.create({
                    type: "earnings",
                    awardType: "subscription",
                    shops: subscriptioresponsen?.shops,
                    user: affliateReponse?._id,
                    totalAmount: award,
                    mpesaCode : transaction_code,
                    balance: bal,
                });
                affliateReponse.wallet = affliateReponse.wallet + award;
                affliateReponse.save();
                const replacementss = {
                    referrerName: affliateReponse.name,
                    shopName: shopNames,
                    ownerName: subscriptioresponsen?.userId.username,
                    points: award,
                    type: "subscription",
                    currency: "KES",
                };
                sendEmail(affliateReponse.email, 'Earnings!!', 'partneraward', replacementss);
                functions.sendSms(affliateReponse?.phonenumber,"Congratulations!! you have earned KES "+award+" for "+subscriptioresponsen?.userId?.username+" subscription, your new balance is KES"+bal);

            }
            //award a user as an affliate
            if (subscriptioresponsen.userId.referal) {
                let adminResponse = await Admin.findById(subscriptioresponsen.userId.referal).populate("primaryShop");
                     award = (subscription.amount / 100) * 10;
                    await awardsSchema.create({
                        type: "earnings",
                        awardType: "subscription",
                        shops: subscriptioresponsen?.shops,
                        user: adminResponse?._id,
                        totalAmount: award,
                        balance: (adminResponse?.referalCredit ?? 0) + award,
                    });
                    adminResponse.referalCredit = adminResponse.referalCredit + award;
                    adminResponse.save();
                    const replacementss = {
                        referrerName: adminResponse.username,
                        shopName: shopNames,
                        ownerName: adminResponse.username,
                        points: award,
                        type: "subscription",
                        currency: adminResponse.primaryShop == null ? "KES" : adminResponse.primaryShop.currency,
                    };
                    sendEmail(adminResponse.email, 'Awarded!!', 'openshopaward', replacementss);
                    functions.sendSms(adminResponse?.phone,"Congratulations!! you have earned KES "+award+" for sharing app with "+subscriptioresponsen?.userId?.username);
                }
                const transactoinResponse = await Transaction.create({
                    amount: req.body.TransAmount,
                    balance: 0,
                    type: "subscription",
                    user: subscriptioresponsen.userId?._id,
                    transId: req.body.BillRefNumber,
                    mpesaCode: transaction_code,
                    status: true,
                    affliate: subscriptioresponsen?.userId?.affliate,
                    affliateAmount: award
                })
                transactoinResponse.save();

            //stop this shop other subscriptions
            // await Subscription.findOneAndUpdate(
            //     { shops: { $in: subscription.shop } },
            //     { status: false, endDate: new Date() }
            // );
        });
module.exports = mpesa;
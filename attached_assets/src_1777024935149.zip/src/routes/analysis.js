// routes/stockValueRoute.js

const express = require("express");
const router = express.Router();

const analysisController = require("../controllers/analysis");
const { getSalesSummary } = require("../controllers/sales");
const { getPurchasesSummary } = require("../controllers/purchase");

/**
 * @swagger
 * /analysis/stockanalysis:
 *   get:
 *     summary: Calculate total stock value and profit estimate.
 *     description: Retrieve the total stock value and profit estimate based on buying and selling prices of products.
 *     tags:
 *       - Analysis
 *     parameters:
 *       - in: query
 *         name: shopid
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: Start date for the netprofit calculation.
 *     responses:
 *       200:
 *         description: Successful calculation of stock value and profit estimate.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 totalStockValue:
 *                   type: number
 *                   description: Total stock value based on buying prices and quantities.
 *                 profitEstimate:
 *                   type: number
 *                   description: Estimated profit based on buying and selling prices and quantities.
 *       500:
 *         description: Internal server error.
 */

router.get("/stockanalysis", analysisController.calculateStockValue);
router.get("/profits/summary", analysisController.profitSummary);
router.get("/netprofit", analysisController.calculateetProfit);
// router.get("/duesbydate/", analysisController.getduesbydate);

/**
 * @swagger
 * /analysis/netprofit/yearly/{year}:
 *   get:
 *     summary: Calculate netprofit by a date range
 *     tags: [Analysis]
 *     parameters:
 *       - in: path
 *         name: year
 *         schema:
 *           type: string
 *           format: date
 *         description: Start date for the netprofit calculation.
 *     responses:
 *       '200':
 *         description: Successful
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 totalSales:
 *                   type: number
 *                   description: Total sales for the specified date range.
 *                 profitOnSales:
 *                   type: number
 *                   description: Profit on sales for the specified date range.
 *                 badStockValue:
 *                   type: number
 *                   description: Bad stock value for the specified date range.
 *                 totalExpenses:
 *                   type: number
 *                   description: Total cashflow for the specified date range
 *       '500':
 *         description: Failed to calculate financial data
 */
router.get(
  "/netprofit/yearly/:year",
  analysisController.calculateFinancialDataByYear
);


/**
 * @swagger
 * /analysis/report/sales:
 *   get:
 *     summary: Calculate total stock value and profit estimate.
 *     description: Retrieve the total stock value and profit estimate based on buying and selling prices of products.
 *     tags:
 *       - Analysis
 *     parameters:
 *       - in: query
 *         name: shopid
 *         required: true
 *       - in: query
 *         name: fromDate
 *         required: true
 *       - in: query
 *         name: toDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: get sales report by date.
 *     responses:
 *       200:
 *         description: Successful calculation of stock value and profit estimate.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 totalStockValue:
 *                   type: number
 *                   description: Total stock value based on buying prices and quantities.
 *                 profitEstimate:
 *                   type: number
 *                   description: Estimated profit based on buying and selling prices and quantities.
 *       500:
 *         description: Internal server error.
 */

router.get("/report/sales", getSalesSummary);


/**
 * @swagger
 * /analysis/report/purchases:
 *   get:
 *     summary: Calculate total stock value and profit estimate.
 *     description: Retrieve the total stock value and profit estimate based on buying and selling prices of products.
 *     tags:
 *       - Analysis
 *     parameters:
 *       - in: query
 *         name: shopid
 *         required: true
 *       - in: query
 *         name: fromDate
 *         required: true
 *       - in: query
 *         name: toDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: get purchases report by date.
 *     responses:
 *       200:
 *         description: Successful calculation of stock value and profit estimate.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 totalStockValue:
 *                   type: number
 *                   description: Total stock value based on buying prices and quantities.
 *                 profitEstimate:
 *                   type: number
 *                   description: Estimated profit based on buying and selling prices and quantities.
 *       500:
 *         description: Internal server error.
 */

router.get("/report/purchases", getPurchasesSummary);
/**
 * @swagger
 * /analysis/backup/download/{id}:
 *   get:
 *     summary: send email with backup data.
 *     tags:
 *       - Analysis
 *     parameters:  
 *       - in: path
 *         name: id
 *         required: true 
 *         description: send email with backup data. 
 */

router.get("/backup/download/:id", analysisController.sendBackupEmail);

 

router.put("/update/user/lastseen", analysisController.updateLastSeen);
router.get("/pdf/download/file", analysisController.getOutOfStockProductsExcel)
router.get("/stock/count/analysis", analysisController.getStockCountAnalysis)
module.exports = router;
 
const express = require("express");
const router = express.Router();
const productController = require("../controllers/product");
router.post("/category/", productController.createProductCategory);
router.get("/category/", productController.getAllProductCategories);
router.put("/category/:id", productController.updateProductCategory);
router.delete("/category/:id", productController.deleteProductCategory);

router.get("/category/all/:id", productController.getProductCategoryById);
router.post("/", productController.createProduct);
router.get("/", productController.getAllProducts);
router.get("/admin/products", productController.getProducts);
router.put("/:id", productController.updateProduct);

router.get("/:id", productController.getProductById);
router.get("/product/search", productController.searchProducts);
router.delete("/:id", productController.deleteProduct);
router.put("/remove/bundle/item", productController.removebundleitem);
router.get("/product/summary", productController.getProductSummary);
router.get("/shop/:shopId", productController.getProductsByShopId);
router.post("/import/products", productController.importProducts);
/**
 * @swagger
 * /product/transfer/products:
 *   post:
 *     summary: Import products from an Excel sheet.
 *     description: Upload an Excel sheet containing product data to import into the system.
 *     tags:
 *       - Products
 *     consumes:
 *       - multipart/form-data
 *     parameters:
 *       - in: formData
 *         name: productExcel
 *         type: file
 *         description: Excel file containing product data.
 *         required: true
 *     responses:
 *       200:
 *         description: Successful import of products.
 *       400:
 *         description: Bad request. No file uploaded or invalid file format.
 *       500:
 *         description: Internal server error.
 */

router.post("/transfer/products", productController.transferProducts);
/**
 * @swagger
 * /product/stockreport/{shopId}:
 *   get:
 *     summary: Get stock report by shopId
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: shopId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Successfully retrieved stock report by shopId.
 *       '500':
 *         description: Internal server error.
 */

router.get("/stockreport/:shopId", productController.getStockReport);

/**
 * @swagger
 * /product/images/{id}:
 *   get:
 *     summary: update product images
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Successfully update product data.
 *       '500':
 *         description: Internal server error.
 */

router.put("/images/:id", productController.updateProductImages);
router.post("/report", productController.generateResports);
router.put("/adjust/:id", productController.adjustStock);
router.get("/adjust/:id", productController.getProductAdjustments);
router.get("/bundle/items/:id", productController.getProductBundleItems)
router.get("/history/product", productController.getStockAndSalesSummary)
module.exports = router;
 